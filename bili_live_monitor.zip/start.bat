@echo off
chcp 65001 >nul
set PYTHONIOENCODING=utf-8
title bili-live-log
cd /d "%~dp0"

:loop
echo [%date% %time%] start...
python main.py <nul
echo [%date% %time%] exit code %errorlevel%, restart in 5s...
ping -n 6 127.0.0.1 >nul
goto loop