#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# dialogs.py
"""登录对话框 + 账号管理（含 IP 属地 + 高级功能 + 勋章搜索防抖）"""
import asyncio
import json
import re
import threading
import time
import urllib.parse
import webbrowser

import tkinter as tk
from tkinter import messagebox, ttk

import qrcode
from PIL import Image, ImageTk

import account
import auth
import avatar_cache
from logger import log, log_err

try:
    from auth import (
        login_bridge, do_password_login,
        api_get_all_medals, api_wear_medal,
    )
except Exception:
    login_bridge = None
    do_password_login = None
    api_get_all_medals = None
    api_wear_medal = None


# ---------- 配色 / 字体 ----------
BG_MAIN = "#1e272e"
BG_PANEL = "#2c3e50"
BG_CARD = "#34495e"
BG_INPUT = "#22313f"
BG_BORDER = "#3d566e"
FG_MAIN = "#ecf0f1"
FG_SUB = "#95a5a6"
FG_DIM = "#6e7681"
ACCENT = "#1abc9c"
BTN_PRIMARY = "#2ecc71"
BTN_PRIMARY_HOVER = "#27ae60"
BTN_DANGER = "#e74c3c"
BTN_DANGER_HOVER = "#c0392b"
BTN_NEUTRAL = "#7f8c8d"
BTN_NEUTRAL_HOVER = "#95a5a6"
BTN_INFO = "#3498db"
BTN_INFO_HOVER = "#2980b9"
BTN_WARN = "#f39c12"
WARN = "#f1c40f"

FONT_TITLE = ("Microsoft YaHei UI", 16, "bold")
FONT_HEAD = ("Microsoft YaHei UI", 11, "bold")
FONT_BODY = ("Microsoft YaHei UI", 10)
FONT_SMALL = ("Microsoft YaHei UI", 9)
FONT_TINY = ("Microsoft YaHei UI", 8)
FONT_BTN = ("Microsoft YaHei UI", 10, "bold")
FONT_MONO = ("Consolas", 10)


# ---------- 缓存 ----------
_COUNTRY_LIST_CACHE = {"common": [], "others": [], "loaded": False}
_MEDAL_CACHE = {"items": None, "loaded": False, "loading": False}


def _fmt_cid(code, name):
    return f"+{code}  {name}"


# ============================================================
#  IP 属地
# ============================================================
async def _fetch_ip_zone(timeout=5):
    """获取当前 IP 属地。接口：x/web-interface/zone（无需登录）。"""
    import aiohttp

    url = "https://api.bilibili.com/x/web-interface/zone"
    headers = {
        "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/120.0 Safari/537.36"),
        "Referer": "https://www.bilibili.com/",
    }
    try:
        async with aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=timeout)
        ) as s:
            async with s.get(url, headers=headers) as resp:
                data = await resp.json(content_type=None)
    except Exception as e:
        log(f"获取 IP 属地失败: {e}", "AUTH", show=False)
        return None

    if not isinstance(data, dict) or data.get("code") != 0:
        return None

    d = data.get("data") or {}
    return {
        "addr": d.get("addr", ""),
        "country": d.get("country", ""),
        "province": d.get("province", ""),
        "city": d.get("city", ""),
        "isp": d.get("isp", ""),
        "latitude": d.get("latitude", 0),
        "longitude": d.get("longitude", 0),
        "zone_id": d.get("zone_id", 0),
        "country_code": d.get("country_code", 0),
    }


def _fmt_ip_zone(info):
    if not info:
        return "", ""
    try:
        parts = []
        if info.get("country"):
            parts.append(info["country"])
        if info.get("province"):
            parts.append(info["province"])
        if info.get("city") and info.get("city") != info.get("province"):
            parts.append(info["city"])
        location = " · ".join(parts) if parts else "未知"

        short = f"IP属地: {location}"
        isp = info.get("isp", "")
        if isp:
            short += f" · {isp}"

        details = []
        addr = info.get("addr", "")
        if addr:
            details.append(f"IP: {addr}")
        lat = info.get("latitude")
        lng = info.get("longitude")
        if lat or lng:
            details.append(f"坐标: {lat}, {lng}")
        cc = info.get("country_code")
        if cc:
            details.append(f"国码: {cc}")
        zone_id = info.get("zone_id")
        if zone_id:
            details.append(f"zone: {zone_id}")

        return short, " · ".join(details)
    except Exception:
        return "", ""


def _load_country_list_sync():
    global _COUNTRY_LIST_CACHE
    if _COUNTRY_LIST_CACHE["loaded"]:
        return _COUNTRY_LIST_CACHE

    loop = asyncio.new_event_loop()
    try:
        data = loop.run_until_complete(auth.api_country_list())
    except Exception as e:
        log(f"加载国家列表异常: {e}", "AUTH", show=False)
        data = None
    finally:
        try:
            loop.close()
        except Exception:
            pass

    if not data:
        data = {
            "common": [
                ("86", "中国大陆"),
                ("852", "中国香港特别行政区"),
                ("853", "中国澳门特别行政区"),
                ("886", "中国台湾"),
                ("1", "美国"),
                ("81", "日本"),
                ("82", "韩国"),
                ("65", "新加坡"),
                ("60", "马来西亚"),
                ("44", "英国"),
                ("61", "澳大利亚"),
                ("33", "法国"),
                ("49", "德国"),
                ("7", "俄罗斯"),
            ],
            "others": [],
        }

    _COUNTRY_LIST_CACHE["common"] = data.get("common", [])
    _COUNTRY_LIST_CACHE["others"] = data.get("others", [])
    _COUNTRY_LIST_CACHE["loaded"] = True
    return _COUNTRY_LIST_CACHE


def _build_cid_values(default_code="86"):
    cache = _load_country_list_sync()
    common = cache["common"]
    others = cache["others"]

    seen = set()
    all_items = []
    for code, name in common + others:
        key = (code, name)
        if key in seen:
            continue
        seen.add(key)
        all_items.append((code, name))

    common_set = set(common)
    common_items = [(c, n) for c, n in common]
    other_items = [(c, n) for c, n in all_items if (c, n) not in common_set]
    other_items.sort(key=lambda x: x[1])

    values = [_fmt_cid(c, n) for c, n in common_items + other_items]

    default_text = _fmt_cid("86", "中国大陆")
    for c, n in common_items + other_items:
        if c == default_code:
            default_text = _fmt_cid(c, n)
            break

    code_map = {_fmt_cid(c, n): c for c, n in common_items + other_items}
    return values, default_text, code_map


def _center(win, w, h):
    try:
        win.update_idletasks()
        sw = win.winfo_screenwidth()
        sh = win.winfo_screenheight()
        x = max(0, (sw - w) // 2)
        y = max(0, (sh - h) // 2)
        win.geometry(f"{w}x{h}+{x}+{y}")
    except Exception:
        pass


def _ensure_dialog_style():
    if getattr(_ensure_dialog_style, "_done", False):
        return
    _ensure_dialog_style._done = True
    try:
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass

        style.configure("Dialog.TNotebook",
                        background=BG_MAIN, borderwidth=0)
        style.configure("Dialog.TNotebook.Tab",
                        background=BG_PANEL, foreground=FG_MAIN,
                        padding=[14, 8], font=FONT_BTN)
        style.map("Dialog.TNotebook.Tab",
                  background=[("selected", ACCENT), ("active", "#3d566e")],
                  foreground=[("selected", "#0f1a20")])

        style.configure("Dialog.TCombobox",
                        fieldbackground=BG_INPUT,
                        background=BG_INPUT,
                        foreground=FG_MAIN,
                        arrowcolor=ACCENT,
                        bordercolor=BG_INPUT,
                        lightcolor=BG_INPUT,
                        darkcolor=BG_INPUT,
                        borderwidth=0,
                        relief="flat",
                        padding=(2, 6))
        style.map("Dialog.TCombobox",
                  fieldbackground=[("readonly", BG_INPUT),
                                    ("active", BG_INPUT),
                                    ("focus", BG_INPUT)],
                  foreground=[("readonly", FG_MAIN),
                              ("active", FG_MAIN)],
                  background=[("readonly", BG_INPUT),
                              ("active", BG_INPUT)],
                  arrowcolor=[("active", "#26d4bb"),
                              ("focus", "#26d4bb")])
    except Exception:
        pass


def _install_combobox_listbox_style(win):
    try:
        win.option_add("*TCombobox*Listbox.background", BG_PANEL)
        win.option_add("*TCombobox*Listbox.foreground", FG_MAIN)
        win.option_add("*TCombobox*Listbox.selectBackground", ACCENT)
        win.option_add("*TCombobox*Listbox.selectForeground", "#0f1a20")
        win.option_add("*TCombobox*Listbox.font", FONT_BODY)
        win.option_add("*TCombobox*Listbox.borderWidth", 0)
        win.option_add("*TCombobox*Listbox.highlightThickness", 0)
        win.option_add("*TCombobox*Listbox.relief", "flat")
    except Exception:
        pass


def _int_to_hex(v, fallback="#888888"):
    if isinstance(v, int) and v > 0:
        return "#{:06X}".format(v & 0xFFFFFF)
    return fallback


def _pick_text_color(bg_hex, fallback="#FFFFFF"):
    try:
        r = int(bg_hex[1:3], 16)
        g = int(bg_hex[3:5], 16)
        b = int(bg_hex[5:7], 16)
        luma = 0.299 * r + 0.587 * g + 0.114 * b
        return "#000000" if luma > 160 else "#FFFFFF"
    except Exception:
        return fallback


# ============================================================
#  基类
# ============================================================
class _SafeToplevelMixin:
    def _safe_exists(self):
        try:
            if self.destroyed:
                return False
            return bool(self.win.winfo_exists())
        except Exception:
            return False

    def _safe_after(self, ms, func, *args):
        if not self._safe_exists():
            return None
        try:
            return self.win.after(ms, func, *args)
        except Exception:
            return None

    def _safe_msgbox(self, kind, title, message, default=None, **kwargs):
        if not self._safe_exists():
            return default
        try:
            fn = getattr(messagebox, kind)
            return fn(title, message, parent=self.win, **kwargs)
        except Exception:
            return default

    def _safe_close(self):
        try:
            self.destroyed = True
        except Exception:
            pass
        try:
            self.win.destroy()
        except Exception:
            pass


# ============================================================
#  登录对话框
# ============================================================
class LoginDialog(_SafeToplevelMixin):
    def __init__(self, parent, on_saved):
        self.on_saved = on_saved
        self.destroyed = False
        self.qr_polling = False
        self.qr_photo = None

        self._sms_captcha_key = ""
        self._sms_phone = ""
        self._sms_cid_value = "86"
        self._sms_cd_timer = None
        self._sms_cd_left = 0

        self._cid_values = None
        self._cid_map = None
        self._cid_default = None

        self.win = tk.Toplevel(parent)
        self.win.title("登录 Bilibili")
        self.win.configure(bg=BG_MAIN)
        self.win.transient(parent)
        _center(self.win, 700, 720)

        header = tk.Frame(self.win, bg=BG_MAIN)
        header.pack(fill=tk.X, padx=24, pady=(20, 6))
        tk.Label(header, text="登录 Bilibili", fg=ACCENT, bg=BG_MAIN,
                 font=FONT_TITLE).pack(anchor=tk.W)
        tk.Label(header, text="四种登录方式任选其一",
                 fg=FG_SUB, bg=BG_MAIN, font=FONT_SMALL).pack(
            anchor=tk.W, pady=(2, 0))

        _ensure_dialog_style()
        _install_combobox_listbox_style(self.win)

        self.nb = ttk.Notebook(self.win, style="Dialog.TNotebook")
        self.nb.pack(fill=tk.BOTH, expand=True, padx=20, pady=8)

        self._build_qr_tab()
        self._build_password_tab()
        self._build_sms_tab()
        self._build_cookie_tab()

        bottom = tk.Frame(self.win, bg=BG_MAIN)
        bottom.pack(fill=tk.X, padx=20, pady=(4, 18))
        tk.Button(bottom, text="关闭", command=self._close,
                  bg=BTN_NEUTRAL, fg="#ffffff",
                  activebackground=BTN_NEUTRAL_HOVER,
                  activeforeground="#ffffff",
                  font=FONT_BTN, relief=tk.FLAT, padx=24, pady=6,
                  cursor="hand2", bd=0).pack(side=tk.RIGHT)

        self.win.protocol("WM_DELETE_WINDOW", self._close)
        self._safe_after(300, self._qr_refresh)

    def _safe_config(self, widget, **kwargs):
        if self.destroyed:
            return
        try:
            if widget.winfo_exists():
                widget.config(**kwargs)
        except Exception:
            pass

    def _set_status(self, widget, text, color):
        if self.destroyed:
            return

        def _apply():
            self._safe_config(widget, text=text, fg=color)
        self._safe_after(0, _apply)

    def _set_url_label(self, label, url):
        if self.destroyed:
            return

        def _apply():
            try:
                if not label.winfo_exists():
                    return
                label.config(text=f"{url}   （点击复制）")

                def _copy(_e=None):
                    if self.destroyed:
                        return
                    try:
                        self.win.clipboard_clear()
                        self.win.clipboard_append(url)
                        self._set_status(label, "已复制到剪贴板", ACCENT)
                    except Exception:
                        pass
                label.bind("<Button-1>", _copy)
            except Exception:
                pass
        self._safe_after(0, _apply)

    def _ensure_cid_values(self):
        if self._cid_values is not None:
            return
        try:
            values, default_text, code_map = _build_cid_values("86")
            self._cid_values = values
            self._cid_map = code_map
            self._cid_default = default_text
        except Exception as e:
            log(f"加载区号列表失败: {e}", "AUTH", show=False)
            self._cid_values = ["+86  中国大陆"]
            self._cid_map = {"+86  中国大陆": "86"}
            self._cid_default = "+86  中国大陆"

    def _get_cid_value(self):
        try:
            txt = self.sms_cid.get().strip()
        except Exception:
            return "86"
        if self._cid_map and txt in self._cid_map:
            return self._cid_map[txt]
        m = re.match(r"^\+?(\d+)", txt)
        return m.group(1) if m else "86"

    def _close(self):
        self.destroyed = True
        self.qr_polling = False
        if self._sms_cd_timer:
            try:
                self.win.after_cancel(self._sms_cd_timer)
            except Exception:
                pass
            self._sms_cd_timer = None
        try:
            self.win.destroy()
        except Exception:
            pass

    # ---------- 扫码 ----------
    def _build_qr_tab(self):
        tab = tk.Frame(self.nb, bg=BG_PANEL)
        self.nb.add(tab, text=" 扫码登录 ")

        tk.Label(tab, text="使用 B 站手机 APP 扫描二维码",
                 fg=FG_MAIN, bg=BG_PANEL, font=FONT_HEAD).pack(pady=(18, 10))

        qr_frame = tk.Frame(tab, bg="#ffffff", width=260, height=260)
        qr_frame.pack(pady=6)
        qr_frame.pack_propagate(False)
        self.qr_label = tk.Label(qr_frame, bg="#ffffff",
                                 text="二维码加载中...", fg="#7f8c8d",
                                 font=FONT_BODY)
        self.qr_label.pack(fill=tk.BOTH, expand=True)

        self.qr_status = tk.Label(tab, text="正在获取二维码...",
                                  fg=ACCENT, bg=BG_PANEL, font=FONT_BODY)
        self.qr_status.pack(pady=8)

        tk.Button(tab, text="刷新二维码", command=self._qr_refresh,
                  bg=BTN_INFO, fg="#ffffff",
                  activebackground=BTN_INFO_HOVER, activeforeground="#ffffff",
                  font=FONT_BTN, relief=tk.FLAT, padx=20, pady=6,
                  cursor="hand2", bd=0).pack(pady=6)

    def _qr_refresh(self):
        if self.destroyed:
            return
        self.qr_polling = False
        self._safe_config(self.qr_status, text="正在获取二维码...", fg=ACCENT)
        threading.Thread(target=self._qr_worker, daemon=True).start()

    def _qr_worker(self):
        loop = asyncio.new_event_loop()
        try:
            data = loop.run_until_complete(auth.api_qrcode_generate())
            if self.destroyed:
                return
            if data.get("code") != 0:
                self._set_status(self.qr_status,
                                 f"获取失败: {data.get('message')}",
                                 BTN_DANGER)
                return
            url = data["data"]["url"]
            key = data["data"]["qrcode_key"]
            log("已获取登录二维码", "AUTH")
            img = qrcode.make(url).resize((240, 240))
            self._safe_after(0, self._qr_show, img)
            self.qr_polling = True
            asyncio.set_event_loop(loop)
            loop.run_until_complete(self._qr_poll(key))
        except Exception:
            pass
        finally:
            try:
                loop.close()
            except Exception:
                pass

    def _qr_show(self, img):
        if self.destroyed:
            return
        try:
            if not self.qr_label.winfo_exists():
                return
            photo = ImageTk.PhotoImage(img, master=self.win)
            self.qr_photo = photo
            self.qr_label.config(image=photo, text="")
            self._set_status(self.qr_status, "请使用手机 APP 扫码", ACCENT)
        except Exception as e:
            self._set_status(self.qr_status, f"渲染失败: {e}", BTN_DANGER)

    async def _qr_poll(self, key):
        last = ""
        while self.qr_polling and not self.destroyed:
            try:
                data, ck = await auth.api_qrcode_poll(key)
                code = (data.get("data") or {}).get("code")
                if code == 0:
                    final = self._parse_qr_url(
                        data["data"].get("url", "")) or ck
                    self.qr_polling = False
                    log("扫码确认成功", "AUTH")
                    self._safe_after(0, self._login_success,
                                     final, "扫码登录")
                    return
                elif code == 86038:
                    self._set_status(self.qr_status,
                                     "二维码已失效，请刷新", BTN_DANGER)
                    self.qr_polling = False
                    return
                elif code == 86090:
                    if last != "scanned":
                        self._set_status(self.qr_status,
                                         "已扫码，请在手机确认", BTN_WARN)
                        log("用户已扫码，等待手机确认", "AUTH")
                        last = "scanned"
            except Exception:
                pass
            await asyncio.sleep(2)

    def _parse_qr_url(self, url):
        if not url:
            return {}
        try:
            q = urllib.parse.urlparse(url).query
            p = urllib.parse.parse_qs(q)
            return {k: p[k][0] for k in
                    ("DedeUserID", "DedeUserID__ckMd5", "SESSDATA", "bili_jct")
                    if k in p and p[k]}
        except Exception:
            return {}

    # ---------- 密码 ----------
    def _build_password_tab(self):
        tab = tk.Frame(self.nb, bg=BG_PANEL)
        self.nb.add(tab, text=" 密码登录 ")

        tk.Label(tab, text="输入 B 站账号密码，浏览器完成人机验证",
                 fg=FG_MAIN, bg=BG_PANEL, font=FONT_HEAD).pack(pady=(18, 4))
        tk.Label(tab, text="账号支持：用户名 / 手机号 / 邮箱",
                 fg=FG_SUB, bg=BG_PANEL, font=FONT_SMALL).pack()

        tk.Label(tab, text="用户名或手机号", fg=FG_SUB, bg=BG_PANEL,
                 font=FONT_SMALL, anchor=tk.W).pack(
            fill=tk.X, padx=40, pady=(20, 4))
        user_wrap = tk.Frame(tab, bg=BG_INPUT,
                             highlightthickness=1,
                             highlightbackground=BG_BORDER)
        user_wrap.pack(fill=tk.X, padx=40)
        self.pwd_user = tk.Entry(user_wrap, bg=BG_INPUT, fg=FG_MAIN,
                                  insertbackground=ACCENT, font=FONT_BODY,
                                  relief=tk.FLAT, bd=0)
        self.pwd_user.pack(fill=tk.X, padx=12, pady=8)

        tk.Label(tab, text="密码", fg=FG_SUB, bg=BG_PANEL,
                 font=FONT_SMALL, anchor=tk.W).pack(
            fill=tk.X, padx=40, pady=(12, 4))
        pwd_wrap = tk.Frame(tab, bg=BG_INPUT,
                            highlightthickness=1,
                            highlightbackground=BG_BORDER)
        pwd_wrap.pack(fill=tk.X, padx=40)
        self.pwd_pass = tk.Entry(pwd_wrap, bg=BG_INPUT, fg=FG_MAIN,
                                  insertbackground=ACCENT, font=FONT_BODY,
                                  relief=tk.FLAT, bd=0, show="●")
        self.pwd_pass.pack(fill=tk.X, padx=12, pady=8)

        self.pwd_status = tk.Label(tab, text="", fg=FG_SUB, bg=BG_PANEL,
                                    font=FONT_SMALL, wraplength=580,
                                    justify=tk.LEFT)
        self.pwd_status.pack(fill=tk.X, padx=40, pady=(12, 0))

        self.pwd_url = tk.Label(tab, text="", fg=ACCENT, bg=BG_PANEL,
                                 font=FONT_SMALL, cursor="hand2",
                                 wraplength=580, justify=tk.LEFT)
        self.pwd_url.pack(fill=tk.X, padx=40, pady=(4, 0))

        self.pwd_btn = tk.Button(tab, text="开始登录",
                                  command=self._pwd_start,
                                  bg=BTN_PRIMARY, fg="#0f1a20",
                                  activebackground=BTN_PRIMARY_HOVER,
                                  activeforeground="#ffffff",
                                  font=FONT_BTN, relief=tk.FLAT,
                                  padx=32, pady=8, cursor="hand2", bd=0)
        self.pwd_btn.pack(pady=18)

        self.pwd_user.bind("<Return>", lambda e: self.pwd_pass.focus())
        self.pwd_pass.bind("<Return>", lambda e: self._pwd_start())

    def _pwd_start(self):
        if self.destroyed:
            return
        if not login_bridge or not do_password_login:
            self._safe_msgbox("showerror", "错误",
                              "auth 模块未加载极验登录功能")
            return

        username = self.pwd_user.get().strip()
        password = self.pwd_pass.get()
        if not username:
            self._set_status(self.pwd_status, "请输入账号", BTN_DANGER)
            return
        if not password:
            self._set_status(self.pwd_status, "请输入密码", BTN_DANGER)
            return

        self.pwd_btn.config(state=tk.DISABLED)
        self.pwd_url.config(text="")

        if not login_bridge.start():
            self._set_status(self.pwd_status, "验证服务启动失败", BTN_DANGER)
            self._restore_pwd_inputs()
            return

        url = login_bridge.get_login_url()
        self._set_url_label(self.pwd_url, url)
        self._set_status(self.pwd_status,
                          "请在浏览器打开上方地址完成人机验证...",
                          BTN_WARN)
        try:
            login_bridge.open_in_browser()
        except Exception:
            pass

        pwd_snapshot = (username, password)

        self._wait_geetest_then(
            lambda g: do_password_login(pwd_snapshot[0],
                                        pwd_snapshot[1], g),
            on_done=self._pwd_done,
            on_error=self._pwd_error,
        )

    def _pwd_done(self, res):
        if self.destroyed:
            return
        if res.get("ok"):
            self._set_status(self.pwd_status, "登录成功", ACCENT)
            self._save_cookies_and_close(res.get("cookies", {}),
                                          res.get("info", {}),
                                          "密码登录")
            return

        if res.get("risk_url"):
            try:
                webbrowser.open(res["risk_url"])
            except Exception:
                pass
            self._set_status(
                self.pwd_status,
                "检测到登录环境风险，已尝试打开手机验证页面",
                BTN_DANGER)
        else:
            self._set_status(self.pwd_status,
                              f"登录失败: {res.get('msg', '')}",
                              BTN_DANGER)
        self._restore_pwd_inputs()

    def _pwd_error(self, e):
        if self.destroyed:
            return
        self._set_status(self.pwd_status, f"错误: {e}", BTN_DANGER)
        self._restore_pwd_inputs()

    def _restore_pwd_inputs(self):
        try:
            if self.pwd_btn.winfo_exists():
                self.pwd_btn.config(state=tk.NORMAL)
        except Exception:
            pass

    # ---------- 短信 ----------
    def _build_sms_tab(self):
        tab = tk.Frame(self.nb, bg=BG_PANEL)
        self.nb.add(tab, text=" 短信登录 ")

        tk.Label(tab, text="手机号登录，浏览器完成人机验证",
                 fg=FG_MAIN, bg=BG_PANEL, font=FONT_HEAD).pack(pady=(18, 4))
        tk.Label(tab, text="选择国际区号，填写手机号；手机号和验证码全程可输入",
                 fg=FG_SUB, bg=BG_PANEL, font=FONT_SMALL).pack()

        tk.Label(tab, text="手机号", fg=FG_SUB, bg=BG_PANEL,
                 font=FONT_SMALL, anchor=tk.W).pack(
            fill=tk.X, padx=40, pady=(20, 4))

        phone_row = tk.Frame(tab, bg=BG_PANEL)
        phone_row.pack(fill=tk.X, padx=40)

        cid_wrap = tk.Frame(phone_row, bg=BG_BORDER, bd=0)
        cid_wrap.pack(side=tk.LEFT, padx=(0, 8))

        cid_inner = tk.Frame(cid_wrap, bg=BG_INPUT, bd=0)
        cid_inner.pack(padx=1, pady=1)

        self.sms_cid = ttk.Combobox(
            cid_inner, values=[], width=14, state="normal",
            font=FONT_BODY, style="Dialog.TCombobox",
            cursor="hand2")
        self.sms_cid.pack(fill=tk.BOTH, expand=True)
        self._safe_after(100, self._lazy_load_cid_sms)

        tel_wrap = tk.Frame(phone_row, bg=BG_INPUT,
                            highlightthickness=1,
                            highlightbackground=BG_BORDER)
        tel_wrap.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))
        self.sms_tel = tk.Entry(tel_wrap, bg=BG_INPUT, fg=FG_MAIN,
                                 insertbackground=ACCENT, font=FONT_BODY,
                                 relief=tk.FLAT, bd=0)
        self.sms_tel.pack(fill=tk.X, padx=12, pady=8)

        self.sms_send_btn = tk.Button(
            phone_row, text="发送验证码",
            command=self._sms_send,
            bg=BTN_INFO, fg="#ffffff",
            activebackground=BTN_INFO_HOVER, activeforeground="#ffffff",
            font=FONT_BTN, relief=tk.FLAT,
            padx=14, pady=8, cursor="hand2", bd=0)
        self.sms_send_btn.pack(side=tk.LEFT)

        tk.Label(tab,
                 text="提示：区号可从下拉选择，也可以直接输入数字（如 86、1、852）",
                 fg=FG_SUB, bg=BG_PANEL, font=FONT_SMALL,
                 anchor=tk.W).pack(fill=tk.X, padx=40, pady=(2, 0))

        tk.Label(tab, text="验证码", fg=FG_SUB, bg=BG_PANEL,
                 font=FONT_SMALL, anchor=tk.W).pack(
            fill=tk.X, padx=40, pady=(14, 4))
        code_row = tk.Frame(tab, bg=BG_PANEL)
        code_row.pack(fill=tk.X, padx=40)

        code_wrap = tk.Frame(code_row, bg=BG_INPUT,
                             highlightthickness=1,
                             highlightbackground=BG_BORDER)
        code_wrap.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.sms_code = tk.Entry(code_wrap, bg=BG_INPUT, fg=FG_MAIN,
                                  insertbackground=ACCENT, font=FONT_BODY,
                                  relief=tk.FLAT, bd=0)
        self.sms_code.pack(fill=tk.X, padx=12, pady=8)

        self.sms_login_btn = tk.Button(
            code_row, text="登录",
            command=self._sms_login,
            bg=BTN_PRIMARY, fg="#0f1a20",
            activebackground=BTN_PRIMARY_HOVER,
            activeforeground="#ffffff",
            font=FONT_BTN, relief=tk.FLAT,
            padx=24, pady=8, cursor="hand2", bd=0,
            state=tk.DISABLED)
        self.sms_login_btn.pack(side=tk.LEFT, padx=(8, 0))

        self.sms_status = tk.Label(tab, text="", fg=FG_SUB, bg=BG_PANEL,
                                    font=FONT_SMALL, wraplength=580,
                                    justify=tk.LEFT)
        self.sms_status.pack(fill=tk.X, padx=40, pady=(14, 0))

        self.sms_url = tk.Label(tab, text="", fg=ACCENT, bg=BG_PANEL,
                                 font=FONT_SMALL, cursor="hand2",
                                 wraplength=580, justify=tk.LEFT)
        self.sms_url.pack(fill=tk.X, padx=40, pady=(4, 0))

        self.sms_tel.bind("<Return>", lambda e: self.sms_code.focus())
        self.sms_code.bind("<Return>", lambda e: self._sms_login())

    def _lazy_load_cid_sms(self):
        if self.destroyed:
            return
        try:
            self._ensure_cid_values()
            if self.sms_cid.winfo_exists():
                self.sms_cid["values"] = self._cid_values
                if not self.sms_cid.get():
                    self.sms_cid.set(self._cid_default)
        except Exception as e:
            log(f"短信区号加载失败: {e}", "AUTH", show=False)

    def _sms_send(self):
        if self.destroyed:
            return
        if not login_bridge:
            self._safe_msgbox("showerror", "错误",
                              "auth 模块未加载极验登录功能")
            return
        tel = self.sms_tel.get().strip()
        tel = re.sub(r"^0+", "", tel)
        tel = re.sub(r"\D", "", tel)
        cid = self._get_cid_value()

        if not tel or not tel.isdigit() or not (6 <= len(tel) <= 15):
            self._set_status(self.sms_status,
                              "手机号格式错误（去掉前导 0，只保留数字）",
                              BTN_DANGER)
            return

        self.sms_send_btn.config(state=tk.DISABLED, text="发送中...")
        self.sms_url.config(text="")
        self._sms_captcha_key = ""
        self.sms_login_btn.config(state=tk.DISABLED)

        if not login_bridge.start():
            self._set_status(self.sms_status, "验证服务启动失败", BTN_DANGER)
            self.sms_send_btn.config(state=tk.NORMAL, text="发送验证码")
            return

        url = login_bridge.get_login_url()
        self._set_url_label(self.sms_url, url)
        self._set_status(self.sms_status,
                          "请在浏览器打开上方地址完成人机验证...",
                          BTN_WARN)
        try:
            login_bridge.open_in_browser()
        except Exception:
            pass

        self._sms_phone = tel
        self._sms_cid_value = cid

        self._wait_geetest_then(
            lambda g: auth.api_sms_send(cid, tel, g["token"],
                                         g["challenge"],
                                         g["validate"], g["seccode"]),
            on_done=self._sms_send_done,
            on_error=self._sms_send_error,
        )

    def _sms_send_done(self, res):
        if self.destroyed:
            return
        try:
            self.sms_send_btn.config(state=tk.NORMAL, text="发送验证码")
        except Exception:
            pass
        if res.get("code") == 0:
            self._sms_captcha_key = (res.get("data") or {}).get(
                "captcha_key", "")
            self._set_status(self.sms_status,
                              "短信已发送，请查看手机", ACCENT)
            self.sms_login_btn.config(state=tk.NORMAL)
            try:
                self.sms_code.focus_set()
            except Exception:
                pass
            self._start_sms_cd(60)
        else:
            self._set_status(self.sms_status,
                              f"发送失败: [{res.get('code')}] "
                              f"{res.get('message', '')}",
                              BTN_DANGER)

    def _sms_send_error(self, e):
        if self.destroyed:
            return
        try:
            self.sms_send_btn.config(state=tk.NORMAL, text="发送验证码")
        except Exception:
            pass
        self._set_status(self.sms_status, f"错误: {e}", BTN_DANGER)

    def _start_sms_cd(self, seconds):
        self._sms_cd_left = seconds
        self._update_sms_cd()

    def _update_sms_cd(self):
        if self.destroyed:
            return
        if self._sms_cd_left <= 0:
            try:
                if self.sms_send_btn.winfo_exists():
                    self.sms_send_btn.config(state=tk.NORMAL,
                                              text="发送验证码")
            except Exception:
                pass
            self._sms_cd_timer = None
            return
        try:
            if self.sms_send_btn.winfo_exists():
                self.sms_send_btn.config(
                    state=tk.DISABLED,
                    text=f"{self._sms_cd_left}s 后重发")
        except Exception:
            pass
        self._sms_cd_left -= 1
        self._sms_cd_timer = self._safe_after(1000, self._update_sms_cd)

    def _sms_login(self):
        if self.destroyed:
            return
        if not self._sms_captcha_key:
            self._set_status(self.sms_status, "请先发送验证码", BTN_DANGER)
            return
        code = self.sms_code.get().strip()
        code = re.sub(r"\D", "", code)
        if not code:
            self._set_status(self.sms_status, "请输入验证码", BTN_DANGER)
            return

        self.sms_login_btn.config(state=tk.DISABLED, text="登录中...")

        def _on_done(res_tuple):
            if self.destroyed:
                return
            try:
                if self.sms_login_btn.winfo_exists():
                    self.sms_login_btn.config(state=tk.NORMAL, text="登录")
            except Exception:
                pass
            res, ck = res_tuple
            if res.get("code") == 0 and ck:
                self._set_status(self.sms_status, "登录成功", ACCENT)
                self._save_cookies_and_close(ck, {}, "短信登录")
            else:
                self._set_status(self.sms_status,
                                  f"登录失败: [{res.get('code')}] "
                                  f"{res.get('message', '')}",
                                  BTN_DANGER)

        def _on_error(e):
            if self.destroyed:
                return
            try:
                if self.sms_login_btn.winfo_exists():
                    self.sms_login_btn.config(state=tk.NORMAL, text="登录")
            except Exception:
                pass
            self._set_status(self.sms_status, f"错误: {e}", BTN_DANGER)

        self._run_async(
            auth.api_sms_login(self._sms_cid_value,
                                self._sms_phone,
                                code,
                                self._sms_captcha_key),
            _on_done, _on_error)

    # ---------- Cookie ----------
    def _build_cookie_tab(self):
        tab = tk.Frame(self.nb, bg=BG_PANEL)
        self.nb.add(tab, text=" Cookie 登录 ")

        tk.Label(tab, text="从浏览器复制 Cookie 粘贴到下方",
                 fg=FG_MAIN, bg=BG_PANEL, font=FONT_HEAD).pack(pady=(18, 4))
        tk.Label(tab,
                 text="必填：SESSDATA、bili_jct、DedeUserID、DedeUserID__ckMd5",
                 fg=FG_SUB, bg=BG_PANEL, font=FONT_SMALL).pack(pady=(0, 2))
        tk.Label(tab,
                 text='格式：SESSDATA=xxx; bili_jct=xxx; DedeUserID=xxx; ...',
                 fg=FG_SUB, bg=BG_PANEL, font=FONT_SMALL).pack(pady=(0, 10))

        wrap = tk.Frame(tab, bg=BG_INPUT, highlightthickness=0)
        wrap.pack(fill=tk.BOTH, expand=True, padx=24, pady=6)
        self.cookie_text = tk.Text(wrap, height=12, bg=BG_INPUT, fg=FG_MAIN,
                                    insertbackground=ACCENT,
                                    font=FONT_MONO,
                                    relief=tk.FLAT, bd=0,
                                    wrap=tk.WORD, padx=12, pady=10)
        self.cookie_text.pack(fill=tk.BOTH, expand=True)

        self.cookie_status = tk.Label(tab, text="", fg=ACCENT, bg=BG_PANEL,
                                       font=FONT_BODY, wraplength=580)
        self.cookie_status.pack(pady=6)

        tk.Button(tab, text="登 录", command=self._cookie_login,
                  bg=BTN_PRIMARY, fg="#0f1a20",
                  activebackground=BTN_PRIMARY_HOVER,
                  activeforeground="#ffffff",
                  font=FONT_BTN, relief=tk.FLAT, padx=40, pady=8,
                  cursor="hand2", bd=0).pack(pady=10)

    def _parse_cookie_text(self, text):
        d = {}
        text = text.strip()
        if text.startswith("{"):
            try:
                obj = json.loads(text)
                for k, v in obj.items():
                    if isinstance(v, str):
                        d[k] = v
                return d
            except Exception:
                pass
        for chunk in re.split(r"[;\n]+", text):
            chunk = chunk.strip()
            if not chunk:
                continue
            if "=" in chunk:
                k, v = chunk.split("=", 1)
                d[k.strip()] = v.strip()
        return d

    def _cookie_login(self):
        if self.destroyed:
            return
        text = self.cookie_text.get("1.0", tk.END).strip()
        if not text:
            self._safe_msgbox("showwarning", "提示", "请粘贴 Cookie")
            return
        ck = self._parse_cookie_text(text)
        required = ["SESSDATA", "bili_jct", "DedeUserID", "DedeUserID__ckMd5"]
        missing = [k for k in required if not ck.get(k)]
        if missing:
            self._safe_msgbox("showerror", "缺少字段",
                              "缺少必要字段：\n" + ", ".join(missing))
            return
        self._safe_config(self.cookie_status, text="验证中...", fg=BTN_WARN)
        log(f"Cookie 登录请求: UID={ck.get('DedeUserID')}", "AUTH")

        def _do():
            old = account.get_cookie_dict().copy()
            merged = dict(old)
            merged.update(ck)
            if not account.save_cookies(merged):
                self._set_status(self.cookie_status, "保存失败", BTN_DANGER)
                return
            account.reload_headers()
            loop = asyncio.new_event_loop()
            info = {}
            try:
                info = loop.run_until_complete(auth.fetch_account_info())
            except Exception as e:
                log_err(f"Cookie 验证异常: {e}")
            finally:
                try:
                    loop.close()
                except Exception:
                    pass
            if not info or not info.get("is_login"):
                account.save_cookies(old)
                account.reload_headers()
                self._set_status(self.cookie_status,
                                 "Cookie 无效或已过期", BTN_DANGER)
                return
            account.add_or_update_account(merged, info)
            log(f"Cookie 登录成功: {info.get('uname')} "
                f"(UID={info.get('mid')})", "AUTH")
            self._set_status(self.cookie_status, "登录成功", ACCENT)
            try:
                self.on_saved()
            except Exception:
                pass

            def _ui_done():
                if self.destroyed:
                    return
                self._safe_msgbox("showinfo", "成功",
                                  f"登录成功：{info.get('uname')}")
                self._safe_after(500, self._close)
            self._safe_after(0, _ui_done)

        threading.Thread(target=_do, daemon=True).start()

    def _login_success(self, ck, method):
        if self.destroyed:
            return
        if not ck or not ck.get("SESSDATA"):
            self._safe_msgbox("showerror", "登录失败", "未获取到 SESSDATA")
            return
        self._save_cookies_and_close(ck, {}, method)

    def _save_cookies_and_close(self, ck, info, method):
        if not ck or not ck.get("SESSDATA"):
            log_err(f"{method} 未拿到有效 cookie")
            return
        merged = dict(account.get_cookie_dict())
        merged.update(ck)
        if not account.save_cookies(merged):
            self._safe_msgbox("showerror", "错误", "保存失败")
            return
        account.reload_headers()
        log(f"登录成功: {method}", "AUTH")

        def _post():
            loop = asyncio.new_event_loop()
            try:
                if not info or not info.get("is_login"):
                    info2 = loop.run_until_complete(
                        auth.fetch_account_info())
                else:
                    info2 = info
                if info2.get("is_login"):
                    account.add_or_update_account(merged, info2)
                    log(f"账号已保存: {info2.get('uname')} "
                        f"(UID={info2.get('mid')})", "AUTH")
            except Exception as e:
                log_err(f"获取账号信息失败: {e}")
            finally:
                try:
                    loop.close()
                except Exception:
                    pass

            def _ui():
                if self.destroyed:
                    return
                try:
                    self.on_saved()
                except Exception:
                    pass
                self._safe_msgbox("showinfo", "成功", f"{method}成功")
                self._close()

            self._safe_after(0, _ui)

        threading.Thread(target=_post, daemon=True).start()

    def _wait_geetest_then(self, coro_factory, on_done, on_error=None):
        def _worker():
            try:
                g = login_bridge.wait_geetest(timeout=300)
                if not g:
                    if not self.destroyed:
                        err = Exception("人机验证超时，请重试")
                        self._safe_after(0, lambda: on_error(err))
                    return
                loop = asyncio.new_event_loop()
                try:
                    result = loop.run_until_complete(coro_factory(g))
                finally:
                    try:
                        loop.close()
                    except Exception:
                        pass
                self._safe_after(0, lambda: on_done(result))
            except Exception as e:
                if on_error:
                    self._safe_after(0, lambda e=e: on_error(e))

        threading.Thread(target=_worker, daemon=True).start()

    def _run_async(self, coro, on_done, on_error=None):
        def _worker():
            loop = asyncio.new_event_loop()
            try:
                result = loop.run_until_complete(coro)
                self._safe_after(0, lambda: on_done(result))
            except Exception as e:
                if on_error:
                    self._safe_after(0, lambda e=e: on_error(e))
            finally:
                try:
                    loop.close()
                except Exception:
                    pass

        threading.Thread(target=_worker, daemon=True).start()


# ============================================================
#  账号管理对话框（含 IP 属地 + 粉丝团灯牌 + 高级功能）
# ============================================================
class AccountDialog(_SafeToplevelMixin):
    def __init__(self, parent, callbacks, refresh_ui_cb=None):
        self.callbacks = callbacks
        self.destroyed = False
        self._photos = {}
        self._pending = set()

        self._medal_items = []
        self._medal_search_var = None
        self._medal_list_inner = None
        self._medal_canvas_window = None
        self._medal_status_lbl = None

        # 搜索防抖 / 缓存
        self._medal_search_after_id = None
        self._medal_last_kw = None
        self._medal_max_render = 300

        self.win = tk.Toplevel(parent)
        self.win.title("账号管理")
        self.win.configure(bg=BG_MAIN)
        self.win.transient(parent)
        _center(self.win, 760, 800)

        _ensure_dialog_style()
        _install_combobox_listbox_style(self.win)

        header = tk.Frame(self.win, bg=BG_MAIN)
        header.pack(fill=tk.X, padx=24, pady=(20, 6))
        tk.Label(header, text="账号管理", fg=ACCENT, bg=BG_MAIN,
                 font=FONT_TITLE).pack(anchor=tk.W)
        tk.Label(header, text="管理账号 · 粉丝团灯牌 · 高级功能",
                 fg=FG_SUB, bg=BG_MAIN, font=FONT_SMALL).pack(
            anchor=tk.W, pady=(2, 0))

        # IP 属地显示
        self.ip_zone_frame = tk.Frame(self.win, bg=BG_MAIN)
        self.ip_zone_frame.pack(fill=tk.X, padx=24, pady=(4, 0))

        self.ip_zone_lbl = tk.Label(
            self.ip_zone_frame, text="正在获取 IP 属地...",
            fg=FG_SUB, bg=BG_MAIN, font=FONT_SMALL, anchor=tk.W)
        self.ip_zone_lbl.pack(fill=tk.X)

        self.ip_zone_detail_lbl = tk.Label(
            self.ip_zone_frame, text="",
            fg=FG_DIM, bg=BG_MAIN, font=FONT_TINY, anchor=tk.W)
        self.ip_zone_detail_lbl.pack(fill=tk.X, pady=(1, 0))

        ip_btn_row = tk.Frame(self.win, bg=BG_MAIN)
        ip_btn_row.pack(fill=tk.X, padx=24, pady=(2, 0))
        tk.Button(ip_btn_row, text="刷新 IP 属地", command=self._load_ip_zone,
                  bg=BG_CARD, fg=FG_SUB,
                  activebackground=BG_PANEL, activeforeground=ACCENT,
                  font=FONT_TINY, relief=tk.FLAT, bd=0,
                  padx=8, pady=2, cursor="hand2").pack(side=tk.LEFT)

        nb = ttk.Notebook(self.win, style="Dialog.TNotebook")
        nb.pack(fill=tk.BOTH, expand=True, padx=20, pady=8)

        tab_account = tk.Frame(nb, bg=BG_MAIN)
        nb.add(tab_account, text="  账号管理  ")
        self._build_account_tab(tab_account)

        tab_medal = tk.Frame(nb, bg=BG_MAIN)
        nb.add(tab_medal, text="  选择粉丝团灯牌  ")
        self._build_medal_tab(tab_medal)

        tab_advanced = tk.Frame(nb, bg=BG_MAIN)
        nb.add(tab_advanced, text="  高级功能  ")
        self._build_advanced_tab(tab_advanced)

        self._build_bottom_bar()

        self.win.protocol("WM_DELETE_WINDOW", self._close)

        self._refresh()
        self._safe_after(200, lambda: self._load_medals(force=False))
        self._safe_after(100, self._load_ip_zone)

    # ------------------------------------------------------------------
    #  IP 属地
    # ------------------------------------------------------------------
    def _load_ip_zone(self):
        if self.destroyed:
            return
        try:
            if self.ip_zone_lbl.winfo_exists():
                self.ip_zone_lbl.config(text="正在获取 IP 属地...",
                                         fg=FG_SUB)
            if self.ip_zone_detail_lbl.winfo_exists():
                self.ip_zone_detail_lbl.config(text="")
        except Exception:
            pass

        def _worker():
            try:
                loop = asyncio.new_event_loop()
                try:
                    info = loop.run_until_complete(_fetch_ip_zone())
                finally:
                    try:
                        loop.close()
                    except Exception:
                        pass
            except Exception:
                info = None
            self._safe_after(0, lambda: self._on_ip_zone_ready(info))

        threading.Thread(target=_worker, daemon=True,
                         name="ip-zone-fetch").start()

    def _on_ip_zone_ready(self, info):
        if self.destroyed:
            return
        if not info:
            try:
                if self.ip_zone_lbl.winfo_exists():
                    self.ip_zone_lbl.config(text="IP 属地获取失败",
                                             fg=FG_SUB)
            except Exception:
                pass
            return

        try:
            short, details = _fmt_ip_zone(info)
            if self.ip_zone_lbl.winfo_exists():
                self.ip_zone_lbl.config(text=short, fg=ACCENT)
            if self.ip_zone_detail_lbl.winfo_exists():
                self.ip_zone_detail_lbl.config(text=details or "")
        except Exception as e:
            log_err(f"渲染 IP 属地失败: {e}")

    def _close(self):
        self.destroyed = True
        try:
            if self._medal_search_after_id:
                self.win.after_cancel(self._medal_search_after_id)
        except Exception:
            pass
        self._medal_search_after_id = None
        # ★ 解绑红包/天选回调，避免刷新已销毁控件
        try:
            from red_packet import red_packet_manager
            if red_packet_manager.on_status_update == self._on_rp_status_change:
                red_packet_manager.on_status_update = None
            if red_packet_manager.on_stats_update == self._on_rp_stats_change:
                red_packet_manager.on_stats_update = None
            if red_packet_manager.on_log == self._on_rp_log:
                red_packet_manager.on_log = None
            if red_packet_manager.on_anchor_status_update == \
                    self._on_anchor_status_change:
                red_packet_manager.on_anchor_status_update = None
        except Exception:
            pass
        try:
            self.win.destroy()
        except Exception:
            pass

    # ------------------------------------------------------------------
    #  Tab 1：账号管理
    # ------------------------------------------------------------------
    def _build_account_tab(self, parent):
        self.current_frame = tk.Frame(parent, bg=BG_CARD)
        self.current_frame.pack(fill=tk.X, padx=12, pady=10)

        tk.Label(parent, text="已保存账号", fg=ACCENT, bg=BG_MAIN,
                 font=FONT_HEAD).pack(anchor=tk.W, padx=16, pady=(6, 4))

        list_frame = tk.Frame(parent, bg=BG_MAIN)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=12, pady=4)
        self.canvas = tk.Canvas(list_frame, bg=BG_PANEL,
                                 highlightthickness=0)
        sb = tk.Scrollbar(list_frame, orient=tk.VERTICAL,
                          command=self.canvas.yview)
        self.list_inner = tk.Frame(self.canvas, bg=BG_PANEL)
        self.list_inner.bind(
            "<Configure>",
            lambda e: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")))
        self.canvas.create_window((0, 0), window=self.list_inner,
                                   anchor=tk.NW)
        self.canvas.configure(yscrollcommand=sb.set)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sb.pack(side=tk.RIGHT, fill=tk.Y)

    # ------------------------------------------------------------------
    #  Tab 2：粉丝团灯牌
    # ------------------------------------------------------------------
    def _build_medal_tab(self, parent):
        title_row = tk.Frame(parent, bg=BG_MAIN)
        title_row.pack(fill=tk.X, padx=12, pady=(12, 4))
        tk.Label(title_row, text="我的粉丝团灯牌", fg=ACCENT, bg=BG_MAIN,
                 font=FONT_HEAD).pack(anchor=tk.W)
        tk.Label(title_row,
                 text="点击「佩戴」切换当前显示的勋章（需已登录）",
                 fg=FG_SUB, bg=BG_MAIN, font=FONT_SMALL).pack(
            anchor=tk.W, pady=(2, 0))

        search_row = tk.Frame(parent, bg=BG_MAIN)
        search_row.pack(fill=tk.X, padx=12, pady=(8, 4))

        tk.Label(search_row, text="搜索", fg=FG_SUB, bg=BG_MAIN,
                 font=FONT_SMALL).pack(side=tk.LEFT, padx=(0, 6))

        search_wrap = tk.Frame(search_row, bg=BG_INPUT,
                                highlightthickness=1,
                                highlightbackground=BG_BORDER)
        search_wrap.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self._medal_search_var = tk.StringVar()
        self._medal_search_var.trace_add(
            "write", self._on_medal_search_changed)

        tk.Entry(
            search_wrap, textvariable=self._medal_search_var,
            bg=BG_INPUT, fg=FG_MAIN, insertbackground=ACCENT,
            font=FONT_BODY, relief=tk.FLAT, bd=0).pack(
            fill=tk.X, padx=10, pady=6)

        tk.Button(search_row, text="清空",
                  command=lambda: self._medal_search_var.set(""),
                  bg=BTN_NEUTRAL, fg="#ffffff",
                  activebackground=BTN_NEUTRAL_HOVER,
                  activeforeground="#ffffff",
                  font=FONT_SMALL, relief=tk.FLAT,
                  padx=10, pady=4, cursor="hand2",
                  bd=0).pack(side=tk.LEFT, padx=(6, 0))
        tk.Button(search_row, text="刷新",
                  command=lambda: self._load_medals(force=True),
                  bg=BTN_INFO, fg="#ffffff",
                  activebackground=BTN_INFO_HOVER,
                  activeforeground="#ffffff",
                  font=FONT_SMALL, relief=tk.FLAT,
                  padx=10, pady=4, cursor="hand2",
                  bd=0).pack(side=tk.LEFT, padx=(6, 0))

        list_wrap = tk.Frame(parent, bg=BG_PANEL,
                              highlightthickness=1,
                              highlightbackground=BG_BORDER)
        list_wrap.pack(fill=tk.BOTH, expand=True, padx=12, pady=(4, 4))

        canvas = tk.Canvas(list_wrap, bg=BG_PANEL,
                            highlightthickness=0, bd=0)
        sb = tk.Scrollbar(list_wrap, orient=tk.VERTICAL,
                           command=canvas.yview,
                           bg=BG_PANEL, troughcolor=BG_PANEL,
                           activebackground=BG_BORDER, bd=0,
                           highlightthickness=0, width=8, relief=tk.FLAT)
        self._medal_list_inner = tk.Frame(canvas, bg=BG_PANEL)
        self._medal_list_inner.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        self._medal_canvas_window = canvas.create_window(
            (0, 0), window=self._medal_list_inner, anchor=tk.NW)
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sb.pack(side=tk.RIGHT, fill=tk.Y)

        def _on_canvas_resize(e):
            try:
                canvas.itemconfigure(self._medal_canvas_window,
                                      width=e.width)
            except Exception:
                pass
        canvas.bind("<Configure>", _on_canvas_resize)

        self._medal_status_lbl = tk.Label(
            parent, text="加载中...", fg=FG_SUB, bg=BG_MAIN,
            font=FONT_SMALL, anchor=tk.W)
        self._medal_status_lbl.pack(fill=tk.X, padx=12, pady=(0, 8))

    # ------------------------------------------------------------------
    #  Tab 3：高级功能（自动抢红包 + 自动抢天选）
    # ------------------------------------------------------------------
    def _build_advanced_tab(self, parent):
        from red_packet import red_packet_manager, CONFIG

        # ---------- 自动抢红包 ----------
        tk.Label(parent, text="自动抢红包", fg=ACCENT, bg=BG_MAIN,
                 font=FONT_HEAD).pack(anchor=tk.W, padx=16, pady=(12, 4))
        tk.Label(parent,
                 text="只对已添加监听的直播间生效",
                 fg=FG_SUB, bg=BG_MAIN, font=FONT_SMALL).pack(
            anchor=tk.W, padx=16)

        cfg_text = (
            f"扫描间隔: {CONFIG['scan_interval']}s  ·  "
            f"单房间上限: {CONFIG['max_listen_seconds']}s"
        )
        tk.Label(parent, text=cfg_text, fg=FG_DIM, bg=BG_MAIN,
                 font=FONT_TINY).pack(anchor=tk.W, padx=16, pady=(2, 6))

        ctrl_row = tk.Frame(parent, bg=BG_MAIN)
        ctrl_row.pack(fill=tk.X, padx=16, pady=(4, 4))

        self._rp_status_lbl = tk.Label(
            ctrl_row, text="未开启", fg=FG_SUB, bg=BG_MAIN,
            font=FONT_BODY, anchor=tk.W)
        self._rp_status_lbl.pack(side=tk.LEFT)

        self._rp_toggle_btn = tk.Button(
            ctrl_row, text="开启",
            command=self._toggle_red_packet,
            bg=BTN_PRIMARY, fg="#0f1a20",
            activebackground=BTN_PRIMARY_HOVER,
            activeforeground="#ffffff",
            font=FONT_BTN, relief=tk.FLAT, bd=0,
            padx=20, pady=4, cursor="hand2")
        self._rp_toggle_btn.pack(side=tk.RIGHT)

        # ---------- 自动抢天选 ----------
        tk.Label(parent, text="自动抢天选", fg=ACCENT, bg=BG_MAIN,
                 font=FONT_HEAD).pack(anchor=tk.W, padx=16, pady=(14, 4))
        tk.Label(parent,
                 text="立刻参与",
                 fg=FG_SUB, bg=BG_MAIN, font=FONT_SMALL).pack(
            anchor=tk.W, padx=16)

        al_ctrl_row = tk.Frame(parent, bg=BG_MAIN)
        al_ctrl_row.pack(fill=tk.X, padx=16, pady=(4, 4))

        self._al_status_lbl = tk.Label(
            al_ctrl_row, text="已开启", fg=ACCENT, bg=BG_MAIN,
            font=FONT_BODY, anchor=tk.W)
        self._al_status_lbl.pack(side=tk.LEFT)

        self._al_toggle_btn = tk.Button(
            al_ctrl_row, text="关闭",
            command=self._toggle_anchor_lot,
            bg=BTN_DANGER, fg="#ffffff",
            activebackground=BTN_DANGER_HOVER,
            activeforeground="#ffffff",
            font=FONT_BTN, relief=tk.FLAT, bd=0,
            padx=20, pady=4, cursor="hand2")
        self._al_toggle_btn.pack(side=tk.RIGHT)

        # ---------- 统计 ----------
        self._rp_stats_lbl = tk.Label(
            parent,
            text=("已参与红包: 0 · 红包中奖: 0 · "
                  "已参与天选: 0 · 天选中奖: 0 · "
                  "待抢: 0 · 运行: 0"),
            fg=FG_SUB, bg=BG_MAIN, font=FONT_SMALL, anchor=tk.W,
            wraplength=700, justify=tk.LEFT)
        self._rp_stats_lbl.pack(fill=tk.X, padx=16, pady=(8, 2))

        # ---------- 中奖历史 ----------
        tk.Label(parent, text="中奖历史", fg=WARN, bg=BG_MAIN,
                 font=FONT_HEAD).pack(anchor=tk.W, padx=16, pady=(8, 2))
        win_wrap = tk.Frame(parent, bg=BG_INPUT,
                             highlightthickness=1,
                             highlightbackground=BG_BORDER)
        win_wrap.pack(fill=tk.X, padx=16, pady=(0, 8))
        self._rp_win_text = tk.Text(
            win_wrap, bg=BG_INPUT, fg=WARN, font=FONT_MONO,
            wrap=tk.WORD, state=tk.DISABLED, relief=tk.FLAT, bd=0,
            padx=8, pady=6, height=4)
        self._rp_win_text.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self._rp_win_text.tag_config("win", foreground=WARN)

        # ---------- 运行日志 ----------
        tk.Label(parent, text="运行日志", fg=ACCENT, bg=BG_MAIN,
                 font=FONT_HEAD).pack(anchor=tk.W, padx=16, pady=(8, 2))
        log_wrap = tk.Frame(parent, bg=BG_INPUT,
                             highlightthickness=1,
                             highlightbackground=BG_BORDER)
        log_wrap.pack(fill=tk.BOTH, expand=True, padx=16, pady=(0, 12))

        self._rp_log_text = tk.Text(
            log_wrap, bg=BG_INPUT, fg=FG_SUB, font=FONT_MONO,
            wrap=tk.WORD, state=tk.DISABLED, relief=tk.FLAT, bd=0,
            padx=8, pady=6, height=8)
        self._rp_log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sb = tk.Scrollbar(log_wrap, orient=tk.VERTICAL,
                          command=self._rp_log_text.yview,
                          bg=BG_PANEL, troughcolor=BG_PANEL)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self._rp_log_text.configure(yscrollcommand=sb.set)

        # ---------- 绑定回调 ----------
        red_packet_manager.on_status_update = self._on_rp_status_change
        red_packet_manager.on_log = self._on_rp_log
        red_packet_manager.on_stats_update = self._on_rp_stats_change
        red_packet_manager.on_anchor_status_update = \
            self._on_anchor_status_change

        self._on_rp_status_change()
        self._on_anchor_status_change()
        self._on_rp_stats_change(red_packet_manager.get_stats())

    def _toggle_red_packet(self):
        from red_packet import red_packet_manager
        if red_packet_manager.is_enabled():
            red_packet_manager.stop()
        else:
            ok = red_packet_manager.start()
            if not ok:
                self._safe_msgbox("showwarning", "提示",
                                  "开启失败：请先登录账号")
        self._on_rp_status_change()

    def _on_rp_status_change(self):
        if self.destroyed:
            return
        try:
            from red_packet import red_packet_manager
            enabled = red_packet_manager.is_enabled()
        except Exception:
            enabled = False

        def _apply():
            try:
                if not self._rp_toggle_btn.winfo_exists():
                    return
                if enabled:
                    self._rp_toggle_btn.config(
                        text="停止", bg=BTN_DANGER, fg="#ffffff",
                        activebackground=BTN_DANGER_HOVER,
                        activeforeground="#ffffff")
                    self._rp_status_lbl.config(text="运行中", fg=ACCENT)
                else:
                    self._rp_toggle_btn.config(
                        text="开启", bg=BTN_PRIMARY, fg="#0f1a20",
                        activebackground=BTN_PRIMARY_HOVER,
                        activeforeground="#ffffff")
                    self._rp_status_lbl.config(text="未开启", fg=FG_SUB)
            except Exception:
                pass
        self._safe_after(0, _apply)

    # ★ 天选开关
    def _toggle_anchor_lot(self):
        from red_packet import red_packet_manager
        cur = red_packet_manager.is_anchor_enabled()
        red_packet_manager.set_anchor_enabled(not cur)
        self._on_anchor_status_change()

    def _on_anchor_status_change(self):
        if self.destroyed:
            return
        try:
            from red_packet import red_packet_manager
            enabled = red_packet_manager.is_anchor_enabled()
        except Exception:
            enabled = False

        def _apply():
            try:
                if not self._al_toggle_btn.winfo_exists():
                    return
                if enabled:
                    self._al_toggle_btn.config(
                        text="关闭", bg=BTN_DANGER, fg="#ffffff",
                        activebackground=BTN_DANGER_HOVER,
                        activeforeground="#ffffff")
                    self._al_status_lbl.config(text="已开启", fg=ACCENT)
                else:
                    self._al_toggle_btn.config(
                        text="开启", bg=BTN_PRIMARY, fg="#0f1a20",
                        activebackground=BTN_PRIMARY_HOVER,
                        activeforeground="#ffffff")
                    self._al_status_lbl.config(text="已关闭", fg=FG_SUB)
            except Exception:
                pass
        self._safe_after(0, _apply)

    def _on_rp_stats_change(self, stats):
        if self.destroyed:
            return
        try:
            from red_packet import red_packet_manager
            joined = stats.get("joined", 0)
            won = stats.get("won", 0)
            gifts = stats.get("gifts", [])
            anchor_joined = stats.get("anchor_joined", 0)
            anchor_won = stats.get("anchor_won", 0)
            pending = red_packet_manager.get_pending_count()
            running = red_packet_manager.get_running_count()
        except Exception:
            joined = won = pending = running = 0
            anchor_joined = anchor_won = 0
            gifts = []

        def _apply():
            try:
                if self._rp_stats_lbl.winfo_exists():
                    text = (f"已参与红包: {joined} · 红包中奖: {won} · "
                            f"已参与天选: {anchor_joined} · "
                            f"天选中奖: {anchor_won} · "
                            f"待抢: {pending} · 运行: {running}")
                    self._rp_stats_lbl.config(
                        text=text,
                        fg=(WARN if (won > 0 or anchor_won > 0)
                            else FG_SUB))

                if hasattr(self, "_rp_win_text") and \
                        self._rp_win_text.winfo_exists():
                    self._rp_win_text.configure(state=tk.NORMAL)
                    self._rp_win_text.delete("1.0", tk.END)
                    if not gifts:
                        self._rp_win_text.insert(
                            tk.END, "暂无中奖记录\n", "win")
                    else:
                        for g in gifts[-30:]:
                            ts = time.strftime(
                                "%m-%d %H:%M:%S",
                                time.localtime(g.get("ts", 0)))
                            tag = g.get("tag", "红包")
                            line = (f"[{ts}] [{tag}] 房间 "
                                    f"{g.get('room_id')} · "
                                    f"{g.get('gift_name')} x{g.get('num')} "
                                    f"(lot {g.get('lot_id')})\n")
                            self._rp_win_text.insert(tk.END, line, "win")
                    self._rp_win_text.see(tk.END)
                    self._rp_win_text.configure(state=tk.DISABLED)
            except Exception:
                pass
        self._safe_after(0, _apply)

    def _on_rp_log(self, level, msg):
        if self.destroyed:
            return
        ts = time.strftime("%H:%M:%S")

        def _apply():
            try:
                if not self._rp_log_text.winfo_exists():
                    return
                self._rp_log_text.configure(state=tk.NORMAL)
                self._rp_log_text.insert(tk.END,
                                          f"[{ts}] [{level}] {msg}\n")
                n = int(self._rp_log_text.index('end-1c').split('.')[0])
                if n > 200:
                    self._rp_log_text.delete("1.0", f"{n - 199}.0")
                self._rp_log_text.see(tk.END)
                self._rp_log_text.configure(state=tk.DISABLED)
            except Exception:
                pass
        self._safe_after(0, _apply)

    # ------------------------------------------------------------------
    #  底部按钮
    # ------------------------------------------------------------------
    def _build_bottom_bar(self):
        bottom = tk.Frame(self.win, bg=BG_MAIN)
        bottom.pack(fill=tk.X, padx=20, pady=(4, 18))

        tk.Button(bottom, text="添加账号", command=self._add_account,
                  bg=BTN_PRIMARY, fg="#0f1a20",
                  activebackground=BTN_PRIMARY_HOVER,
                  activeforeground="#ffffff",
                  font=FONT_BTN, relief=tk.FLAT, padx=18, pady=6,
                  cursor="hand2", bd=0).pack(side=tk.LEFT, padx=(0, 6))
        tk.Button(bottom, text="重新登录", command=self._relogin,
                  bg=BTN_INFO, fg="#ffffff",
                  activebackground=BTN_INFO_HOVER,
                  activeforeground="#ffffff",
                  font=FONT_BTN, relief=tk.FLAT, padx=18, pady=6,
                  cursor="hand2", bd=0).pack(side=tk.LEFT, padx=6)
        tk.Button(bottom, text="关闭", command=self._close,
                  bg=BTN_NEUTRAL, fg="#ffffff",
                  activebackground=BTN_NEUTRAL_HOVER,
                  activeforeground="#ffffff",
                  font=FONT_BTN, relief=tk.FLAT, padx=18, pady=6,
                  cursor="hand2", bd=0).pack(side=tk.RIGHT)
        tk.Button(bottom, text="退出登录", command=self._logout_current,
                  bg=BTN_DANGER, fg="#ffffff",
                  activebackground=BTN_DANGER_HOVER,
                  activeforeground="#ffffff",
                  font=FONT_BTN, relief=tk.FLAT, padx=18, pady=6,
                  cursor="hand2", bd=0).pack(side=tk.RIGHT, padx=(6, 6))

    # ------------------------------------------------------------------
    #  头像加载
    # ------------------------------------------------------------------
    def _load_avatar(self, url, label, size):
        if not url:
            return
        key = (url, size)
        if key in self._photos:
            try:
                if label.winfo_exists():
                    label.config(image=self._photos[key], text="")
            except Exception:
                pass
            return
        if key in self._pending:
            return
        self._pending.add(key)

        def _do():
            try:
                img = avatar_cache.load_image(url)
                if img is None:
                    return
                resized = img.resize((size, size), Image.LANCZOS)

                def _make_and_apply():
                    if self.destroyed:
                        return
                    try:
                        if not self.win.winfo_exists():
                            return
                        if not label.winfo_exists():
                            return
                        photo = ImageTk.PhotoImage(resized,
                                                    master=self.win)
                        self._photos[key] = photo
                        label.config(image=photo, text="")
                    except Exception:
                        pass
                self._safe_after(0, _make_and_apply)
            except Exception as e:
                log(f"账号头像加载失败: {e}", "WARN", show=False)
            finally:
                self._pending.discard(key)

        threading.Thread(target=_do, daemon=True).start()

    # ------------------------------------------------------------------
    #  账号列表刷新
    # ------------------------------------------------------------------
    def _refresh(self):
        if self.destroyed:
            return
        for w in self.current_frame.winfo_children():
            w.destroy()
        for w in self.list_inner.winfo_children():
            w.destroy()

        if account.account_info.get("is_login"):
            row = tk.Frame(self.current_frame, bg=BG_CARD)
            row.pack(fill=tk.X, padx=14, pady=14)

            av = tk.Label(row, bg=BG_CARD, width=64, height=64,
                          text="", relief=tk.FLAT, bd=0)
            av.pack(side=tk.LEFT)
            self._load_avatar(account.account_info.get("face", ""), av, 64)

            info = tk.Frame(row, bg=BG_CARD)
            info.pack(side=tk.LEFT, padx=14, fill=tk.X, expand=True)

            tk.Label(info, text="当前账号", fg=ACCENT, bg=BG_CARD,
                     font=FONT_SMALL).pack(anchor=tk.W)
            tk.Label(info, text=account.account_info.get("uname", ""),
                     fg=FG_MAIN, bg=BG_CARD,
                     font=("Microsoft YaHei UI", 13, "bold")).pack(
                anchor=tk.W)
            coin = account.account_info.get('coin', 0)
            bcoin = account.account_info.get('bcoin', 0)
            sub = (f"UID {account.account_info.get('mid')}  ·  "
                   f"Lv{account.account_info.get('level', 0)}  ·  "
                   f"硬币 {coin}  ·  B币 {bcoin}")
            tk.Label(info, text=sub, fg=FG_SUB, bg=BG_CARD,
                     font=FONT_SMALL).pack(anchor=tk.W, pady=(2, 0))
            if account.account_info.get("vip_status"):
                tk.Label(info,
                         text=account.account_info.get("vip_label", ""),
                         fg="#ff69b4", bg=BG_CARD,
                         font=FONT_SMALL).pack(anchor=tk.W)
        else:
            tk.Label(self.current_frame, text="当前未登录",
                     fg=FG_SUB, bg=BG_CARD, font=FONT_BODY).pack(pady=36)

        data = account.load_accounts()
        accounts = data.get("accounts", {})
        current = data.get("current")
        if not accounts:
            tk.Label(self.list_inner, text="暂无保存的账号",
                     fg=FG_SUB, bg=BG_PANEL, font=FONT_BODY).pack(pady=36)
            return

        for mid, acc in accounts.items():
            self._build_account_row(mid, acc, mid == current)

    def _build_account_row(self, mid, acc, is_cur):
        bg = BG_CARD if is_cur else BG_PANEL
        row = tk.Frame(self.list_inner, bg=bg)
        row.pack(fill=tk.X, pady=2, padx=4)

        av = tk.Label(row, bg=bg, width=40, height=40, text="",
                      relief=tk.FLAT, bd=0)
        av.pack(side=tk.LEFT, padx=12, pady=10)
        self._load_avatar(acc.get("face", ""), av, 40)

        info = tk.Frame(row, bg=bg)
        info.pack(side=tk.LEFT, fill=tk.X, expand=True)

        prefix = "● " if is_cur else ""
        color = ACCENT if is_cur else FG_MAIN
        tk.Label(info, text=prefix + acc.get("uname", f"UID {mid}"),
                 fg=color, bg=bg,
                 font=("Microsoft YaHei UI", 11,
                       "bold" if is_cur else "normal"),
                 anchor=tk.W).pack(anchor=tk.W)
        tk.Label(info, text=f"UID {mid}", fg=FG_SUB, bg=bg,
                 font=FONT_SMALL, anchor=tk.W).pack(anchor=tk.W)

        btns = tk.Frame(row, bg=bg)
        btns.pack(side=tk.RIGHT, padx=12)
        if not is_cur:
            tk.Button(btns, text="切换",
                      command=lambda m=mid: self._switch(m),
                      bg=BTN_INFO, fg="#ffffff",
                      activebackground=BTN_INFO_HOVER,
                      activeforeground="#ffffff",
                      font=FONT_SMALL, relief=tk.FLAT, padx=14, pady=4,
                      cursor="hand2", bd=0).pack()
        else:
            tk.Label(btns, text="使用中", fg=ACCENT, bg=bg,
                     font=FONT_SMALL).pack()

    # ------------------------------------------------------------------
    #  粉丝团灯牌
    # ------------------------------------------------------------------
    def _on_medal_search_changed(self, *args):
        """搜索框输入变化：防抖 250ms 后触发刷新。"""
        if self.destroyed:
            return
        if self._medal_search_after_id:
            try:
                self.win.after_cancel(self._medal_search_after_id)
            except Exception:
                pass
        self._medal_search_after_id = self._safe_after(
            250, self._render_medal_list)

    def _set_medal_status(self, text, color=FG_SUB):
        if self.destroyed:
            return
        if self._medal_status_lbl and \
                self._medal_status_lbl.winfo_exists():
            try:
                self._medal_status_lbl.config(text=text, fg=color)
            except Exception:
                pass

    def _load_medals(self, force=False):
        if self.destroyed:
            return
        if not api_get_all_medals:
            self._set_medal_status("auth 模块未提供勋章接口", BTN_DANGER)
            return
        if not account.has_login():
            self._set_medal_status("请先登录后再选择灯牌", BTN_WARN)
            self._medal_last_kw = None
            self._render_medal_list(force=True)
            return

        if not force and _MEDAL_CACHE["loaded"]:
            self._medal_items = _MEDAL_CACHE["items"] or []
            for m in self._medal_items:
                if "_search_key" not in m:
                    try:
                        name = (m.get("target_name")
                                or m.get("uname") or "").lower()
                        medal_name = (m.get("medal_name") or "").lower()
                        m["_search_key"] = name + " " + medal_name
                    except Exception:
                        m["_search_key"] = ""
            self._medal_last_kw = None
            self._render_medal_list(force=True)
            self._set_medal_status(
                f"共 {len(self._medal_items)} 枚勋章（已缓存）", ACCENT)
            return

        if _MEDAL_CACHE["loading"]:
            self._set_medal_status("正在加载中...", BTN_WARN)
            return

        _MEDAL_CACHE["loading"] = True
        self._set_medal_status("正在加载勋章列表...", BTN_WARN)

        def _worker():
            loop = asyncio.new_event_loop()
            try:
                result = loop.run_until_complete(api_get_all_medals())
            except Exception as e:
                result = {"ok": False, "msg": str(e), "items": []}
            finally:
                try:
                    loop.close()
                except Exception:
                    pass

            _MEDAL_CACHE["loading"] = False
            if result.get("ok"):
                _MEDAL_CACHE["items"] = result.get("items", []) or []
                _MEDAL_CACHE["loaded"] = True

            self._safe_after(0, lambda: self._on_medals_loaded(result))

        threading.Thread(target=_worker, daemon=True).start()

    def _on_medals_loaded(self, result):
        if self.destroyed:
            return
        if not self._safe_exists():
            return
        if not result.get("ok"):
            self._set_medal_status(
                f"加载失败: {result.get('msg', '')}", BTN_DANGER)
            self._medal_items = []
            self._medal_last_kw = None
            self._render_medal_list(force=True)
            return
        self._medal_items = result.get("items", []) or []
        for m in self._medal_items:
            try:
                name = (m.get("target_name")
                        or m.get("uname") or "").lower()
                medal_name = (m.get("medal_name") or "").lower()
                m["_search_key"] = name + " " + medal_name
            except Exception:
                m["_search_key"] = ""
        self._medal_last_kw = None
        self._render_medal_list(force=True)
        self._set_medal_status(
            f"共 {len(self._medal_items)} 枚勋章", ACCENT)

    def _render_medal_list(self, force=False):
        self._medal_search_after_id = None

        if self.destroyed:
            return
        if not self._medal_list_inner or \
                not self._medal_list_inner.winfo_exists():
            return

        try:
            kw = (self._medal_search_var.get() or "").strip().lower()
        except Exception:
            kw = ""

        if not force and kw == self._medal_last_kw:
            if self._medal_list_inner.winfo_children():
                return

        self._medal_last_kw = kw

        for w in self._medal_list_inner.winfo_children():
            w.destroy()

        if not account.has_login():
            tk.Label(self._medal_list_inner,
                     text="请先登录账号",
                     fg=FG_SUB, bg=BG_PANEL,
                     font=FONT_BODY).pack(pady=40)
            return

        if not self._medal_items:
            tk.Label(self._medal_list_inner,
                     text="暂无粉丝团灯牌\n（在此房间送过礼物的 UP 主会出现在这里）",
                     fg=FG_SUB, bg=BG_PANEL, font=FONT_BODY,
                     justify=tk.CENTER).pack(pady=40)
            return

        matched = []
        for m in self._medal_items:
            if kw:
                key = m.get("_search_key")
                if key is None:
                    name = (m.get("target_name")
                            or m.get("uname") or "").lower()
                    medal_name = (m.get("medal_name") or "").lower()
                    key = name + " " + medal_name
                    m["_search_key"] = key
                if kw not in key:
                    continue
            matched.append(m)

        total = len(matched)

        if total == 0:
            tk.Label(self._medal_list_inner,
                     text=f"没有匹配「{kw}」的勋章",
                     fg=FG_SUB, bg=BG_PANEL,
                     font=FONT_BODY).pack(pady=40)
            return

        show_list = matched[:self._medal_max_render]
        for m in show_list:
            self._build_medal_row(m)

        if total > self._medal_max_render:
            tk.Label(
                self._medal_list_inner,
                text=(f"…… 还有 {total - self._medal_max_render} 枚"
                      f"（共 {total} 枚），请细化关键词"),
                fg=FG_DIM, bg=BG_PANEL, font=FONT_SMALL,
                pady=8).pack(fill=tk.X)

        if kw:
            tip = f"匹配 {total} / {len(self._medal_items)} 枚"
            if total > self._medal_max_render:
                tip += f"（显示前 {self._medal_max_render}）"
            self._set_medal_status(tip, ACCENT)

    def _build_medal_row(self, m):
        row_idx = len(self._medal_list_inner.winfo_children())
        bg = BG_CARD if row_idx % 2 == 0 else BG_PANEL

        row = tk.Frame(self._medal_list_inner, bg=bg)
        row.pack(fill=tk.X, padx=2, pady=1)

        border = _int_to_hex(m.get("medal_color_border", 0))
        start = _int_to_hex(m.get("medal_color_start", 0))

        badge_wrap = tk.Frame(row, bg=bg, width=130, height=38)
        badge_wrap.pack(side=tk.LEFT, padx=10, pady=6)
        badge_wrap.pack_propagate(False)

        badge = tk.Frame(badge_wrap, bg=border)
        badge.pack(fill=tk.BOTH, expand=True)

        fg = _pick_text_color(start)
        tk.Label(
            badge,
            text=f"{m.get('medal_name', '?')} {m.get('level', 0)}",
            fg=fg, bg=start, font=FONT_SMALL, anchor=tk.CENTER
        ).pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

        info_col = tk.Frame(row, bg=bg)
        info_col.pack(side=tk.LEFT, fill=tk.X, expand=True,
                      padx=(6, 8))

        uname = m.get("target_name") or m.get("uname") or "?"
        tk.Label(info_col, text=uname, fg=FG_MAIN, bg=bg,
                 font=FONT_BODY, anchor=tk.W).pack(fill=tk.X)

        intimacy = m.get("intimacy", 0) or 0
        next_int = m.get("next_intimacy", 0) or 0
        feed = m.get("today_feed", 0) or 0
        day_limit = m.get("day_limit", 0) or 0
        room_id = m.get("roomid", 0) or 0

        parts = [f"亲密度 {intimacy}"]
        if next_int:
            parts.append(f"/ {next_int}")
        if day_limit:
            parts.append(f"  今日 {feed}/{day_limit}")
        if room_id:
            parts.append(f"  房间 {room_id}")
        tk.Label(info_col, text="".join(parts), fg=FG_SUB, bg=bg,
                 font=FONT_TINY, anchor=tk.W).pack(fill=tk.X, pady=(2, 0))

        right = tk.Frame(row, bg=bg)
        right.pack(side=tk.RIGHT, padx=(0, 10))

        lit = m.get("is_lighted", 0)
        lit_text = "已点亮" if lit else "未点亮"
        lit_color = ACCENT if lit else FG_SUB
        tk.Label(right, text=lit_text, fg=lit_color, bg=bg,
                 font=FONT_TINY).pack(side=tk.LEFT, padx=(0, 8))

        medal_id = m.get("medal_id", 0)
        btn = tk.Button(
            right, text="佩戴",
            bg=BTN_INFO, fg="#ffffff",
            activebackground=BTN_INFO_HOVER,
            activeforeground="#ffffff",
            font=FONT_SMALL, relief=tk.FLAT, bd=0,
            padx=12, pady=3, cursor="hand2")
        btn.config(command=lambda mid=medal_id, b=btn:
                   self._wear_medal(mid, b))
        btn.pack(side=tk.LEFT)

    def _wear_medal(self, medal_id, btn):
        if self.destroyed:
            return
        if not api_wear_medal or not medal_id:
            return
        try:
            if btn.winfo_exists():
                btn.config(state=tk.DISABLED, text="佩戴中...")
        except Exception:
            pass
        self._set_medal_status(f"正在佩戴勋章 {medal_id}...", BTN_WARN)

        def _worker():
            loop = asyncio.new_event_loop()
            try:
                result = loop.run_until_complete(api_wear_medal(medal_id))
            except Exception as e:
                result = {"ok": False, "msg": str(e)}
            finally:
                try:
                    loop.close()
                except Exception:
                    pass
            self._safe_after(0, lambda: self._on_wear_done(result, btn))

        threading.Thread(target=_worker, daemon=True).start()

    def _on_wear_done(self, result, btn):
        if self.destroyed:
            return
        if not self._safe_exists():
            return
        if result.get("ok"):
            self._set_medal_status(
                f"佩戴成功: {result.get('msg', '')}", ACCENT)
            try:
                if btn.winfo_exists():
                    btn.config(state=tk.NORMAL, text="已佩戴",
                                bg=BTN_NEUTRAL)
            except Exception:
                pass
        else:
            self._set_medal_status(
                f"佩戴失败: {result.get('msg', '')}", BTN_DANGER)
            try:
                if btn.winfo_exists():
                    btn.config(state=tk.NORMAL, text="佩戴",
                                bg=BTN_INFO)
            except Exception:
                pass

    # ------------------------------------------------------------------
    #  底部按钮回调
    # ------------------------------------------------------------------
    def _add_account(self):
        cb = None
        try:
            cb = self.callbacks.get("login")
        except Exception:
            pass
        self._close()
        if cb:
            try:
                cb()
            except Exception as e:
                log_err(f"添加账号回调异常: {e}")

    def _relogin(self):
        cb = None
        try:
            cb = self.callbacks.get("login")
        except Exception:
            pass
        self._close()
        if cb:
            try:
                cb()
            except Exception as e:
                log_err(f"重新登录回调异常: {e}")

    def _switch(self, mid):
        cb = None
        try:
            cb = self.callbacks.get("switch")
        except Exception:
            pass
        self._close()
        if cb:
            try:
                cb(mid)
            except Exception as e:
                log_err(f"切换账号回调异常: {e}")

    def _logout_current(self):
        if self.destroyed:
            return
        if not account.account_info.get("is_login"):
            self._safe_msgbox("showinfo", "提示", "当前未登录")
            return
        cur_mid = str(account.UID)
        data = account.load_accounts()
        acc = data["accounts"].get(cur_mid, {})
        uname = (acc.get("uname") or account.account_info.get("uname")
                 or f"UID {cur_mid}")
        ok = self._safe_msgbox(
            "askyesno", "退出登录",
            f"确定退出账号 {uname}？\n\n该账号将从列表移除，Token 会失效。",
            default=False)
        if not ok:
            return
        cb = None
        try:
            cb = self.callbacks.get("logout")
        except Exception:
            pass
        self._close()
        if cb:
            try:
                cb()
            except Exception as e:
                log_err(f"退出登录回调异常: {e}")