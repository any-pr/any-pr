# -*- coding: utf-8 -*-
"""B 站直播流获取 + PyAV 播放器
"""
import json
import queue
import threading
import time
import urllib.parse
import urllib.request
from collections import deque

import av
import tkinter as tk
from PIL import Image, ImageTk


PLAYURL_API = "https://api.live.bilibili.com/room/v1/Room/playUrl"
ROOM_INFO_API = "https://api.live.bilibili.com/room/v1/Room/get_info"
DANMUINFO_API = ("https://api.live.bilibili.com/xlive/web-room/v1/index/"
                 "getDanmuInfo")
REFERER = "https://live.bilibili.com/"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36")

QUALITY_LABELS = {
    30000: "杜比",
    20000: "4K",
    10000: "原画",
    400: "蓝光",
    250: "超清",
    150: "高清",
    80: "流畅",
}

# ── 播放参数 ───────────────────────────────────────────────
_VIDEO_BUFFER_MAX_SECONDS = 3.0
_VIDEO_BUFFER_HARD_MAX = 150
_VIDEO_BUFFER_MIN_KEEP = 5
_PTS_BACKWARD_THRESHOLD = -0.5
_PTS_FORWARD_THRESHOLD = 5.0
_DROP_BEHIND = 0.8
_FIRST_FRAME_DECODE_TIMEOUT = 8.0
_FIRST_FRAME_RENDER_TIMEOUT = 6.0
_VIDEO_STALL_TIMEOUT = 4.0
_VIDEO_RENDER_STALL_TIMEOUT = 3.0
_LINE_OPEN_TIMEOUT = 20.0
_URL_CACHE_TTL = 300
_DEFAULT_AUDIO_SR = 44100
_DEFAULT_AUDIO_CH = 2
_AUDIO_RING_MS = 800
_AUDIO_BLOCKSIZE = 0  # 让 PortAudio 自己选 block size


# ============================================================
#  音频环形缓冲
# ============================================================
class _AudioRing:
    def __init__(self, max_bytes):
        self._buf = bytearray()
        self._max = max(1, int(max_bytes))
        self._lock = threading.Lock()

    def write(self, data):
        if not data:
            return
        with self._lock:
            if len(data) > self._max:
                data = data[-self._max:]
            space = self._max - len(self._buf)
            if len(data) > space:
                drop = len(data) - space
                del self._buf[:drop]
            self._buf.extend(data)

    def read(self, n):
        if n <= 0:
            return b""
        with self._lock:
            if not self._buf:
                return b""
            take = min(n, len(self._buf))
            data = bytes(self._buf[:take])
            del self._buf[:take]
            return data

    def clear(self):
        with self._lock:
            self._buf.clear()

    def size(self):
        with self._lock:
            return len(self._buf)


# ============================================================
#  音频设备探测
#
#  ⚠ 关键：绝不在这里创建 RawOutputStream！
#  反复打开/关闭 PortAudio 原生流在某些 Windows 音频驱动上
#  会直接触发 0xC0000005（原生访问违规），Python 无法捕获。
# ============================================================
_PROBED_AUDIO = None
_PROBED_AUDIO_OK = False
_PROBE_LOCK = threading.Lock()


def _query_audio_device(force=False):
    """只查询音频设备参数，不打开任何原生流。

    返回：
        (samplerate, channels, latency) 或 None
    """
    global _PROBED_AUDIO, _PROBED_AUDIO_OK

    with _PROBE_LOCK:
        if _PROBED_AUDIO_OK and not force:
            return _PROBED_AUDIO

        try:
            import sounddevice as sd
        except ImportError:
            _PROBED_AUDIO = None
            _PROBED_AUDIO_OK = False
            return None

        try:
            dev = sd.query_devices(kind="output")
            default_sr = float(dev.get("default_samplerate",
                                        _DEFAULT_AUDIO_SR))
            max_ch = int(dev.get("max_output_channels",
                                  _DEFAULT_AUDIO_CH))
            if default_sr <= 0:
                default_sr = _DEFAULT_AUDIO_SR
            if max_ch <= 0:
                _PROBED_AUDIO = None
                _PROBED_AUDIO_OK = False
                return None

            channels = 2 if max_ch >= 2 else 1
            samplerate = int(round(default_sr))
            if samplerate <= 0:
                samplerate = _DEFAULT_AUDIO_SR

            result = (samplerate, channels, None)
            _PROBED_AUDIO = result
            _PROBED_AUDIO_OK = True
            return result
        except Exception:
            _PROBED_AUDIO = None
            _PROBED_AUDIO_OK = False
            return None


def prewarm_audio():
    """安全的音频预热——只查询设备信息，不创建原生流。"""
    return _query_audio_device(force=False)


def prewarm_all_rooms(room_ids, qn=10000, platform_="web", on_done=None):
    ids = list(room_ids)
    total = len(ids)

    def _worker():
        ok = 0
        for rid in ids:
            try:
                url_provider.fetch_sync(rid, qn=qn, platform_=platform_)
                ok += 1
            except Exception:
                pass
        if on_done:
            try:
                on_done(ok, total)
            except Exception:
                pass

    threading.Thread(target=_worker, daemon=True,
                     name="url-prewarm").start()


# ============================================================
#  URL 提供者
# ============================================================
class StreamURLProvider:
    def __init__(self):
        self._lock = threading.Lock()
        self._cache = {}
        self._prefetching = set()

    @staticmethod
    def _cache_key(room_id, qn, platform_):
        return (int(room_id), int(qn), str(platform_))

    def get_cached(self, room_id, qn, platform_):
        key = self._cache_key(room_id, qn, platform_)
        with self._lock:
            entry = self._cache.get(key)
            if not entry:
                return None
            if time.time() - entry["ts"] > _URL_CACHE_TTL:
                self._cache.pop(key, None)
                return None
            return dict(entry)

    def fetch_sync(self, room_id, qn=10000, platform_="web"):
        cached = self.get_cached(room_id, qn, platform_)
        if cached:
            return cached

        info = fetch_stream_urls(room_id, qn=qn, platform_=platform_)
        entry = {
            "urls": list(info.get("urls", [])),
            "format": info.get("format", "flv"),
            "quality": info.get("quality", qn),
            "accept_quality": info.get("accept_quality", []) or [],
            "quality_description":
                info.get("quality_description", []) or [],
            "ts": time.time(),
        }
        if not entry["urls"]:
            raise RuntimeError("接口返回空线路列表")

        key = self._cache_key(room_id, qn, platform_)
        with self._lock:
            self._cache[key] = entry
        return dict(entry)

    def prefetch_async(self, room_id, qn=10000, platform_="web",
                       on_done=None):
        cached = self.get_cached(room_id, qn, platform_)
        if cached:
            if on_done:
                try:
                    on_done(cached, None)
                except Exception:
                    pass
            return

        key = self._cache_key(room_id, qn, platform_)
        with self._lock:
            if key in self._prefetching:
                return
            self._prefetching.add(key)

        def _worker():
            err = None
            result = None
            try:
                result = self.fetch_sync(room_id, qn=qn,
                                          platform_=platform_)
            except Exception as e:
                err = e
            finally:
                with self._lock:
                    self._prefetching.discard(key)
            if on_done:
                try:
                    on_done(result, err)
                except Exception:
                    pass

        threading.Thread(target=_worker, daemon=True).start()

    def clear(self):
        with self._lock:
            self._cache.clear()


# ============================================================
#  接口
# ============================================================
def _http_get_json(url, params=None, extra_headers=None):
    if params:
        url = url + "?" + urllib.parse.urlencode(params)
    headers = {"User-Agent": UA, "Referer": REFERER}
    if extra_headers:
        headers.update(extra_headers)
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read().decode("utf-8"))


def fetch_real_room_id(short_room_id):
    return int(short_room_id)


def fetch_danmu_info(real_room_id):
    data = _http_get_json(DANMUINFO_API, {"id": real_room_id})
    if data.get("code") != 0:
        raise RuntimeError(
            f"getDanmuInfo 接口错误: code={data.get('code')} "
            f"message={data.get('message')}"
        )
    return data["data"]


def fetch_stream_urls(room_id, qn=10000, platform_="web"):
    params = {"cid": room_id, "qn": qn, "platform": platform_}
    data = _http_get_json(PLAYURL_API, params)

    if data.get("code") != 0:
        raise RuntimeError(
            f"playUrl 接口错误: code={data.get('code')} "
            f"message={data.get('message')}"
        )

    d = data.get("data", {})
    durl = d.get("durl", []) or []

    urls_sorted = []
    for item in durl:
        u = item.get("url", "")
        if not u:
            continue
        order = item.get("order", 0) or 0
        urls_sorted.append((order, u))
    urls_sorted.sort(key=lambda x: x[0])
    urls = [u for _, u in urls_sorted]

    if not urls:
        raise RuntimeError("接口返回 durl 为空，房间可能未开播")

    first_path = urls[0].split("?")[0].lower()
    fmt = "m3u8" if first_path.endswith(".m3u8") else "flv"

    return {
        "quality": d.get("current_quality", qn),
        "accept_quality": d.get("accept_quality", []) or [],
        "quality_description": d.get("quality_description", []) or [],
        "format": fmt,
        "urls": urls,
        "line_count": len(urls),
    }


# ============================================================
#  播放器
# ============================================================
class PyAVPlayer:
    def __init__(self, canvas):
        self.canvas = canvas

        self._playing = False
        self._stop_evt = threading.Event()

        # —— 会话（generation）隔离 ——
        self._session_lock = threading.Lock()
        self._session_id = 0

        # Container / streams
        self._container = None
        self._video_stream = None
        self._audio_stream = None
        self._video_tb = 1.0 / 90000.0
        self._estimated_frame_duration = 1.0 / 30.0

        # 视频
        self._video_buf = deque()
        self._video_buf_lock = threading.Lock()
        self._last_video_pts = None
        self._render_initialized = False
        self._timeline_origin_pts_sec = None
        self._timeline_origin_wall = 0.0

        # 音频
        self._audio_ring = None
        self._sd_stream = None
        self._has_audio = False
        self._audio_sr = _DEFAULT_AUDIO_SR
        self._audio_ch = _DEFAULT_AUDIO_CH
        self._audio_latency = None
        self._audio_bytes_per_frame = self._audio_ch * 2

        # 线程
        self._decode_thread = None
        self._audio_thread = None
        self._watchdog_thread = None

        # URL（原始顺序，永不重排）
        self._urls = []
        self._current_url_idx = 0

        # 渲染
        self._photo = None
        self._canvas_image_id = None
        self._last_canvas_size = None

        # 计数器
        self._dropped = 0
        self._rendered = 0
        self._decoded_video = 0
        self._decoded_audio = 0
        self._recalibrations = 0
        self._underflows = 0
        self._render_errors = 0
        self._decode_errors = 0

        # Watchdog 时间戳
        self._decode_start_time = 0.0
        self._first_decode_time = 0.0
        self._last_decode_time = 0.0
        self._last_render_time = 0.0

        self._first_frame_decoded_evt = threading.Event()
        self._first_frame_rendered_evt = threading.Event()
        self._first_render_timeout_reported = False

        # 重连
        self._reconnect_lock = threading.Lock()
        self._reconnecting = False

        # 回调
        self.on_status = None
        self.on_error = None
        self.on_stream_ended = None

    # ==========================================================
    #  会话管理
    # ==========================================================
    def _new_session(self):
        with self._session_lock:
            self._session_id += 1
            return self._session_id

    def _get_session(self):
        with self._session_lock:
            return self._session_id

    # ==========================================================
    #  对外：开始播放
    # ==========================================================
    def play(self, urls):
        # stop() 会：递增会话、创建新的 _stop_evt、
        # 停旧线程、关闭 container / 音频流
        self.stop()

        if isinstance(urls, str):
            all_urls = [urls]
        else:
            all_urls = [u for u in (urls or []) if u]

        if not all_urls:
            self._playing = False
            self._notify_error("没有可用的流 URL")
            return

        self._urls = list(all_urls)
        self._playing = True

        session_id = self._get_session()   # 由 stop() 递增过了

        # 音频参数只查询一次，绝不创建原生流
        probed = _query_audio_device(force=not _PROBED_AUDIO_OK)
        if probed:
            self._audio_sr, self._audio_ch, self._audio_latency = probed
            self._audio_bytes_per_frame = self._audio_ch * 2
        else:
            self._has_audio = False
            self._audio_sr = _DEFAULT_AUDIO_SR
            self._audio_ch = _DEFAULT_AUDIO_CH
            self._audio_latency = None

        last_err = None
        for idx in range(len(self._urls)):
            if self._stop_evt.is_set() or \
                    session_id != self._get_session():
                self._playing = False
                return
            try:
                self._try_open_url(idx)
                self._notify_status(
                    f"已连接线路 {idx + 1}/{len(self._urls)}", "ok")
                self._start_threads(session_id)
                return
            except Exception as e:
                last_err = e
                self._notify_status(
                    f"线路 {idx + 1}/{len(self._urls)} 失败: {e}", "warn")
                self._close_container()
                continue

        self._playing = False
        self._notify_error(
            f"全部 {len(self._urls)} 条线路都失败: {last_err}"
            if last_err else f"全部 {len(self._urls)} 条线路都失败")

    def switch_line(self, index):
        if index < 0 or index >= len(self._urls):
            return False
        if not self._urls:
            return False
        if index == self._current_url_idx and self._playing:
            return True

        self._notify_status(
            f"正在切换到线路 {index + 1}/{len(self._urls)}...", "info")

        self._stop_threads_and_container()
        session_id = self._get_session()

        try:
            self._try_open_url(index)
            self._start_threads(session_id)
            return True
        except Exception as e:
            self._notify_error(f"切换到线路 {index + 1} 失败: {e}")
            self._playing = False
            return False

    def set_urls(self, urls):
        self._urls = list(urls)

    # ==========================================================
    #  内部：打开单条线路
    # ==========================================================
    def _try_open_url(self, idx):
        url = self._urls[idx]

        lower = url.split("?")[0].lower()
        fmt_hint = None
        if lower.endswith(".flv"):
            fmt_hint = "flv"
        elif lower.endswith(".m3u8"):
            fmt_hint = "hls"

        options = {
            "referer": REFERER,
            "user_agent": UA,
            "rw_timeout": "15000000",
            "stimeout": "15000000",
            "probesize": "2000000",
            "analyzeduration": "5000000",
            "fflags": "discardcorrupt",
            "err_detect": "ignore_err",
            "buffer_size": "1048576",
        }

        kwargs = {"options": options, "timeout": _LINE_OPEN_TIMEOUT}
        if fmt_hint:
            kwargs["format"] = fmt_hint

        self._container = av.open(url, **kwargs)

        self._video_stream = next(
            (s for s in self._container.streams if s.type == "video"), None)
        self._audio_stream = next(
            (s for s in self._container.streams if s.type == "audio"), None)

        if not self._video_stream:
            raise RuntimeError("未找到视频流")

        self._has_audio = (self._audio_stream is not None and
                            _PROBED_AUDIO_OK)

        try:
            self._video_tb = float(self._video_stream.time_base) or \
                (1.0 / 90000.0)
        except Exception:
            self._video_tb = 1.0 / 90000.0

        try:
            fps = self._video_stream.average_rate
            if fps and float(fps) > 0:
                self._estimated_frame_duration = 1.0 / float(fps)
            else:
                self._estimated_frame_duration = 1.0 / 30.0
        except Exception:
            self._estimated_frame_duration = 1.0 / 30.0

        self._current_url_idx = idx

        with self._video_buf_lock:
            self._video_buf.clear()
            self._last_video_pts = None
            self._render_initialized = False
            self._timeline_origin_pts_sec = None
            self._timeline_origin_wall = 0.0

        self._first_frame_decoded_evt.clear()
        self._first_frame_rendered_evt.clear()
        self._first_render_timeout_reported = False

        self._decode_start_time = time.monotonic()
        self._first_decode_time = 0.0
        self._last_decode_time = 0.0
        self._last_render_time = 0.0

        self._recalibrations = 0

    def _close_container(self):
        if self._container:
            try:
                self._container.close()
            except Exception:
                pass
            self._container = None
        self._video_stream = None
        self._audio_stream = None

    # ==========================================================
    #  线程生命周期
    # ==========================================================
    def _start_threads(self, session_id):
        # 每个线程捕获当前的 stop_evt 引用（避免被后续 set 换掉）
        stop_evt = self._stop_evt

        self._decode_thread = threading.Thread(
            target=self._decode_loop,
            args=(session_id, stop_evt),
            daemon=True, name=f"decoder-{session_id}",
        )
        self._audio_thread = threading.Thread(
            target=self._audio_loop,
            args=(session_id, stop_evt),
            daemon=True, name=f"audio-{session_id}",
        )
        self._watchdog_thread = threading.Thread(
            target=self._watchdog_loop,
            args=(session_id, stop_evt),
            daemon=True, name=f"watchdog-{session_id}",
        )

        self._decode_thread.start()
        self._audio_thread.start()
        self._watchdog_thread.start()

    def _stop_threads_and_container(self):
        """停掉线程和 container，保留 _playing / _urls。

        用于 switch_line / reconnect。
        使旧线程彻底失效（会话递增 + stop_evt.set）。
        """
        # 使旧线程失效（它们会检查 session_id != current）
        self._new_session()

        # 同时给当前 stop_evt 打标记（旧线程都持有引用）
        try:
            self._stop_evt.set()
        except Exception:
            pass

        # 等旧线程退出
        for t in (self._decode_thread, self._audio_thread,
                  self._watchdog_thread):
            if t and t.is_alive():
                try:
                    t.join(timeout=1.5)
                except Exception:
                    pass

        # 关闭音频流
        if self._sd_stream is not None:
            try:
                self._sd_stream.abort()
            except Exception:
                pass
            try:
                self._sd_stream.close()
            except Exception:
                pass
            self._sd_stream = None

        # 关闭 container
        self._close_container()

        self._decode_thread = None
        self._audio_thread = None
        self._watchdog_thread = None

        if self._audio_ring:
            self._audio_ring.clear()
            self._audio_ring = None

        # 为下一次会话准备新的 stop event
        self._stop_evt = threading.Event()

        with self._video_buf_lock:
            self._video_buf.clear()

    # ==========================================================
    #  解码线程
    # ==========================================================
    def _decode_loop(self, session_id, stop_evt):
        if session_id != self._get_session():
            return

        resampler = None
        if self._audio_stream is not None and self._has_audio:
            layout = "stereo" if self._audio_ch == 2 else "mono"
            try:
                resampler = av.AudioResampler(
                    format="s16",
                    layout=layout,
                    rate=self._audio_sr,
                )
            except Exception:
                resampler = None
                self._has_audio = False

        try:
            stream_v = self._video_stream
            stream_a = self._audio_stream

            for packet in self._container.demux():
                if stop_evt.is_set() or \
                        session_id != self._get_session():
                    break
                if packet.dts is None:
                    continue

                try:
                    if packet.stream is stream_v:
                        for frame in packet.decode():
                            if stop_evt.is_set() or \
                                    session_id != self._get_session():
                                break
                            self._push_video_frame(frame)

                    elif packet.stream is stream_a and resampler is not None:
                        for frame in packet.decode():
                            if stop_evt.is_set() or \
                                    session_id != self._get_session():
                                break
                            try:
                                out = resampler.resample(frame)
                            except Exception:
                                continue
                            if not isinstance(out, (list, tuple)):
                                out = [out]
                            for of in out:
                                if of is None:
                                    continue
                                try:
                                    data = bytes(of.planes[0])
                                except Exception:
                                    continue
                                if data and self._audio_ring:
                                    self._audio_ring.write(data)
                                    self._decoded_audio += 1
                    else:
                        try:
                            packet.decode()
                        except Exception:
                            pass
                except Exception:
                    self._decode_errors += 1
                    continue
        except Exception as e:
            self._decode_errors += 1
            if not stop_evt.is_set() and \
                    session_id == self._get_session():
                self._notify_error(f"解码异常: {e}")
        finally:
            # demux 结束 → 只有当前会话才请求重连
            if not stop_evt.is_set() and \
                    session_id == self._get_session():
                self._request_reconnect("解码线程退出")

    # ==========================================================
    #  视频帧入队
    # ==========================================================
    def _push_video_frame(self, frame):
        now_mono = time.monotonic()
        if self._first_decode_time == 0.0:
            self._first_decode_time = now_mono

        with self._video_buf_lock:
            pts = frame.pts

            if pts is not None and self._last_video_pts is not None:
                delta = (pts - self._last_video_pts) * self._video_tb
                if delta < _PTS_BACKWARD_THRESHOLD or \
                        delta > _PTS_FORWARD_THRESHOLD:
                    self._video_buf.clear()
                    self._render_initialized = False
                    self._timeline_origin_pts_sec = None
                    self._timeline_origin_wall = 0.0
                    self._recalibrations += 1

            if pts is not None:
                self._last_video_pts = pts

            self._video_buf.append((frame, now_mono))
            self._decoded_video += 1

            while len(self._video_buf) > _VIDEO_BUFFER_MIN_KEEP:
                first_frame, _ = self._video_buf[0]
                last_frame, _ = self._video_buf[-1]
                if first_frame.pts is None or last_frame.pts is None:
                    if len(self._video_buf) <= _VIDEO_BUFFER_HARD_MAX:
                        break
                    self._video_buf.popleft()
                    self._dropped += 1
                    continue
                span = (last_frame.pts - first_frame.pts) * self._video_tb
                if span <= _VIDEO_BUFFER_MAX_SECONDS:
                    break
                self._video_buf.popleft()
                self._dropped += 1

        self._last_decode_time = now_mono
        if not self._first_frame_decoded_evt.is_set():
            self._first_frame_decoded_evt.set()

    # ==========================================================
    #  音频线程（重写：只打开一次流，绝不 fallback）
    # ==========================================================
    def _audio_loop(self, session_id, stop_evt):
        if session_id != self._get_session():
            return

        if not self._has_audio:
            return

        try:
            import sounddevice as sd
        except ImportError:
            self._has_audio = False
            self._notify_status("未安装 sounddevice，音频静音", "warn")
            return

        sr = int(self._audio_sr)
        ch = int(self._audio_ch)

        if sr <= 0:
            sr = _DEFAULT_AUDIO_SR
        if ch not in (1, 2):
            ch = 2

        bytes_per_frame = ch * 2
        self._audio_bytes_per_frame = bytes_per_frame

        ring_bytes = int(sr * bytes_per_frame * _AUDIO_RING_MS / 1000)
        self._audio_ring = _AudioRing(ring_bytes)

        stopped = threading.Event()

        def _callback(outdata, frames, time_info, status):
            try:
                if stopped.is_set() or stop_evt.is_set() or \
                        session_id != self._get_session():
                    outdata[:] = b"\x00" * (frames * bytes_per_frame)
                    return

                needed = frames * bytes_per_frame
                ring = self._audio_ring

                if ring is None:
                    outdata[:] = b"\x00" * needed
                    self._underflows += 1
                    return

                data = ring.read(needed)
                if len(data) < needed:
                    outdata[:] = data + b"\x00" * (needed - len(data))
                    self._underflows += 1
                else:
                    outdata[:] = data

                try:
                    if getattr(status, "output_underflow", False):
                        self._underflows += 1
                except Exception:
                    pass
            except Exception:
                try:
                    outdata[:] = b"\x00" * (frames * bytes_per_frame)
                except Exception:
                    pass

        stream = None
        try:
            # ★ 只尝试一次，绝不 fallback 到其它参数组合。
            #  如果这里崩了，视频继续播，音频放弃。
            kwargs = {
                "samplerate": sr,
                "channels": ch,
                "dtype": "int16",
                "blocksize": _AUDIO_BLOCKSIZE,
                "callback": _callback,
            }
            stream = sd.RawOutputStream(**kwargs)
            self._sd_stream = stream
            stream.start()
            self._notify_status(f"音频已启用：{sr}Hz / {ch}ch", "ok")
        except Exception as e:
            self._has_audio = False
            if stream is not None:
                try:
                    stream.close()
                except Exception:
                    pass
            self._sd_stream = None
            self._notify_status(
                f"音频设备打开失败，视频继续播放: {e}", "warn")
            if self._audio_ring:
                self._audio_ring.clear()
            self._audio_ring = None
            return

        try:
            while not stop_evt.wait(0.5):
                if session_id != self._get_session():
                    break
        finally:
            stopped.set()
            try:
                stream.abort()
            except Exception:
                pass
            try:
                stream.close()
            except Exception:
                pass
            if self._sd_stream is stream:
                self._sd_stream = None
            if self._audio_ring:
                self._audio_ring.clear()
            self._audio_ring = None

    # ==========================================================
    #  Watchdog
    # ==========================================================
    def _watchdog_loop(self, session_id, stop_evt):
        while not stop_evt.wait(1.0):
            if session_id != self._get_session():
                return

            now = time.monotonic()

            if not self._first_frame_decoded_evt.is_set():
                if self._decode_start_time > 0 and \
                        now - self._decode_start_time > \
                        _FIRST_FRAME_DECODE_TIMEOUT:
                    self._notify_error("首帧解码超时")
                    self._request_reconnect("首帧解码超时")
                    return
                continue

            if not self._first_frame_rendered_evt.is_set() and \
                    not self._first_render_timeout_reported:
                if self._first_decode_time > 0 and \
                        now - self._first_decode_time > \
                        _FIRST_FRAME_RENDER_TIMEOUT:
                    self._first_render_timeout_reported = True
                    self._notify_status("首帧渲染超时，尝试切线路", "warn")
                    self._request_reconnect("首帧渲染超时")
                    return

            if self._last_decode_time > 0 and \
                    now - self._last_decode_time > _VIDEO_STALL_TIMEOUT:
                self._notify_status("视频解码停止，尝试切线路", "warn")
                self._request_reconnect("视频解码停止")
                return

            if self._last_render_time > 0 and \
                    now - self._last_render_time > \
                    _VIDEO_RENDER_STALL_TIMEOUT:
                self._notify_status("视频渲染停止，尝试切线路", "warn")
                self._request_reconnect("视频渲染停止")
                return

    # ==========================================================
    #  自动重连
    # ==========================================================
    def _request_reconnect(self, reason):
        with self._reconnect_lock:
            if self._reconnecting or self._stop_evt.is_set():
                return
            self._reconnecting = True

        if not self._stop_evt.is_set():
            self._notify_status(f"检测到 {reason}，尝试恢复", "warn")

        threading.Thread(
            target=self._reconnect_worker, args=(reason,),
            daemon=True, name="reconnect").start()

    def _reconnect_worker(self, reason):
        try:
            if self._stop_evt.is_set():
                return

            urls = list(self._urls)
            n = len(urls)
            if n == 0:
                self._playing = False
                self._notify_error(f"{reason}：无可用线路")
                return

            current = self._current_url_idx

            for offset in range(1, n + 1):
                if not self._playing:
                    return

                next_idx = (current + offset) % n

                # _stop_threads_and_container 会递增会话，
                # 使旧线程彻底失效，并创建新的 _stop_evt
                self._stop_threads_and_container()
                session_id = self._get_session()

                if not self._playing:
                    return

                try:
                    self._try_open_url(next_idx)
                    self._start_threads(session_id)
                    if self._playing:
                        self._notify_status(
                            f"已恢复线路 {next_idx + 1}/{n}", "ok")
                        return
                except Exception:
                    continue

            self._playing = False
            self._notify_error(f"{reason}：全部线路无法恢复")
            self._notify_stream_ended()
        finally:
            with self._reconnect_lock:
                self._reconnecting = False

    # ==========================================================
    #  UI 渲染（由 UI 主线程 after(16) 调用）
    # ==========================================================
    def update_canvas(self):
        if not self._playing or self._stop_evt.is_set():
            return

        now_wall = time.perf_counter()
        render_frame = None

        with self._video_buf_lock:
            if not self._video_buf:
                return

            if not self._render_initialized:
                frame, _ = self._video_buf.popleft()
                abs_sec = self._frame_abs_seconds(frame)
                if abs_sec is not None:
                    self._timeline_origin_pts_sec = abs_sec
                self._timeline_origin_wall = now_wall
                self._render_initialized = True
                render_frame = frame
            else:
                elapsed = now_wall - self._timeline_origin_wall
                origin = self._timeline_origin_pts_sec

                if origin is not None:
                    while self._video_buf:
                        f, _ = self._video_buf[0]
                        abs_sec = self._frame_abs_seconds(f)
                        if abs_sec is None:
                            break
                        rel = abs_sec - origin
                        if rel < elapsed - _DROP_BEHIND:
                            self._video_buf.popleft()
                            self._dropped += 1
                        else:
                            break

                while self._video_buf:
                    f, _ = self._video_buf[0]
                    abs_sec = self._frame_abs_seconds(f)
                    if abs_sec is None:
                        render_frame = self._video_buf.popleft()[0]
                        continue
                    if origin is None:
                        render_frame = self._video_buf.popleft()[0]
                        continue
                    rel = abs_sec - origin
                    if rel <= elapsed:
                        render_frame = self._video_buf.popleft()[0]
                    else:
                        break

        if render_frame is None:
            return

        ok = self._render_frame(render_frame)

        # ★ 只有真正成功渲染后才刷新时间戳 / 首帧渲染标记
        if ok:
            self._last_render_time = time.monotonic()
            if not self._first_frame_rendered_evt.is_set():
                self._first_frame_rendered_evt.set()

    def _frame_abs_seconds(self, frame):
        if frame.pts is not None:
            return float(frame.pts) * self._video_tb
        return None

    def _render_frame(self, frame):
        """把一帧画到 canvas 上。

        返回：
            True  —— 已成功显示到 Canvas
            False —— 因异常没有显示（watchdog 依赖这个）
        """
        img = None

        try:
            arr = frame.to_ndarray(format="rgb24")
            try:
                img = Image.fromarray(arr, "RGB")
            except Exception:
                img = Image.fromarray(arr)
        except Exception:
            self._render_errors += 1
            img = None

        if img is None:
            try:
                img = frame.to_image()
            except Exception:
                self._render_errors += 1
                return False

        try:
            cw = self.canvas.winfo_width()
            ch = self.canvas.winfo_height()
            if cw <= 1 or ch <= 1:
                cw, ch = 640, 360

            iw, ih = img.size
            scale = min(cw / iw, ch / ih)
            nw = max(1, int(iw * scale))
            nh = max(1, int(ih * scale))

            if (nw, nh) != (iw, ih):
                img = img.resize((nw, nh), Image.BILINEAR)

            self._photo = ImageTk.PhotoImage(img)

            if self._canvas_image_id is None or \
                    self._last_canvas_size != (cw, ch):
                try:
                    self.canvas.delete("all")
                except Exception:
                    pass
                self._canvas_image_id = self.canvas.create_image(
                    cw // 2, ch // 2, anchor=tk.CENTER,
                    image=self._photo)
                self._last_canvas_size = (cw, ch)
            else:
                self.canvas.itemconfig(
                    self._canvas_image_id, image=self._photo)

            self._rendered += 1
            return True
        except Exception:
            self._render_errors += 1
            return False

    # ==========================================================
    #  停止（对外）
    # ==========================================================
    def stop(self):
        self._playing = False
        # 递增会话 + 停旧线程 + 关 container / 音频流
        # 并创建新的 _stop_evt 供下一次 play() 使用
        self._stop_threads_and_container()
        self._has_audio = False

        # 只重置 Python 侧状态。
        # ★ 不在这里操作 Tk Canvas —— 那是主线程的事。
        self._canvas_image_id = None
        self._last_canvas_size = None
        self._photo = None

    # ==========================================================
    #  查询
    # ==========================================================
    def is_playing(self):
        return self._playing

    @property
    def current_url_index(self):
        return self._current_url_idx

    @property
    def total_urls(self):
        return len(self._urls)

    @property
    def has_audio(self):
        return self._has_audio

    @property
    def urls(self):
        return list(self._urls)

    def get_stats(self):
        with self._video_buf_lock:
            vq = len(self._video_buf)
            origin = self._timeline_origin_pts_sec
        return {
            "playing": self._playing,
            "has_audio": self._has_audio,
            "video_q": vq,
            "decoded_video": self._decoded_video,
            "decoded_audio": self._decoded_audio,
            "dropped": self._dropped,
            "rendered": self._rendered,
            "recalibrations": self._recalibrations,
            "underflows": self._underflows,
            "render_errors": self._render_errors,
            "decode_errors": self._decode_errors,
            "line": self._current_url_idx + 1,
            "total_lines": len(self._urls),
            "audio_sr": self._audio_sr,
            "audio_ch": self._audio_ch,
            "timeline_origin": origin,
            "session": self._get_session(),
        }

    def _notify_status(self, text, color="info"):
        if self.on_status:
            try:
                self.on_status(text, color)
            except Exception:
                pass

    def _notify_error(self, msg):
        if self.on_error:
            try:
                self.on_error(msg)
            except Exception:
                pass

    def _notify_stream_ended(self):
        if self.on_stream_ended:
            try:
                self.on_stream_ended()
            except Exception:
                pass


url_provider = StreamURLProvider()