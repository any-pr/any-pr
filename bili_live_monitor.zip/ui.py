﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ui.py
import asyncio
import hashlib
import json
import sys
import time as _time
import urllib.parse
if sys.version_info >= (3, 14):
    try:
        asyncio.set_event_loop_policy(asyncio.DefaultEventLoopPolicy())
    except Exception:
        pass
    try:
        asyncio.set_event_loop(asyncio.new_event_loop())
    except Exception:
        pass

import queue
import threading
import time
import urllib.request
import webbrowser

import tkinter as tk
from tkinter import ttk

from PIL import Image, ImageTk

import account
import avatar_cache
import live_area
import live_player
from logger import log, log_err

try:
    from auth import (login_bridge, do_password_login,
                      api_get_all_medals, api_wear_medal)
except Exception:
    login_bridge = None
    do_password_login = None
    api_get_all_medals = None
    api_wear_medal = None

BG_ROOT = "#0d1117"
BG_PANEL = "#161b22"
BG_CARD = "#21262d"
BG_INPUT = "#0d1117"
BG_HOVER = "#30363d"
BORDER = "#30363d"
FG_MAIN = "#e6edf3"
FG_SUB = "#8b949e"
FG_DIM = "#6e7681"
ACCENT = "#2dd4bf"
ACCENT_HOVER = "#26b8a4"
SUCCESS = "#3fb950"
WARN = "#d29922"
DANGER = "#f85149"
INFO = "#58a6ff"
PURPLE = "#bc8cff"

FONT_TITLE = ("Microsoft YaHei UI", 12, "bold")
FONT_HEAD = ("Microsoft YaHei UI", 10, "bold")
FONT_BODY = ("Microsoft YaHei UI", 10)
FONT_SMALL = ("Microsoft YaHei UI", 9)
FONT_TINY = ("Microsoft YaHei UI", 8)
FONT_TS = ("Consolas", 9)
FONT_PK = ("Microsoft YaHei UI", 11, "bold")
FONT_PK_BIG = ("Microsoft YaHei UI", 14, "bold")
FONT_WATCHED_BIG = ("Microsoft YaHei UI", 26, "bold")
FONT_PAGE_BTN = ("Microsoft YaHei UI", 11, "bold")
FONT_PAGE_INFO = ("Microsoft YaHei UI", 11, "bold")

EVENT_COLORS = {
    "white": FG_MAIN, "green": SUCCESS, "yellow": WARN,
    "cyan": ACCENT, "magenta": PURPLE, "red": DANGER,
    "blue": INFO, "dim": FG_DIM,
}

TOP_KEYS = ["连接", "直播", "人气", "在线", "弹幕", "礼物", "SC"]
QUALITY_OPTIONS = [("原画", 10000),
                   ("蓝光", 400), ("超清", 250), ("高清", 150), ("流畅", 80)]
PLATFORM_OPTIONS = [("HTTP-FLV (web)", "web"), ("HLS / M3U8 (h5)", "h5")]

_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
       "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36")
_AREA_MEM_CACHE = {}
PK_STALE_TIMEOUT = 60.0

PLAY_BTN_BG = SUCCESS
PLAY_BTN_FG = "#0d1117"
PLAY_BTN_ACTIVE_BG = "#31a04c"
PLAY_BTN_ACTIVE_FG = "#0d1117"
STOP_BTN_BG = DANGER
STOP_BTN_FG = "#ffffff"
STOP_BTN_ACTIVE_BG = "#c0392b"
STOP_BTN_ACTIVE_FG = "#ffffff"
PLAY_BTN_TEXT = "播放"
STOP_BTN_TEXT = "停止"

# 弹幕长度上限（按字符计）
DANMU_MAX_LEN = 40

# 表情面板：每页显示多少个分区
EMOTE_PAGE_SIZE = 5

_MIXIN_KEY_ENC_TAB = [
    46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35,
    27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13,
    37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4,
    22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52,
]
_WBI_CACHE = {"img_key": "", "sub_key": "", "ts": 0.0}
_WBI_LOCK = threading.Lock()


def _get_wbi_keys(force=False):
    with _WBI_LOCK:
        now = time.time()
        if not force and _WBI_CACHE["img_key"] and now - _WBI_CACHE["ts"] < 43200:
            return _WBI_CACHE["img_key"], _WBI_CACHE["sub_key"]
    try:
        d = _http_get_json("https://api.bilibili.com/x/web-interface/nav",
                            with_cookie=True)
        wbi = ((d.get("data") or {}).get("wbi_img") or {})
        img_url = wbi.get("img_url", "")
        sub_url = wbi.get("sub_url", "")
        if img_url and sub_url:
            img_key = img_url.rsplit("/", 1)[-1].split(".")[0]
            sub_key = sub_url.rsplit("/", 1)[-1].split(".")[0]
            with _WBI_LOCK:
                _WBI_CACHE["img_key"] = img_key
                _WBI_CACHE["sub_key"] = sub_key
                _WBI_CACHE["ts"] = time.time()
            return img_key, sub_key
    except Exception:
        pass
    return "", ""


def _get_mixin_key(img_key, sub_key):
    raw = img_key + sub_key
    return "".join(raw[i] for i in _MIXIN_KEY_ENC_TAB if i < len(raw))[:32]


def _wbi_sign(params):
    img_key, sub_key = _get_wbi_keys()
    if not img_key or not sub_key:
        return dict(params)
    mixin_key = _get_mixin_key(img_key, sub_key)
    params = dict(params)
    params["wts"] = int(time.time())
    sorted_items = sorted(params.items())
    query = urllib.parse.urlencode(sorted_items)
    w_rid = hashlib.md5((query + mixin_key).encode()).hexdigest()
    params["w_rid"] = w_rid
    return params


def _norm_color(c, fallback=""):
    if not c:
        return fallback
    if isinstance(c, int):
        return "#{:06X}".format(c & 0xFFFFFF)
    s = str(c).strip()
    if s.startswith("#"):
        s = s[1:]
    if s.startswith("0x") or s.startswith("0X"):
        s = s[2:]
    if len(s) >= 6:
        return "#" + s[:6].upper()
    return fallback


def _pick_text_color(bg_hex, fallback="#FFFFFF"):
    try:
        r = int(bg_hex[1:3], 16)
        g = int(bg_hex[3:5], 16)
        b = int(bg_hex[5:7], 16)
        luma = 0.299 * r + 0.587 * g + 0.114 * b
        return "#000000" if luma > 160 else "#FFFFFF"
    except Exception:
        return fallback


def _empty_pk_state():
    return {
        "active": False,
        "my_name": "我", "my_uid": 0, "my_room_id": 0,
        "my_face": "", "my_color": "", "my_votes": 0,
        "oppo_name": "对手", "oppo_uid": 0, "oppo_room_id": 0,
        "oppo_face": "", "oppo_color": "", "oppo_votes": 0,
        "members": [], "session_id": "",
    }


def _is_interact_msg(msg):
    return not (msg.startswith("[弹幕]") or msg.startswith("[历史弹幕]"))


def _http_get_json(url, timeout=8, with_cookie=False, referer=None, params=None):
    if params:
        sep = "&" if "?" in url else "?"
        url = url + sep + urllib.parse.urlencode(params)
    headers = {
        "User-Agent": _UA,
        "Referer": referer or "https://live.bilibili.com/",
        "Origin": "https://live.bilibili.com",
        "Accept": "application/json, text/plain, */*",
    }
    if with_cookie:
        try:
            ck = account.get_cookie_dict()
            if ck:
                cookie_str = "; ".join(
                    f"{k}={v}" for k, v in ck.items()
                    if v is not None and str(v) != "")
                if cookie_str:
                    headers["Cookie"] = cookie_str
        except Exception:
            pass
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


class UserDetailDialog:
    def __init__(self, parent, uid=0, room_id=0,
                 initial_name="", initial_face=""):
        self.parent = parent
        self.uid = int(uid or 0)
        self.room_id = int(room_id or 0)
        self.destroyed = False
        self.win = tk.Toplevel(parent)
        self.win.title(f"用户详情 · {initial_name or uid or room_id}")
        self.win.configure(bg=BG_ROOT)
        self.win.geometry("720x760")
        self.win.minsize(580, 520)
        try:
            self.win.transient(parent)
        except Exception:
            pass
        self.win.protocol("WM_DELETE_WINDOW", self._close)

        head = tk.Frame(self.win, bg=BG_PANEL)
        head.pack(fill=tk.X)

        self.avatar_lbl = tk.Label(head, bg=BG_PANEL, width=72, height=72,
                                    text="", relief=tk.FLAT, bd=0)
        self.avatar_lbl.pack(side=tk.LEFT, padx=(16, 12), pady=12)

        info_col = tk.Frame(head, bg=BG_PANEL)
        info_col.pack(side=tk.LEFT, fill=tk.X, expand=True, pady=12)

        self.name_lbl = tk.Label(info_col, text=initial_name or "加载中...",
                                  fg=FG_MAIN, bg=BG_PANEL,
                                  font=("Microsoft YaHei UI", 14, "bold"),
                                  anchor=tk.W)
        self.name_lbl.pack(fill=tk.X, anchor=tk.W)

        self.uid_lbl = tk.Label(info_col,
                                 text=(f"UID {self.uid}" if self.uid else ""),
                                 fg=FG_SUB, bg=BG_PANEL, font=FONT_SMALL,
                                 anchor=tk.W)
        self.uid_lbl.pack(fill=tk.X, anchor=tk.W, pady=(2, 0))

        self.sign_lbl = tk.Label(info_col, text="", fg=FG_DIM, bg=BG_PANEL,
                                  font=FONT_TINY, anchor=tk.W, wraplength=460,
                                  justify=tk.LEFT)
        self.sign_lbl.pack(fill=tk.X, anchor=tk.W, pady=(4, 0))

        self.status_lbl = tk.Label(self.win, text="正在加载...",
                                    fg=ACCENT, bg=BG_ROOT, font=FONT_SMALL,
                                    anchor=tk.W)
        self.status_lbl.pack(fill=tk.X, padx=16, pady=(4, 4))

        self.nb = ttk.Notebook(self.win)
        self.nb.pack(fill=tk.BOTH, expand=True, padx=12, pady=(0, 12))

        self.tab_overview = tk.Frame(self.nb, bg=BG_PANEL)
        self.nb.add(self.tab_overview, text="  概览  ")
        self.overview_text = self._make_text(self.tab_overview)

        self.tab_room = tk.Frame(self.nb, bg=BG_PANEL)
        self.nb.add(self.tab_room, text="  直播间  ")
        self.room_text = self._make_text(self.tab_room)

        if initial_face:
            self._load_avatar_async(initial_face)

        threading.Thread(target=self._fetch_worker, daemon=True,
                         name="user-detail-fetch").start()

    def _make_text(self, parent):
        wrap = tk.Frame(parent, bg=BG_PANEL)
        wrap.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        wrap.grid_rowconfigure(0, weight=1)
        wrap.grid_columnconfigure(0, weight=1)
        t = tk.Text(wrap, bg=BG_PANEL, fg=FG_MAIN, font=FONT_BODY,
                    relief=tk.FLAT, bd=0, wrap=tk.WORD, padx=12, pady=10,
                    state=tk.DISABLED)
        t.grid(row=0, column=0, sticky="nsew")
        sb = tk.Scrollbar(wrap, orient=tk.VERTICAL, command=t.yview,
                          bg=BG_PANEL, troughcolor=BG_PANEL,
                          activebackground=BG_HOVER, bd=0, highlightthickness=0,
                          width=8, relief=tk.FLAT)
        sb.grid(row=0, column=1, sticky="ns")
        t.configure(yscrollcommand=sb.set)
        t.tag_config("k", foreground=FG_SUB,
                     font=("Microsoft YaHei UI", 10, "bold"))
        t.tag_config("v", foreground=FG_MAIN)
        t.tag_config("v_hi", foreground=ACCENT,
                     font=("Microsoft YaHei UI", 10, "bold"))
        t.tag_config("v_warn", foreground=WARN)
        t.tag_config("v_danger", foreground=DANGER)
        t.tag_config("v_info", foreground=INFO)
        t.tag_config("sec", foreground=PURPLE,
                     font=("Microsoft YaHei UI", 10, "bold"))
        t.tag_config("dim", foreground=FG_DIM)
        return t

    def _safe_exists(self):
        try:
            return (not self.destroyed) and bool(self.win.winfo_exists())
        except Exception:
            return False

    def _safe_after(self, ms, func, *args):
        if not self._safe_exists():
            return None
        try:
            return self.win.after(ms, func, *args)
        except Exception:
            return None

    def _set_status(self, text, color=FG_SUB):
        if not self._safe_exists():
            return
        try:
            self.status_lbl.config(text=text, fg=color)
        except Exception:
            pass

    def _close(self):
        self.destroyed = True
        try:
            self.win.destroy()
        except Exception:
            pass

    def _clear(self, widget):
        if not widget or not widget.winfo_exists():
            return False
        try:
            widget.configure(state=tk.NORMAL)
            widget.delete("1.0", tk.END)
            return True
        except Exception:
            return False

    def _finish(self, widget):
        if not widget or not widget.winfo_exists():
            return
        try:
            widget.configure(state=tk.DISABLED)
        except Exception:
            pass

    def _put(self, widget, key, value, tag="v"):
        try:
            widget.insert(tk.END, f"{key}: ", "k")
            widget.insert(tk.END, f"{value}\n", tag)
        except Exception:
            pass

    def _put_line(self, widget, text, tag="v"):
        try:
            widget.insert(tk.END, text + "\n", tag)
        except Exception:
            pass

    def _section(self, widget, title):
        try:
            widget.insert(tk.END, f"\n──── {title} ────\n", "sec")
        except Exception:
            pass

    @staticmethod
    def _fmt_num(v):
        try:
            n = int(v or 0)
        except Exception:
            return str(v)
        if n >= 100000000:
            return f"{n/100000000:.2f}亿"
        if n >= 10000:
            return f"{n/10000:.2f}万"
        return str(n)

    def _fetch_worker(self):
        raw = {}
        err = None
        try:
            if self.uid <= 0 and self.room_id > 0:
                try:
                    d = _http_get_json(
                        "https://api.live.bilibili.com/room/v1/Room/room_init",
                        params={"id": self.room_id})
                    if d.get("code") == 0:
                        init = d.get("data") or {}
                        raw["room_init"] = init
                        real_rid = int(init.get("room_id", 0) or 0)
                        init_uid = int(init.get("uid", 0) or 0)
                        if real_rid > 0:
                            self.room_id = real_rid
                        if init_uid > 0:
                            self.uid = init_uid
                except Exception:
                    pass

            if self.uid > 0:
                try:
                    d = _http_get_json(
                        "https://api.live.bilibili.com/room/v1/Room/getRoomInfoOld",
                        params={"mid": self.uid})
                    if d.get("code") == 0:
                        room_old = d.get("data") or {}
                        raw["room_old"] = room_old
                        if int(room_old.get("roomStatus", 0) or 0) == 1:
                            rid = int(room_old.get("roomid", 0) or 0)
                            if rid > 0:
                                self.room_id = rid
                except Exception:
                    pass

            if self.room_id > 0:
                try:
                    d = _http_get_json(
                        "https://api.live.bilibili.com/xlive/web-room/v1/"
                        "index/getInfoByRoom", params={"room_id": self.room_id})
                    if d.get("code") == 0:
                        raw["getInfoByRoom"] = d.get("data") or {}
                        anchor = (raw["getInfoByRoom"].get("anchor_info") or {})
                        base = anchor.get("base_info") or {}
                        if self.uid <= 0 and base.get("uid"):
                            self.uid = int(base.get("uid", 0) or 0)
                except Exception:
                    pass

            if self.uid > 0:
                try:
                    signed = _wbi_sign({"mid": self.uid})
                    d = _http_get_json(
                        "https://api.bilibili.com/x/space/wbi/acc/info",
                        with_cookie=True,
                        referer=f"https://space.bilibili.com/{self.uid}",
                        params=signed)
                    if d.get("code") == 0:
                        raw["acc_info"] = d.get("data") or {}
                except Exception:
                    pass

                try:
                    d = _http_get_json(
                        "https://api.bilibili.com/x/web-interface/card",
                        with_cookie=True,
                        referer=f"https://space.bilibili.com/{self.uid}",
                        params={"mid": self.uid, "photo": "true"})
                    if d.get("code") == 0:
                        raw["card"] = d.get("data") or {}
                except Exception:
                    pass

                try:
                    d = _http_get_json(
                        "https://api.bilibili.com/x/relation/stat",
                        with_cookie=True, params={"vmid": self.uid})
                    if d.get("code") == 0:
                        raw["relation"] = d.get("data") or {}
                except Exception:
                    pass

                try:
                    d = _http_get_json(
                        "https://api.bilibili.com/x/space/upstat",
                        with_cookie=True,
                        referer=f"https://space.bilibili.com/{self.uid}",
                        params={"mid": self.uid})
                    if d.get("code") == 0:
                        raw["upstat"] = d.get("data") or {}
                except Exception:
                    pass
        except Exception as e:
            err = e

        if self.uid > 0:
            def _fix_uid():
                try:
                    self.uid_lbl.config(text=f"UID {self.uid}")
                except Exception:
                    pass
            self._safe_after(0, _fix_uid)

        self._safe_after(0, self._on_data, raw, err)

    def _on_data(self, raw, err):
        if not self._safe_exists():
            return
        if err:
            self._set_status(f"加载失败: {err}", DANGER)
            return
        if not raw:
            self._set_status("未获取到数据", WARN)
            return

        acc = raw.get("acc_info") or {}
        card = raw.get("card") or {}
        card_card = card.get("card") or {}
        room_old = raw.get("room_old") or {}

        name = (acc.get("name") or card_card.get("name")
                or ((raw.get("getInfoByRoom") or {}).get("anchor_info") or {})
                    .get("base_info", {}).get("uname", ""))
        face = (acc.get("face") or card_card.get("face")
                or ((raw.get("getInfoByRoom") or {}).get("anchor_info") or {})
                    .get("base_info", {}).get("face", ""))
        sign = acc.get("sign") or card_card.get("sign", "")

        if name:
            try:
                self.name_lbl.config(text=name)
                self.win.title(f"用户详情 · {name}")
            except Exception:
                pass
        if face:
            self._load_avatar_async(face)
        if sign:
            try:
                self.sign_lbl.config(text=sign)
            except Exception:
                pass
        if self.uid:
            try:
                self.uid_lbl.config(text=f"UID {self.uid}")
            except Exception:
                pass

        self._render_overview(raw)
        self._render_room(raw)

        room_status = "有直播间" if room_old.get("roomStatus") == 1 else "无直播间"
        live_status = "直播中" if room_old.get("liveStatus") == 1 else "未开播"
        self._set_status(f"加载完成 · {room_status} · {live_status}", SUCCESS)

    def _render_overview(self, raw):
        t = self.overview_text
        if not self._clear(t):
            return
        try:
            acc = raw.get("acc_info") or {}
            card = raw.get("card") or {}
            cc = card.get("card") or {}
            relation = raw.get("relation") or {}
            upstat = raw.get("upstat") or {}
            room_old = raw.get("room_old") or {}

            self._section(t, "基础信息")
            name = acc.get("name") or cc.get("name", "")
            if name:
                self._put(t, "昵称", name, "v_hi")
            uid = acc.get("mid") or cc.get("mid") or self.uid
            if uid:
                self._put(t, "UID", str(uid))
            sex = acc.get("sex") or cc.get("sex", "")
            if sex:
                self._put(t, "性别", sex)
            level = acc.get("level")
            if level is None and cc.get("level_info"):
                level = (cc.get("level_info") or {}).get("current_level", 0)
            if level is not None and int(level or 0) > 0:
                self._put(t, "等级", f"Lv{level}")
            sign = acc.get("sign") or cc.get("sign", "")
            if sign:
                self._put(t, "签名", sign)
            birthday = acc.get("birthday", "")
            if birthday:
                self._put(t, "生日", birthday)
            school = acc.get("school") or {}
            if school.get("name"):
                self._put(t, "就读学校", school.get("name"))

            official = acc.get("official") or cc.get("Official") or {}
            ov_type = int(official.get("type", -1) or -1)
            if ov_type in (0, 1):
                title = official.get("title") or official.get("desc") or ""
                role = "机构认证" if ov_type == 1 else "UP主认证"
                self._put(t, "认证", f"[{role}] {title}", "v_hi")

            vip = acc.get("vip") or cc.get("vip") or {}
            vip_status = int(vip.get("status", vip.get("vipStatus", 0)) or 0)
            if vip_status:
                label = vip.get("label") or {}
                vtype = label.get("text")
                if not vtype:
                    vt = int(vip.get("type", vip.get("vipType", 0)) or 0)
                    vtype = {1: "月度大会员", 2: "年度大会员"}.get(vt, "大会员")
                due = int(vip.get("due_date", 0) or 0)
                if due > 0:
                    try:
                        due_str = time.strftime("%Y-%m-%d",
                                                 time.localtime(due / 1000.0))
                        self._put(t, "会员", f"{vtype}（到期 {due_str}）", "v_warn")
                    except Exception:
                        self._put(t, "会员", vtype, "v_warn")
                else:
                    self._put(t, "会员", vtype, "v_warn")

            if int(acc.get("is_senior_member", 0) or 0):
                self._put(t, "硬核会员", "是", "v_hi")
            if int(acc.get("silence", 0) or 0):
                self._put(t, "账号状态", "已被封禁", "v_danger")

            sys_notice = acc.get("sys_notice") or {}
            if sys_notice.get("content"):
                self._put(t, "系统通知", sys_notice.get("content"), "v_danger")

            self._section(t, "粉丝与关注")
            fans = (relation.get("follower") or card.get("follower")
                    or cc.get("fans") or 0)
            if fans:
                self._put(t, "粉丝数", self._fmt_num(fans), "v_hi")
            following = (relation.get("following") or cc.get("attention") or 0)
            if following:
                self._put(t, "关注数", self._fmt_num(following))

            archive_view = (upstat.get("archive") or {}).get("view", 0)
            likes = upstat.get("likes", 0)
            archive_count = card.get("archive_count", 0)
            if archive_view or likes or archive_count:
                self._section(t, "视频数据")
                if archive_view:
                    self._put(t, "视频总播放", self._fmt_num(archive_view))
                if likes:
                    self._put(t, "获赞总数", self._fmt_num(likes))
                if archive_count:
                    self._put(t, "投稿数", str(archive_count))

            coins = acc.get("coins")
            if coins is None:
                coins = cc.get("coins")
            if coins is not None and int(coins or 0) > 0:
                self._put(t, "硬币", str(coins))

            fans_medal = acc.get("fans_medal") or {}
            medal = fans_medal.get("medal") or {}
            if medal.get("medal_name"):
                self._section(t, "佩戴勋章")
                self._put(t, "勋章",
                          f"{medal.get('medal_name')} Lv{medal.get('level', 0)}",
                          "v_hi")
                intimacy = int(medal.get("intimacy", 0) or 0)
                nxt = int(medal.get("next_intimacy", 0) or 0)
                if nxt:
                    self._put(t, "亲密度", f"{intimacy} / {nxt}")
                else:
                    self._put(t, "亲密度", str(intimacy))

            if room_old and int(room_old.get("roomStatus", 0) or 0) == 1:
                self._section(t, "直播间摘要")
                self._put(t, "直播间",
                          f"有房间（{room_old.get('roomid', '')}）", "v_hi")
                self._put(t, "当前状态",
                          "直播中" if room_old.get("liveStatus") == 1 else "未开播",
                          "v_warn" if room_old.get("liveStatus") == 1 else "v")
                if room_old.get("title"):
                    self._put(t, "标题", room_old.get("title"))

            if t.index("end-1c") == "1.0":
                t.insert(tk.END, "无用户信息", "dim")
            self._finish(t)
        except Exception as e:
            log_err(f"渲染概览失败: {e}")
            self._finish(t)

    def _render_room(self, raw):
        t = self.room_text
        if not self._clear(t):
            return
        try:
            room_old = raw.get("room_old") or {}
            room_init = raw.get("room_init") or {}
            detail = raw.get("getInfoByRoom") or {}
            room_info = detail.get("room_info") or {}
            anchor = detail.get("anchor_info") or {}
            base_info = anchor.get("base_info") or {}
            live_info = anchor.get("live_info") or {}
            relation_info = anchor.get("relation_info") or {}
            medal_info = anchor.get("medal_info") or {}

            has_room = int(room_old.get("roomStatus", 0) or 0) == 1
            if not has_room and not room_info and not room_init:
                self._put_line(t, "该用户没有直播间", "dim")
                self._finish(t)
                return

            tags = []
            if room_init.get("encrypted"):
                tags.append("[密码保护]")
            if room_init.get("is_locked"):
                tags.append("[房间已锁定]")
            if room_init.get("is_hidden"):
                tags.append("[房间已隐藏]")
            sp = int(room_init.get("special_type", 0) or 0)
            if sp == 1:
                tags.append("[付费直播]")
            elif sp == 2:
                tags.append("[拜年纪]")
            if tags:
                self._put_line(t, "  ".join(tags), "v_warn")

            self._section(t, "直播间信息")
            rid = (room_info.get("room_id") or room_init.get("room_id")
                   or room_old.get("roomid") or self.room_id)
            if rid:
                self._put(t, "房间号", str(rid))
            if room_info.get("short_id"):
                self._put(t, "短号", str(room_info.get("short_id")))
            title = (room_info.get("title") or room_old.get("title", ""))
            if title:
                self._put(t, "标题", title, "v_hi")
            parent_area = room_info.get("parent_area_name", "")
            area = room_info.get("area_name", "")
            if parent_area or area:
                self._put(t, "分区", f"{parent_area} / {area}")
            live_status = (room_old.get("liveStatus")
                           if room_old else room_info.get("live_status"))
            if live_status is not None:
                self._put(t, "直播状态",
                          "直播中" if int(live_status) == 1 else "未开播",
                          "v_warn" if int(live_status) == 1 else "v")
            online = (room_info.get("online") or room_old.get("online") or 0)
            if online:
                self._put(t, "在线人数", self._fmt_num(online), "v_hi")
            if room_info.get("tags"):
                self._put(t, "标签", room_info.get("tags"))

            if base_info or anchor:
                self._section(t, "主播信息")
                uname = base_info.get("uname", "")
                if uname:
                    self._put(t, "主播", uname, "v_hi")
                auid = base_info.get("uid", 0) or room_init.get("uid", 0)
                if auid:
                    self._put(t, "主播 UID", str(auid))
                gender = {0: "保密", 1: "男", 2: "女"}.get(
                    int(base_info.get("gender", 0) or 0), "未知")
                self._put(t, "性别", gender)
                if base_info.get("sign"):
                    self._put(t, "主播签名", base_info.get("sign"))

            if relation_info:
                if relation_info.get("attention") is not None:
                    self._put(t, "主播关注数",
                              self._fmt_num(relation_info.get("attention", 0)))
                if relation_info.get("fans") is not None:
                    self._put(t, "主播粉丝数",
                              self._fmt_num(relation_info.get("fans", 0)), "v_hi")

            if live_info:
                lv = int(live_info.get("live_status", 0))
                if lv == 1:
                    st = int(live_info.get("live_start_time", 0) or 0)
                    if st > 0:
                        self._put(t, "开播时间",
                                  time.strftime("%Y-%m-%d %H:%M:%S",
                                                time.localtime(st)))

            if medal_info:
                if medal_info.get("medal_name"):
                    self._put(t, "粉丝牌", medal_info.get("medal_name", ""))
                if medal_info.get("guard_num") is not None:
                    self._put(t, "舰长数",
                              self._fmt_num(medal_info.get("guard_num", 0)),
                              "v_hi")

            url = room_old.get("url", "")
            if url:
                self._section(t, "链接")
                self._put_line(t, url, "v_info")
            self._finish(t)
        except Exception as e:
            log_err(f"渲染直播间失败: {e}")
            self._finish(t)

    def _load_avatar_async(self, url):
        if not url:
            return
        if url.startswith("http://"):
            url = "https://" + url[7:]

        def _do():
            try:
                img = avatar_cache.load_image(url)
                if img is None:
                    return
                resized = img.resize((72, 72), Image.LANCZOS)

                def _apply():
                    if not self._safe_exists():
                        return
                    try:
                        photo = ImageTk.PhotoImage(resized, master=self.win)
                        self.avatar_lbl.config(image=photo, text="")
                        self.avatar_lbl.image = photo
                    except Exception:
                        pass
                self._safe_after(0, _apply)
            except Exception:
                pass

        threading.Thread(target=_do, daemon=True).start()


class TkUI:
    def __init__(self, root, room_ids, send_cb, account_cb,
                 add_room_cb=None, remove_room_cb=None,
                 refresh_pk_cb=None, login_bridge_=None,
                 get_engine_cb=None,
                 like_report_cb=None,
                 on_account_changed_cb=None,
                 switch_account_cb=None,
                 logout_account_cb=None,
                 send_emoticon_cb=None,
                 list_emoticons_cb=None):
        self.root = root
        self.room_ids = list(room_ids)
        self.current_room = self.room_ids[0] if self.room_ids else 0
        self.send_cb = send_cb
        self.account_cb = account_cb
        self.add_room_cb = add_room_cb
        self.remove_room_cb = remove_room_cb
        self.refresh_pk_cb = refresh_pk_cb
        self.get_engine_cb = get_engine_cb
        self.like_report_cb = like_report_cb
        self.on_account_changed_cb = on_account_changed_cb
        self.switch_account_cb = switch_account_cb
        self.logout_account_cb = logout_account_cb
        self.send_emoticon_cb = send_emoticon_cb
        self.list_emoticons_cb = list_emoticons_cb
        self.login_bridge = login_bridge_ or login_bridge

        self.q = queue.Queue()
        self.avatar_done = queue.Queue()
        self.avatar_requests = queue.Queue()
        self.avatar_cache = {}
        self.avatar_pending = set()
        self.max_event_lines = 800
        self.max_interact_lines = 500

        self._account_face_url = None
        self._account_avatar_photo = None
        self._header_avatar_photo = None
        self._pk_avatar_refs = {}
        self._medal_tags = {}

        # 表情面板状态
        self._emote_panel = None
        self._emote_panel_nb = None
        self._emote_panel_search = None
        self._emote_panel_emotes = []
        self._emote_image_refs = {}     # url -> PhotoImage（会话级缓存）
        self._emote_cover_refs = {}     # url -> PhotoImage（Tab 封面）
        self._emote_cover_urls = {}
        self._emote_total_lbl = None
        self._emote_loaded_tabs = set()
        self._emote_tab_widgets = {}
        self._emote_pending_after = {}
        self._emote_page = 0
        self._emote_filtered = []
        self._emote_page_info_lbl = None
        self._emote_prev_btn = None
        self._emote_next_btn = None

        self.room_cards = {}
        self.capsule_labels = {}
        self.list_inner = None
        self._room_mgr_window = None

        self._pk_bar_last_w = None
        self._pk_bar_last_payload = None

        self._live_dialog = None
        self._live_canvas = None
        self._live_status_lbl = None
        self._live_play_btn = None
        self._live_quality_var = None
        self._live_platform_var = None
        self._live_room_lbl = None
        self._live_player = None
        self._live_last_url = None
        self._live_line_var = None
        self._live_line_combo = None
        self._live_line_urls = []
        self._render_after_id = None

        self._area_mgr = live_area.LiveAreaManager()
        self._area_loaded = False
        self.area_capsule = None
        self.area_val_label = None
        self._area_fetch_requested = set()

        self._interact_window = None
        self._interact_text = None
        self._interact_room_lbl = None
        self._interact_room_id = 0
        self._user_detail_windows = []

        self.watched_val_label = None
        self.rank_inner = None
        self.rank_count_label = None
        self._rank_canvas = None
        self._rank_sb = None

        self.rooms_state = {}
        for rid in self.room_ids:
            self.rooms_state[rid] = self._new_room_state(rid)

        self._build()
        self._refresh_all_room_cards()
        self._refresh_main_panel()
        self._start_avatar_worker()
        self.root.after(80, self._poll)
        self.root.after(5000, self._pk_timeout_check)

        self._ensure_area_loaded(force=True)
        self.root.after(300, self._fetch_all_rooms_area)

    @staticmethod
    def _new_room_state(rid):
        return {
            "title": "等待连接...",
            "anchor_name": "",
            "anchor_face": "",
            "anchor_uid": 0,
            "area_id": 0,
            "area_name": "",
            "status": {
                "连接": "在线", "直播": "未知", "人气": 0, "在线": 0,
                "排名": 0, "粉丝": 0, "弹幕": 0, "礼物": 0,
                "SC": 0, "动画": "无", "watched": 0,
            },
            "event_buffer": [],
            "interact_buffer": [],
            "rank_list": [],
            "pk": _empty_pk_state(),
            "pk_manual_open": False,
            "pk_last_update": 0.0,
        }

    def _root_alive(self):
        try:
            return bool(self.root.winfo_exists())
        except Exception:
            return False

    def _widget_alive(self, w):
        try:
            return w is not None and bool(w.winfo_exists())
        except Exception:
            return False

    def _build(self):
        self._refresh_title()
        self.root.geometry("1420x960")
        self.root.minsize(1200, 780)
        self.root.configure(bg=BG_ROOT)
        main = tk.Frame(self.root, bg=BG_ROOT)
        main.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        main.grid_columnconfigure(0, weight=0, minsize=260)
        main.grid_columnconfigure(1, weight=1)
        main.grid_columnconfigure(2, weight=0, minsize=300)
        main.grid_rowconfigure(0, weight=1)
        self._build_left(main)
        self._build_middle(main)
        self._build_right(main)

    def _refresh_title(self):
        if len(self.room_ids) == 0:
            t = "Bilibili 直播监控"
        elif len(self.room_ids) == 1:
            t = f"Bilibili 直播监控 · 房间 {self.room_ids[0]}"
        else:
            t = f"Bilibili 直播监控 · {len(self.room_ids)} 个房间"
        try:
            self.root.title(t)
        except Exception:
            pass

    @staticmethod
    def _bind_mousewheel(canvas, *widgets):
        def _scroll(event):
            try:
                if not canvas.winfo_exists():
                    return "break"
                delta = event.delta
                if delta == 0:
                    return "break"
                canvas.yview_scroll(int(-delta / 120), "units")
            except Exception:
                pass
            return "break"

        targets = [canvas] + list(widgets)
        for w in targets:
            if w is None:
                continue
            try:
                w.bind("<MouseWheel>", _scroll, add="+")
                w.bind("<Button-4>", lambda e: canvas.yview_scroll(-1, "units"), add="+")
                w.bind("<Button-5>", lambda e: canvas.yview_scroll(1, "units"), add="+")
            except Exception:
                pass

    def _bind_mousewheel_recursive(self, canvas, parent):
        try:
            self._bind_mousewheel(canvas, parent)
        except Exception:
            pass
        try:
            for child in parent.winfo_children():
                self._bind_mousewheel_recursive(canvas, child)
        except Exception:
            pass

    def _build_left(self, parent):
        left = tk.Frame(parent, bg=BG_PANEL, highlightthickness=1,
                        highlightbackground=BORDER)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        left.grid_propagate(False)
        left.grid_rowconfigure(1, weight=1)
        left.grid_columnconfigure(0, weight=1)

        header = tk.Frame(left, bg=BG_PANEL)
        header.grid(row=0, column=0, sticky="ew", padx=16, pady=(16, 10))
        tk.Label(header, text="直播间", fg=FG_MAIN, bg=BG_PANEL,
                 font=FONT_TITLE, anchor=tk.W).pack(side=tk.LEFT)
        self.room_count_label = tk.Label(header, text=f"{len(self.room_ids)}",
                                          fg=FG_DIM, bg=BG_PANEL,
                                          font=FONT_SMALL)
        self.room_count_label.pack(side=tk.RIGHT)

        list_wrap = tk.Frame(left, bg=BG_PANEL)
        list_wrap.grid(row=1, column=0, sticky="nsew")
        list_wrap.grid_rowconfigure(0, weight=1)
        list_wrap.grid_columnconfigure(0, weight=1)

        canvas = tk.Canvas(list_wrap, bg=BG_PANEL, highlightthickness=0, bd=0)
        sb = tk.Scrollbar(list_wrap, orient=tk.VERTICAL, command=canvas.yview,
                          bg=BG_PANEL, troughcolor=BG_PANEL,
                          activebackground=BG_HOVER, bd=0, highlightthickness=0,
                          width=8, relief=tk.FLAT)
        self.list_inner = tk.Frame(canvas, bg=BG_PANEL)
        self.list_inner.bind("<Configure>",
                              lambda e: canvas.configure(
                                  scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.list_inner,
                             anchor=tk.NW, width=240)
        canvas.configure(yscrollcommand=sb.set)
        canvas.grid(row=0, column=0, sticky="nsew")
        sb.grid(row=0, column=1, sticky="ns")

        for rid in self.room_ids:
            self._build_room_card(self.list_inner, rid)

        try:
            self._bind_mousewheel_recursive(canvas, self.list_inner)
        except Exception:
            pass

        bottom = tk.Frame(left, bg=BG_PANEL)
        bottom.grid(row=2, column=0, sticky="ew", padx=12, pady=12)
        tk.Frame(bottom, bg=BORDER, height=1).pack(fill=tk.X, pady=(0, 12))
        tk.Button(bottom, text="房间管理", command=self._open_room_manager,
                  bg=BG_CARD, fg=ACCENT,
                  activebackground=BG_HOVER, activeforeground=ACCENT,
                  font=FONT_BODY, relief=tk.FLAT, bd=0, padx=12, pady=8,
                  anchor=tk.W, cursor="hand2").pack(fill=tk.X)

    def _build_room_card(self, parent, rid):
        state = self.rooms_state[rid]
        is_cur = (rid == self.current_room)
        card_bg = BG_CARD if is_cur else BG_PANEL
        bar_bg = ACCENT if is_cur else BG_PANEL

        card = tk.Frame(parent, bg=card_bg, cursor="hand2")
        card.pack(fill=tk.X, padx=6, pady=2)

        bar = tk.Frame(card, bg=bar_bg, width=3)
        bar.pack(side=tk.LEFT, fill=tk.Y)
        bar.pack_propagate(False)

        inner = tk.Frame(card, bg=card_bg)
        inner.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=8)

        row1 = tk.Frame(inner, bg=card_bg)
        row1.pack(fill=tk.X)

        avatar_wrap = tk.Frame(row1, bg=card_bg, width=36, height=36,
                                cursor="hand2")
        avatar_wrap.pack(side=tk.LEFT)
        avatar_wrap.pack_propagate(False)
        avatar = tk.Label(avatar_wrap, bg=card_bg, text="", bd=0,
                          relief=tk.FLAT, anchor=tk.CENTER, cursor="hand2")
        avatar.pack(fill=tk.BOTH, expand=True)

        avatar.bind("<Button-1>", lambda e, r=rid: self._show_anchor_detail(r))
        avatar_wrap.bind("<Button-1>",
                          lambda e, r=rid: self._show_anchor_detail(r))

        text_col = tk.Frame(row1, bg=card_bg)
        text_col.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(8, 0))

        name = tk.Label(text_col, text=state["anchor_name"] or f"房间 {rid}",
                        fg=FG_MAIN, bg=card_bg, font=FONT_HEAD, anchor=tk.W,
                        justify=tk.LEFT, wraplength=140)
        name.pack(fill=tk.X)

        sub = tk.Label(text_col, text=f"房间号 {rid}", fg=FG_DIM, bg=card_bg,
                       font=FONT_TINY, anchor=tk.W)
        sub.pack(fill=tk.X, pady=(2, 0))

        dot = tk.Canvas(row1, width=10, height=10, bg=card_bg,
                        highlightthickness=0, bd=0)
        dot.pack(side=tk.RIGHT, anchor=tk.N, padx=(4, 0), pady=4)
        dot.create_oval(2, 2, 8, 8, fill=FG_DIM, outline="", tags="dot")

        row2 = tk.Frame(inner, bg=card_bg)
        row2.pack(fill=tk.X, pady=(6, 0))
        stat = tk.Label(row2, text="", fg=FG_SUB, bg=card_bg,
                        font=FONT_TINY, anchor=tk.W)
        stat.pack(side=tk.LEFT)

        row_area = tk.Frame(inner, bg=card_bg)
        row_area.pack(fill=tk.X, pady=(2, 0))
        area_lbl = tk.Label(row_area, text="", fg=ACCENT, bg=card_bg,
                             font=FONT_TINY, anchor=tk.W, justify=tk.LEFT,
                             wraplength=210)
        area_lbl.pack(fill=tk.X, anchor=tk.W)

        pk_row = tk.Frame(inner, bg=card_bg)
        pk_label = tk.Label(pk_row, text="", fg=DANGER, bg=card_bg,
                            font=FONT_TINY, anchor=tk.W, justify=tk.LEFT,
                            wraplength=210)
        pk_label.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self.room_cards[rid] = {
            "card": card, "bar": bar, "inner": inner, "row1": row1,
            "avatar": avatar, "avatar_wrap": avatar_wrap, "name": name,
            "sub": sub, "dot": dot, "row2": row2, "stat": stat,
            "row_area": row_area, "area": area_lbl,
            "pk_row": pk_row, "pk_label": pk_label,
        }
        for w in (card, bar, inner, row1, name, sub, dot, row2, stat,
                  row_area, area_lbl):
            w.bind("<Button-1>", lambda e, r=rid: self._switch_room(r))
        self._update_room_card_status(rid)

    def _validate_entry(self, new_text):
        try:
            return len(new_text) <= DANMU_MAX_LEN
        except Exception:
            return True

    def _build_middle(self, parent):
        mid = tk.Frame(parent, bg=BG_ROOT)
        mid.grid(row=0, column=1, sticky="nsew")
        mid.grid_rowconfigure(2, weight=1)
        mid.grid_columnconfigure(0, weight=1)

        header = tk.Frame(mid, bg=BG_PANEL, highlightthickness=1,
                          highlightbackground=BORDER)
        header.grid(row=0, column=0, sticky="ew", pady=(0, 8))

        title_row = tk.Frame(header, bg=BG_PANEL)
        title_row.pack(fill=tk.X, padx=18, pady=(14, 10))

        header_avatar_wrap = tk.Frame(title_row, bg=BG_PANEL, width=56,
                                       height=56, cursor="hand2")
        header_avatar_wrap.pack(side=tk.LEFT)
        header_avatar_wrap.pack_propagate(False)
        self.header_avatar_label = tk.Label(header_avatar_wrap, bg=BG_PANEL,
                                             text="", bd=0, relief=tk.FLAT,
                                             anchor=tk.CENTER, cursor="hand2")
        self.header_avatar_label.pack(fill=tk.BOTH, expand=True)
        self.header_avatar_label.bind(
            "<Button-1>", lambda e: self._show_current_anchor_detail())
        header_avatar_wrap.bind(
            "<Button-1>", lambda e: self._show_current_anchor_detail())

        title_col = tk.Frame(title_row, bg=BG_PANEL)
        title_col.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(12, 0))

        self.title_label = tk.Label(title_col, text="等待连接...", fg=FG_MAIN,
                                     bg=BG_PANEL, font=FONT_TITLE, anchor=tk.W,
                                     justify=tk.LEFT)
        self.title_label.pack(fill=tk.X, anchor=tk.W)

        self.anchor_subtitle = tk.Label(title_col, text="", fg=FG_SUB,
                                         bg=BG_PANEL, font=FONT_SMALL,
                                         anchor=tk.W, cursor="hand2")
        self.anchor_subtitle.pack(fill=tk.X, pady=(2, 0))
        self.anchor_subtitle.bind(
            "<Button-1>", lambda e: self._show_current_anchor_detail())

        self.account_btn = tk.Button(
            title_row, text="未登录", command=self._on_account_click,
            bg=BG_CARD, fg=FG_SUB, activebackground=BG_HOVER,
            activeforeground=FG_MAIN, font=FONT_SMALL, relief=tk.FLAT, bd=0,
            padx=10, pady=4, cursor="hand2", compound=tk.LEFT)
        self.account_btn.pack(side=tk.RIGHT, padx=(8, 0))

        tk.Button(title_row, text="PK", command=self._toggle_pk_panel,
                  bg=BG_CARD, fg=DANGER, activebackground=BG_HOVER,
                  activeforeground=DANGER, font=FONT_HEAD, relief=tk.FLAT,
                  bd=0, padx=14, pady=4,
                  cursor="hand2").pack(side=tk.RIGHT, padx=(0, 6))

        tk.Button(title_row, text="直播画面", command=self._toggle_live_dialog,
                  bg=BG_CARD, fg=ACCENT, activebackground=BG_HOVER,
                  activeforeground=ACCENT, font=FONT_HEAD, relief=tk.FLAT,
                  bd=0, padx=14, pady=4,
                  cursor="hand2").pack(side=tk.RIGHT, padx=(0, 6))

        tk.Button(title_row, text="互动消息",
                  command=self._toggle_interact_window,
                  bg=BG_CARD, fg=INFO, activebackground=BG_HOVER,
                  activeforeground=INFO, font=FONT_HEAD, relief=tk.FLAT,
                  bd=0, padx=14, pady=4,
                  cursor="hand2").pack(side=tk.RIGHT, padx=(0, 6))

        tk.Button(title_row, text="点赞 x1000",
                  command=self._on_like_report_current,
                  bg=BG_CARD, fg=WARN, activebackground=BG_HOVER,
                  activeforeground=WARN, font=FONT_HEAD, relief=tk.FLAT,
                  bd=0, padx=14, pady=4,
                  cursor="hand2").pack(side=tk.RIGHT, padx=(0, 6))

        caps_row = tk.Frame(header, bg=BG_PANEL)
        caps_row.pack(fill=tk.X, padx=18, pady=(0, 14))
        for k in TOP_KEYS:
            self.capsule_labels[k] = self._make_capsule(caps_row, k)

        self.area_capsule = tk.Frame(caps_row, bg=BG_CARD)
        self.area_capsule.pack(side=tk.RIGHT)
        tk.Label(self.area_capsule, text="分区", fg=FG_DIM, bg=BG_CARD,
                 font=FONT_TINY, padx=8, pady=3).pack(side=tk.LEFT)
        self.area_val_label = tk.Label(self.area_capsule, text="—", fg=ACCENT,
                                        bg=BG_CARD, font=FONT_SMALL, padx=8,
                                        pady=3, width=18, anchor=tk.W)
        self.area_val_label.pack(side=tk.LEFT)

        self.pk_panel = tk.Frame(mid, bg=BG_PANEL, highlightthickness=1,
                                  highlightbackground=DANGER)
        self.pk_panel.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        self._build_pk_panel()
        self.pk_panel.grid_remove()

        event_wrap = tk.Frame(mid, bg=BG_PANEL, highlightthickness=1,
                              highlightbackground=BORDER)
        event_wrap.grid(row=2, column=0, sticky="nsew")
        event_wrap.grid_rowconfigure(0, weight=1)
        event_wrap.grid_columnconfigure(0, weight=1)

        self.event_text = tk.Text(event_wrap, bg=BG_PANEL, fg=FG_MAIN,
                                   font=FONT_BODY, wrap=tk.WORD,
                                   state=tk.DISABLED, relief=tk.FLAT, bd=0,
                                   insertbackground=FG_MAIN, padx=16, pady=12,
                                   selectbackground=BG_HOVER,
                                   selectforeground=FG_MAIN)
        self.event_text.grid(row=0, column=0, sticky="nsew")

        ev_sb = tk.Scrollbar(event_wrap, orient=tk.VERTICAL,
                              command=self.event_text.yview, bg=BG_PANEL,
                              troughcolor=BG_PANEL, activebackground=BG_HOVER,
                              bd=0, highlightthickness=0, width=8, relief=tk.FLAT)
        ev_sb.grid(row=0, column=1, sticky="ns")
        self.event_text.configure(yscrollcommand=ev_sb.set)

        for tag, color in EVENT_COLORS.items():
            self.event_text.tag_config(tag, foreground=color)
        self.event_text.tag_config("ts", foreground=FG_DIM, font=FONT_TS)

        input_wrap = tk.Frame(mid, bg=BG_PANEL, highlightthickness=1,
                              highlightbackground=BORDER)
        input_wrap.grid(row=3, column=0, sticky="ew", pady=(8, 0))
        inner = tk.Frame(input_wrap, bg=BG_PANEL)
        inner.pack(fill=tk.X, padx=16, pady=12)

        tk.Label(inner, text="发送弹幕", fg=FG_SUB, bg=BG_PANEL,
                 font=FONT_SMALL).pack(side=tk.LEFT, padx=(0, 12))

        self.emote_btn = tk.Button(
            inner, text="表情", command=self._toggle_emote_panel,
            bg=BG_CARD, fg=ACCENT, activebackground=BG_HOVER,
            activeforeground=ACCENT, font=FONT_SMALL, relief=tk.FLAT,
            bd=0, padx=12, pady=6, cursor="hand2")
        self.emote_btn.pack(side=tk.LEFT, padx=(0, 8))

        entry_wrap = tk.Frame(inner, bg=BG_INPUT, highlightthickness=1,
                              highlightbackground=BORDER)
        entry_wrap.pack(side=tk.LEFT, fill=tk.X, expand=True)

        vcmd = (self.root.register(self._validate_entry), "%P")
        self.entry = tk.Entry(entry_wrap, bg=BG_INPUT, fg=FG_MAIN,
                              insertbackground=FG_MAIN, font=FONT_BODY,
                              relief=tk.FLAT, bd=0,
                              validate="key", validatecommand=vcmd)
        self.entry.pack(fill=tk.X, padx=12, pady=8)
        self.entry.bind("<Return>", lambda e: self._on_send())

        tk.Button(inner, text="发送", command=self._on_send, bg=ACCENT,
                  fg="#0d1117", activebackground="#26b8a4",
                  activeforeground="#0d1117", font=FONT_HEAD, relief=tk.FLAT,
                  bd=0, padx=24, pady=6,
                  cursor="hand2").pack(side=tk.RIGHT, padx=(12, 0))

    # ============================================================
    #  表情面板（分页 + 完整名称 + 图片按比例 + 大表情直接发送）
    # ============================================================
    def _toggle_emote_panel(self):
        if self._emote_panel and self._emote_panel.winfo_exists():
            self._close_emote_panel()
            return
        self._open_emote_panel()

    def _open_emote_panel(self):
        if not self.send_emoticon_cb or not self.list_emoticons_cb:
            log("表情功能未配置（缺少 send_emoticon_cb / "
                "list_emoticons_cb）", "UI")
            return
        try:
            pkgs = self.list_emoticons_cb(self.current_room) or []
        except Exception as e:
            log_err(f"获取表情列表失败: {e}")
            return
        if not pkgs:
            log("暂无可用的表情（房间可能尚未连接或没有可用表情）", "UI")
            return

        win = tk.Toplevel(self.root)
        win.title(f"选择表情 · 房间 {self.current_room}")
        win.configure(bg=BG_ROOT)
        win.geometry("1080x820")
        win.minsize(900, 600)
        try:
            win.transient(self.root)
        except Exception:
            pass
        win.protocol("WM_DELETE_WINDOW", self._close_emote_panel)

        # 搜索栏
        search_wrap = tk.Frame(win, bg=BG_PANEL)
        search_wrap.pack(fill=tk.X, padx=8, pady=(8, 4))
        tk.Label(search_wrap, text="搜索", fg=FG_SUB, bg=BG_PANEL,
                 font=FONT_SMALL).pack(side=tk.LEFT, padx=(4, 6))
        entry_wrap = tk.Frame(search_wrap, bg=BG_INPUT,
                              highlightthickness=1,
                              highlightbackground=BORDER)
        entry_wrap.pack(side=tk.LEFT, fill=tk.X, expand=True)
        search_var = tk.StringVar()
        tk.Entry(entry_wrap, textvariable=search_var, bg=BG_INPUT,
                 fg=FG_MAIN, insertbackground=FG_MAIN, font=FONT_SMALL,
                 relief=tk.FLAT, bd=0).pack(fill=tk.X, padx=8, pady=5)
        self._emote_total_lbl = tk.Label(search_wrap, text="",
                                         fg=FG_DIM, bg=BG_PANEL,
                                         font=FONT_TINY)
        self._emote_total_lbl.pack(side=tk.RIGHT, padx=(8, 4))

        # 分页栏（明显按钮）
        page_bar = tk.Frame(win, bg=BG_PANEL)
        page_bar.pack(fill=tk.X, padx=8, pady=(4, 6))
        self._emote_prev_btn = tk.Button(
            page_bar, text="◀ 上一页", command=self._emote_prev_page,
            bg=ACCENT, fg="#0d1117", activebackground=ACCENT_HOVER,
            activeforeground="#0d1117", font=FONT_PAGE_BTN,
            relief=tk.FLAT, bd=0, padx=28, pady=8, cursor="hand2",
            disabledforeground=FG_DIM)
        self._emote_prev_btn.pack(side=tk.LEFT)
        self._emote_page_info_lbl = tk.Label(
            page_bar, text="第 1 / 1 页", fg=FG_MAIN, bg=BG_PANEL,
            font=FONT_PAGE_INFO, padx=24)
        self._emote_page_info_lbl.pack(side=tk.LEFT)
        self._emote_next_btn = tk.Button(
            page_bar, text="下一页 ▶", command=self._emote_next_page,
            bg=ACCENT, fg="#0d1117", activebackground=ACCENT_HOVER,
            activeforeground="#0d1117", font=FONT_PAGE_BTN,
            relief=tk.FLAT, bd=0, padx=28, pady=8, cursor="hand2",
            disabledforeground=FG_DIM)
        self._emote_next_btn.pack(side=tk.LEFT)
        tk.Label(page_bar,
                 text=f"（每页 {EMOTE_PAGE_SIZE} 个分区）",
                 fg=FG_DIM, bg=BG_PANEL, font=FONT_TINY).pack(
                     side=tk.LEFT, padx=(16, 0))

        hint = tk.Label(win,
                        text="提示：大表情（装扮 / UP 主 / 房间专属）点击后直接发送；"
                             "小表情（官方黄脸）点击后填入输入框，可与文字混排",
                        fg=FG_DIM, bg=BG_PANEL, font=FONT_TINY,
                        anchor=tk.W)
        hint.pack(fill=tk.X, padx=12, pady=(0, 4))

        self._emote_panel = win
        self._emote_panel_search = search_var
        self._emote_panel_emotes = pkgs
        self._emote_panel_nb = None
        # 打开面板时重置缓存（会话级）
        self._emote_image_refs = {}
        self._emote_cover_refs = {}
        self._emote_cover_urls = {}
        self._emote_loaded_tabs = set()
        self._emote_tab_widgets = {}
        self._emote_pending_after = {}
        self._emote_page = 0

        search_var.trace_add("write",
                             lambda *a: self._on_emote_search_changed())
        self._render_all_emote_tabs()

    def _on_emote_search_changed(self):
        self._emote_page = 0
        self._render_all_emote_tabs()

    def _render_all_emote_tabs(self):
        if not (self._emote_panel and self._emote_panel.winfo_exists()):
            return
        for aid in list(self._emote_pending_after.values()):
            try:
                self.root.after_cancel(aid)
            except Exception:
                pass
        self._emote_pending_after.clear()

        kw = ""
        if self._emote_panel_search is not None:
            try:
                kw = self._emote_panel_search.get() or ""
            except Exception:
                kw = ""
        kwl = kw.strip().lower()

        pkgs = self._emote_panel_emotes or []
        filtered = []
        for pkg in pkgs:
            if not isinstance(pkg, dict):
                continue
            pkg_name = pkg.get("display_name") or pkg.get("pkg_name") or ""
            ems = pkg.get("emoticons") or []
            if not ems:
                continue
            if kwl:
                hit = []
                for em in ems:
                    hay = (str(em.get("emoji") or "") + " " +
                           str(em.get("unique") or "") + " " +
                           pkg_name).lower()
                    if kwl in hay:
                        hit.append(em)
                if not hit:
                    continue
                filtered.append((pkg, hit))
            else:
                filtered.append((pkg, ems))

        self._emote_filtered = filtered
        self._render_emote_tabs_page()

    def _render_emote_tabs_page(self):
        if not (self._emote_panel and self._emote_panel.winfo_exists()):
            return
        for aid in list(self._emote_pending_after.values()):
            try:
                self.root.after_cancel(aid)
            except Exception:
                pass
        self._emote_pending_after.clear()

        if self._emote_panel_nb is not None:
            try:
                self._emote_panel_nb.destroy()
            except Exception:
                pass
        # 注意：不清空 _emote_image_refs，避免翻页/搜索时图片闪烁
        self._emote_cover_urls = {}
        self._emote_loaded_tabs = set()
        self._emote_tab_widgets = {}

        filtered = self._emote_filtered
        total = len(filtered)
        page_size = EMOTE_PAGE_SIZE
        total_pages = max(1, (total + page_size - 1) // page_size)

        if self._emote_page < 0:
            self._emote_page = 0
        if self._emote_page >= total_pages:
            self._emote_page = total_pages - 1

        start = self._emote_page * page_size
        end = min(start + page_size, total)
        page_items = filtered[start:end]

        total_em = sum(len(ems) for _, ems in filtered)
        if self._widget_alive(self._emote_total_lbl):
            try:
                self._emote_total_lbl.config(
                    text=f"{total} 个分区 · {total_em} 个表情")
            except Exception:
                pass
        if self._widget_alive(self._emote_page_info_lbl):
            try:
                self._emote_page_info_lbl.config(
                    text=f"第 {self._emote_page + 1} / {total_pages} 页")
            except Exception:
                pass

        # 分页按钮状态
        can_prev = self._emote_page > 0
        can_next = self._emote_page < total_pages - 1
        if self._widget_alive(self._emote_prev_btn):
            try:
                if can_prev:
                    self._emote_prev_btn.config(
                        state=tk.NORMAL, bg=ACCENT, fg="#0d1117")
                else:
                    self._emote_prev_btn.config(
                        state=tk.DISABLED, bg=BG_HOVER, fg=FG_DIM)
            except Exception:
                pass
        if self._widget_alive(self._emote_next_btn):
            try:
                if can_next:
                    self._emote_next_btn.config(
                        state=tk.NORMAL, bg=ACCENT, fg="#0d1117")
                else:
                    self._emote_next_btn.config(
                        state=tk.DISABLED, bg=BG_HOVER, fg=FG_DIM)
            except Exception:
                pass

        nb = ttk.Notebook(self._emote_panel)
        nb.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))
        nb.bind("<<NotebookTabChanged>>", self._on_emote_tab_changed)
        self._emote_panel_nb = nb

        if not page_items:
            empty = tk.Frame(nb, bg=BG_PANEL)
            nb.add(empty, text="  无匹配  ")
            tk.Label(empty, text="没有匹配的表情", fg=FG_DIM, bg=BG_PANEL,
                     font=FONT_BODY).pack(pady=60)
            return

        for pkg, ems in page_items:
            # 完整显示 Tab 名，不截断
            title = pkg.get("display_name") or pkg.get("pkg_name") or "表情"
            tab = tk.Frame(nb, bg=BG_PANEL)
            nb.add(tab, text=f"  {title} ({len(ems)})  ")
            self._emote_tab_widgets[id(tab)] = (pkg, ems)

            cover = pkg.get("cover") or ""
            if cover:
                if cover.startswith("http://"):
                    cover = "https://" + cover[7:]
                cached = self._emote_cover_refs.get(cover)
                if cached is not None:
                    try:
                        nb.tab(tab, image=cached, compound="left")
                    except Exception:
                        pass
                else:
                    self._emote_cover_urls[id(tab)] = cover
                    self._load_emote_cover_async(id(tab), cover)

        try:
            self.root.after(0, self._on_emote_tab_changed)
        except Exception:
            pass

    def _emote_prev_page(self):
        if self._emote_page > 0:
            self._emote_page -= 1
            self._render_emote_tabs_page()

    def _emote_next_page(self):
        total = len(self._emote_filtered)
        page_size = EMOTE_PAGE_SIZE
        total_pages = max(1, (total + page_size - 1) // page_size)
        if self._emote_page < total_pages - 1:
            self._emote_page += 1
            self._render_emote_tabs_page()

    def _on_emote_tab_changed(self, _event=None):
        nb = self._emote_panel_nb
        if nb is None or not self._widget_alive(nb):
            return
        try:
            cur = nb.select()
        except Exception:
            return
        if not cur:
            return
        try:
            tab = nb.nametowidget(cur)
        except Exception:
            return
        key = id(tab)
        if key in self._emote_loaded_tabs:
            return
        info = self._emote_tab_widgets.get(key)
        if not info:
            return
        pkg, ems = info
        self._emote_loaded_tabs.add(key)
        self._build_emote_tab(tab, ems)

    def _load_emote_cover_async(self, tab_key, url):
        def _worker():
            try:
                img = avatar_cache.load_image(url)
                if img is None:
                    return
                resized = img.resize((20, 20), Image.LANCZOS)
                self.q.put(("emote_cover", tab_key, resized, url))
            except Exception:
                pass
        threading.Thread(target=_worker, daemon=True,
                         name="emote-cover").start()

    def _build_emote_tab(self, parent, emotes):
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)
        canvas = tk.Canvas(parent, bg=BG_PANEL, highlightthickness=0, bd=0)
        sb = tk.Scrollbar(parent, orient=tk.VERTICAL, command=canvas.yview,
                          bg=BG_PANEL, troughcolor=BG_PANEL,
                          activebackground=BG_HOVER, bd=0,
                          highlightthickness=0, width=8, relief=tk.FLAT)
        canvas.grid(row=0, column=0, sticky="nsew")
        sb.grid(row=0, column=1, sticky="ns")
        inner = tk.Frame(canvas, bg=BG_PANEL)
        win_id = canvas.create_window((0, 0), window=inner, anchor=tk.NW)

        def _on_inner(_e):
            try:
                canvas.configure(scrollregion=canvas.bbox("all"))
            except Exception:
                pass

        def _on_canvas(e):
            try:
                canvas.itemconfigure(win_id, width=e.width)
            except Exception:
                pass

        inner.bind("<Configure>", _on_inner)
        canvas.bind("<Configure>", _on_canvas)
        canvas.configure(yscrollcommand=sb.set)
        try:
            self._bind_mousewheel(canvas, inner)
        except Exception:
            pass

        # 4 列布局
        for c in range(4):
            inner.grid_columnconfigure(c, weight=1, uniform="emote")

        state = {"idx": 0, "inner": inner, "emotes": emotes,
                 "canvas": canvas, "win_id": win_id, "key": id(inner)}
        self._fill_emote_batch(state)

    def _fill_emote_batch(self, state):
        inner = state["inner"]
        if not self._widget_alive(inner):
            self._emote_pending_after.pop(state.get("key"), None)
            return
        emotes = state["emotes"]
        idx = state["idx"]
        end = min(idx + 16, len(emotes))
        for i in range(idx, end):
            em = emotes[i]
            r, c = divmod(i, 4)
            try:
                self._build_emote_cell(inner, r, c, em)
            except Exception:
                pass
        state["idx"] = end
        if end < len(emotes):
            try:
                aid = inner.after(1, lambda: self._fill_emote_batch(state))
                self._emote_pending_after[state["key"]] = aid
            except Exception:
                pass
        else:
            self._emote_pending_after.pop(state.get("key"), None)
            try:
                canvas = state["canvas"]
                canvas.update_idletasks()
                canvas.configure(scrollregion=canvas.bbox("all"))
            except Exception:
                pass

    def _build_emote_cell(self, parent, r, c, em):
        """单元格：固定图片容器（168×116）+ 名字最多 4 行"""
        cell = tk.Frame(parent, bg=BG_CARD, cursor="hand2",
                        highlightthickness=1, highlightbackground=BORDER,
                        width=180, height=260)
        cell.grid(row=r, column=c, padx=6, pady=6, sticky="nsew")
        cell.grid_propagate(False)

        # 图片容器：宽 168、高 116（= 100 最大图高 + 16 上下余量）
        img_wrap = tk.Frame(cell, bg=BG_CARD, width=168, height=116)
        img_wrap.pack(fill=tk.X, padx=6, pady=(8, 0))
        img_wrap.pack_propagate(False)
        img_lbl = tk.Label(img_wrap, bg=BG_CARD, text="", bd=0, cursor="hand2")
        img_lbl.pack(expand=True)

        name = (em.get("emoji") or em.get("descript") or "?")
        name = name.strip("[]")
        if not name:
            name = "?"
        if len(name) > 30:
            name = name[:28] + "…"
        name_lbl = tk.Label(cell, text=name, fg=FG_MAIN, bg=BG_CARD,
                            font=("Microsoft YaHei UI", 10, "bold"),
                            wraplength=164,
                            justify=tk.CENTER, cursor="hand2",
                            height=4)
        name_lbl.pack(fill=tk.X, padx=6, pady=(8, 10))

        def _pick(_e=None, target=em):
            self._on_emote_clicked(target)

        for w in (cell, img_wrap, img_lbl, name_lbl):
            w.bind("<Button-1>", _pick)
            w.bind("<Enter>",
                   lambda e, f=cell: f.config(highlightbackground=ACCENT))
            w.bind("<Leave>",
                   lambda e, f=cell: f.config(highlightbackground=BORDER))

        url = em.get("url") or ""
        if url:
            if url.startswith("http://"):
                url = "https://" + url[7:]
            # 命中缓存：直接显示，避免闪烁
            cached = self._emote_image_refs.get(url)
            if cached is not None:
                try:
                    img_lbl.config(image=cached, text="")
                    img_lbl.image = cached
                except Exception:
                    pass
            else:
                self._load_emote_image_async(img_lbl, url)

    @staticmethod
    def _fit_image_by_ratio(img, max_w=168, max_h=100):
        """按原始宽高比缩放，塞进 168×100 外框。
        长条形表情不会被拉伸变形。
        """
        try:
            iw, ih = img.width, img.height
        except Exception:
            return img
        if iw <= 0 or ih <= 0:
            return img
        scale = min(max_w / iw, max_h / ih)
        nw = max(1, int(iw * scale))
        nh = max(1, int(ih * scale))
        try:
            return img.resize((nw, nh), Image.LANCZOS)
        except Exception:
            return img

    def _load_emote_image_async(self, label, url):
        def _worker():
            try:
                img = avatar_cache.load_image(url)
                if img is None:
                    return
                # 按原始宽高比缩放
                resized = self._fit_image_by_ratio(img, 168, 100)
                self.q.put(("emote_image", label, resized, url))
            except Exception:
                pass
        threading.Thread(target=_worker, daemon=True,
                         name="emote-img").start()

    def _on_emote_clicked(self, em):
        """大表情（upower_ / room_）直接发送；小表情填充到输入框"""
        unique = em.get("unique") or ""
        emoji = em.get("emoji") or ""

        # ★ 大表情：直接发送
        is_large = (unique.startswith("upower_")
                    or unique.startswith("room_"))
        if is_large:
            if not self.send_emoticon_cb:
                return
            try:
                res = self.send_emoticon_cb(self.current_room, unique)
            except Exception as e:
                log_err(f"发送大表情异常: {e}")
                return
            if isinstance(res, tuple) and len(res) >= 1 and res[0] is False:
                err = res[1] if len(res) > 1 else "未知错误"
                log_err(f"发送大表情失败: {err}")
            self._close_emote_panel()
            return

        # ★ 小表情：填充到输入框
        insert_text = emoji or unique
        if not insert_text:
            return

        try:
            cur = self.entry.index(tk.INSERT)
        except Exception:
            cur = tk.END

        try:
            self.entry.insert(cur, insert_text)
        except Exception:
            try:
                self.entry.insert(tk.END, insert_text)
            except Exception:
                pass

        try:
            txt = self.entry.get()
            if len(txt) > DANMU_MAX_LEN:
                extra = len(txt) - DANMU_MAX_LEN
                self.entry.delete(0, extra)
        except Exception:
            pass

        try:
            self.entry.focus_set()
        except Exception:
            pass

    def _close_emote_panel(self):
        for aid in list(self._emote_pending_after.values()):
            try:
                self.root.after_cancel(aid)
            except Exception:
                pass
        self._emote_pending_after.clear()
        if self._emote_panel and self._emote_panel.winfo_exists():
            try:
                self._emote_panel.destroy()
            except Exception:
                pass
        self._emote_panel = None
        self._emote_panel_nb = None
        self._emote_panel_search = None
        self._emote_panel_emotes = []
        self._emote_image_refs = {}
        self._emote_cover_refs = {}
        self._emote_cover_urls = {}
        self._emote_total_lbl = None
        self._emote_loaded_tabs = set()
        self._emote_tab_widgets = {}
        self._emote_filtered = []
        self._emote_page = 0
        self._emote_page_info_lbl = None
        self._emote_prev_btn = None
        self._emote_next_btn = None

    # ============================================================
    #  点赞 x1000
    # ============================================================
    def _on_like_report_current(self):
        rid = self.current_room
        if not rid:
            return
        if not self.like_report_cb:
            try:
                from tkinter import messagebox
                messagebox.showwarning("提示", "点赞回调未配置",
                                       parent=self.root)
            except Exception:
                pass
            return
        try:
            ok, msg = self.like_report_cb(rid, 1000)
        except Exception as e:
            log_err(f"点赞上报回调异常: {e}")
            return
        if not ok and msg:
            try:
                from tkinter import messagebox
                messagebox.showwarning("点赞失败", msg, parent=self.root)
            except Exception:
                pass

    # ============================================================
    #  红包中奖 / 开奖
    # ============================================================
    def _on_rp_win_me(self, rid, value):
        try:
            aw = value.get("award_name", "礼物")
            pr = int(value.get("award_price", 0) or 0)
            tn = int(value.get("total_num", 0) or 0)
            lot_id = value.get("lot_id", 0)
            ps = f"（{pr / 100:.2f}元）" if pr > 0 else ""

            ts = time.strftime("%H:%M:%S")
            msg = (f"[中奖] 恭喜中奖！红包 {lot_id} · "
                   f"{aw}{ps} · 共 {tn} 人")

            state = self.rooms_state.get(rid)
            if state:
                state["event_buffer"].append((ts, msg, "magenta", None))
                if len(state["event_buffer"]) > self.max_event_lines:
                    state["event_buffer"] = \
                        state["event_buffer"][-self.max_event_lines:]

            if rid == self.current_room:
                self._append_event_visible(ts, msg, "magenta", None)

            try:
                from tkinter import messagebox
                messagebox.showinfo(
                    "恭喜中奖",
                    f"红包 ID：{lot_id}\n"
                    f"奖品：{aw}\n"
                    f"价值：{pr / 100:.2f} 元\n"
                    f"共 {tn} 人获奖",
                    parent=self.root)
            except Exception:
                pass
        except Exception as e:
            log_err(f"处理红包中奖失败: {e}")

    def _on_rp_winners(self, rid, value):
        try:
            winners = value.get("winners", []) or []
            if not winners:
                return
            lot_id = value.get("lot_id", 0)
            tn = int(value.get("total_num", 0) or 0)

            parts = []
            for w in winners[:8]:
                n = w.get("uname", "?")
                a = w.get("award_name", "")
                p = int(w.get("award_price", 0) or 0)
                if a and p > 0:
                    parts.append(f"{n}[{a}{p / 100:.1f}元]")
                elif a:
                    parts.append(f"{n}[{a}]")
                else:
                    parts.append(n)
            s = ", ".join(parts)
            if len(winners) > 8:
                s += f" 等 {len(winners)} 人"

            ts = time.strftime("%H:%M:%S")
            msg = f"[红包开奖] 红包 {lot_id} · 共 {tn} 人 · {s}"

            state = self.rooms_state.get(rid)
            if state:
                state["event_buffer"].append((ts, msg, "yellow", None))
                if len(state["event_buffer"]) > self.max_event_lines:
                    state["event_buffer"] = \
                        state["event_buffer"][-self.max_event_lines:]

            if rid == self.current_room:
                self._append_event_visible(ts, msg, "yellow", None)
        except Exception as e:
            log_err(f"处理红包开奖失败: {e}")

    def _toggle_interact_window(self):
        if self._interact_window and self._interact_window.winfo_exists():
            self._interact_window.lift()
            self._interact_window.focus_set()
            return
        self._open_interact_window()

    def _open_interact_window(self):
        win = tk.Toplevel(self.root)
        win.title(f"互动消息 · 房间 {self.current_room}")
        win.configure(bg=BG_ROOT)
        win.geometry("620x620")
        win.minsize(400, 360)
        win.transient(self.root)
        win.protocol("WM_DELETE_WINDOW", self._on_interact_window_close)

        header = tk.Frame(win, bg=BG_PANEL)
        header.pack(fill=tk.X, padx=8, pady=(8, 4))
        self._interact_room_lbl = tk.Label(header,
                                            text=f"房间 {self.current_room}",
                                            fg=FG_MAIN, bg=BG_PANEL,
                                            font=FONT_HEAD)
        self._interact_room_lbl.pack(side=tk.LEFT, padx=(4, 12))
        tk.Button(header, text="清空", command=self._clear_interact,
                  bg=BG_CARD, fg=FG_SUB, activebackground=BG_HOVER,
                  activeforeground=FG_MAIN, font=FONT_TINY, relief=tk.FLAT,
                  bd=0, padx=10, pady=2,
                  cursor="hand2").pack(side=tk.RIGHT)

        text_wrap = tk.Frame(win, bg=BG_PANEL, highlightthickness=1,
                              highlightbackground=BORDER)
        text_wrap.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))
        text_wrap.grid_rowconfigure(0, weight=1)
        text_wrap.grid_columnconfigure(0, weight=1)
        self._interact_text = tk.Text(text_wrap, bg=BG_PANEL, fg=FG_SUB,
                                       font=FONT_SMALL, wrap=tk.WORD,
                                       state=tk.DISABLED, relief=tk.FLAT, bd=0,
                                       insertbackground=FG_MAIN, padx=12, pady=8,
                                       selectbackground=BG_HOVER,
                                       selectforeground=FG_MAIN)
        self._interact_text.grid(row=0, column=0, sticky="nsew")
        sb = tk.Scrollbar(text_wrap, orient=tk.VERTICAL,
                          command=self._interact_text.yview, bg=BG_PANEL,
                          troughcolor=BG_PANEL, activebackground=BG_HOVER,
                          bd=0, highlightthickness=0, width=8, relief=tk.FLAT)
        sb.grid(row=0, column=1, sticky="ns")
        self._interact_text.configure(yscrollcommand=sb.set)
        for tag, color in EVENT_COLORS.items():
            self._interact_text.tag_config(tag, foreground=color)
        self._interact_text.tag_config("ts", foreground=FG_DIM, font=FONT_TS)

        self._interact_window = win
        self._interact_room_id = self.current_room
        state = self.rooms_state.get(self.current_room)
        if state:
            self._rebuild_interact(state.get("interact_buffer", []))

    def _on_interact_window_close(self):
        if self._interact_window and self._interact_window.winfo_exists():
            try:
                self._interact_window.destroy()
            except Exception:
                pass
        self._interact_window = None
        self._interact_text = None
        self._interact_room_lbl = None
        self._interact_room_id = 0

    def _clear_interact(self):
        state = self.rooms_state.get(self.current_room)
        if state:
            state["interact_buffer"] = []
        if self._widget_alive(self._interact_text):
            try:
                self._interact_text.configure(state=tk.NORMAL)
                self._interact_text.delete("1.0", tk.END)
                self._interact_text.configure(state=tk.DISABLED)
            except Exception:
                pass

    def _append_interact(self, ts, msg, style, color_info=None):
        if not self._widget_alive(self._interact_text):
            return
        if self._interact_room_id and self._interact_room_id != self.current_room:
            return
        try:
            self._interact_text.configure(state=tk.NORMAL)
            self._interact_text.insert(tk.END, f"[{ts}] ", "ts")
            self._interact_text.insert(tk.END, msg + "\n", style or "dim")
            n = int(self._interact_text.index('end-1c').split('.')[0])
            if n > self.max_interact_lines:
                self._interact_text.delete("1.0",
                                            f"{n - self.max_interact_lines + 1}.0")
            self._interact_text.see(tk.END)
            self._interact_text.configure(state=tk.DISABLED)
        except Exception:
            pass

    def _rebuild_interact(self, buffer):
        if not self._widget_alive(self._interact_text):
            return
        try:
            self._interact_text.configure(state=tk.NORMAL)
            self._interact_text.delete("1.0", tk.END)
            for item in buffer[-self.max_interact_lines:]:
                ts = item[0]
                msg = item[1]
                style = item[2] if len(item) > 2 else "dim"
                self._interact_text.insert(tk.END, f"[{ts}] ", "ts")
                self._interact_text.insert(tk.END, msg + "\n", style or "dim")
            self._interact_text.see(tk.END)
            self._interact_text.configure(state=tk.DISABLED)
        except Exception:
            pass

    def _build_right(self, parent):
        right = tk.Frame(parent, bg=BG_PANEL, highlightthickness=1,
                         highlightbackground=BORDER)
        right.grid(row=0, column=2, sticky="nsew", padx=(8, 0))
        right.grid_propagate(False)
        right.grid_rowconfigure(3, weight=1)
        right.grid_columnconfigure(0, weight=1)

        header = tk.Frame(right, bg=BG_PANEL)
        header.grid(row=0, column=0, sticky="ew", padx=16, pady=(16, 6))
        tk.Label(header, text="直播间数据", fg=FG_MAIN, bg=BG_PANEL,
                 font=FONT_TITLE, anchor=tk.W).pack(anchor=tk.W)

        watched_card = tk.Frame(right, bg=BG_CARD)
        watched_card.grid(row=1, column=0, sticky="ew", padx=10, pady=(0, 8))
        tk.Label(watched_card, text="看过人数", fg=FG_SUB, bg=BG_CARD,
                 font=FONT_SMALL, anchor=tk.W).pack(fill=tk.X, padx=14,
                                                     pady=(10, 0))
        self.watched_val_label = tk.Label(watched_card, text="0", fg=ACCENT,
                                           bg=BG_CARD, font=FONT_WATCHED_BIG,
                                           anchor=tk.W)
        self.watched_val_label.pack(fill=tk.X, padx=14, pady=(0, 10))

        rank_header = tk.Frame(right, bg=BG_PANEL)
        rank_header.grid(row=2, column=0, sticky="ew", padx=16, pady=(6, 4))
        tk.Label(rank_header, text="高能榜", fg=FG_MAIN, bg=BG_PANEL,
                 font=FONT_HEAD, anchor=tk.W).pack(side=tk.LEFT)
        self.rank_count_label = tk.Label(rank_header, text="", fg=FG_DIM,
                                          bg=BG_PANEL, font=FONT_SMALL)
        self.rank_count_label.pack(side=tk.RIGHT)

        rank_wrap = tk.Frame(right, bg=BG_PANEL)
        rank_wrap.grid(row=3, column=0, sticky="nsew", padx=8, pady=(0, 10))
        rank_wrap.grid_rowconfigure(0, weight=1)
        rank_wrap.grid_columnconfigure(0, weight=1)

        canvas = tk.Canvas(rank_wrap, bg=BG_PANEL, highlightthickness=0, bd=0)
        sb = tk.Scrollbar(rank_wrap, orient=tk.VERTICAL, command=canvas.yview,
                          bg=BG_PANEL, troughcolor=BG_PANEL,
                          activebackground=BG_HOVER, bd=0, highlightthickness=0,
                          width=8, relief=tk.FLAT)
        inner = tk.Frame(canvas, bg=BG_PANEL)
        inner.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor=tk.NW, width=270)
        canvas.configure(yscrollcommand=sb.set)
        canvas.grid(row=0, column=0, sticky="nsew")
        sb.grid(row=0, column=1, sticky="ns")

        self._rank_canvas = canvas
        self._rank_sb = sb
        self.rank_inner = inner

    def _ensure_area_loaded(self, force=False):
        if self._area_loaded and self._area_mgr.loaded and not force:
            return

        def _worker():
            try:
                ok = self._area_mgr.fetch(force=force)
            except Exception:
                ok = False

            def _done():
                if not self._root_alive():
                    return
                self._area_loaded = True
                self._refresh_all_area_labels()
                self._refresh_area_capsule()
                if ok:
                    log(f"分区列表加载完成："
                        f"{len(self._area_mgr.parent_areas)} 个父分区", "AREA")
            try:
                self.root.after(0, _done)
            except Exception:
                pass
        threading.Thread(target=_worker, daemon=True).start()

    def _fetch_all_rooms_area(self):
        for rid in self.room_ids:
            state = self.rooms_state.get(rid)
            if state and (state.get("area_id") or state.get("area_name")):
                self._update_room_card_area(rid)
                continue
            cached = _AREA_MEM_CACHE.get(rid)
            if cached:
                state["area_id"] = cached.get("area_id", 0)
                state["area_name"] = cached.get("area_name", "")
                self._update_room_card_area(rid)
                continue
            self._fetch_area_info(rid)

    def _fetch_area_info(self, rid):
        if rid in self._area_fetch_requested:
            return
        state = self.rooms_state.get(rid)
        if state and (state.get("area_id") or state.get("area_name")):
            return
        self._area_fetch_requested.add(rid)

        def _worker():
            try:
                url = (f"https://api.live.bilibili.com/room/v1/Room/"
                       f"get_info?room_id={rid}")
                req = urllib.request.Request(url, headers={
                    "User-Agent": _UA, "Referer": "https://live.bilibili.com/"})
                with urllib.request.urlopen(req, timeout=8) as r:
                    data = json.loads(r.read().decode("utf-8"))
                if data.get("code") == 0:
                    d = data.get("data", {}) or {}
                    area_id = d.get("area_id", 0) or 0
                    area_name = d.get("area_name", "") or ""
                    if area_id or area_name:
                        self.root.after(0, lambda: self._on_area_fetched(
                            rid, area_id, area_name))
            except Exception:
                pass
        threading.Thread(target=_worker, daemon=True).start()

    def _on_area_fetched(self, rid, area_id, area_name):
        if not self._root_alive():
            return
        state = self.rooms_state.get(rid)
        if not state:
            return
        changed = False
        if not state.get("area_id") and area_id:
            state["area_id"] = area_id
            changed = True
        if not state.get("area_name") and area_name:
            state["area_name"] = area_name
            changed = True
        if changed:
            _AREA_MEM_CACHE[rid] = {"area_id": state.get("area_id", 0),
                                     "area_name": state.get("area_name", "")}
            self._update_room_card_area(rid)
            if rid == self.current_room:
                self._refresh_area_capsule()

    def _refresh_all_area_labels(self):
        for rid in self.room_ids:
            self._update_room_card_area(rid)

    def _update_room_card_area(self, rid):
        state = self.rooms_state.get(rid)
        refs = self.room_cards.get(rid)
        if not state or not refs:
            return
        area_lbl = refs.get("area")
        if not area_lbl or not self._widget_alive(area_lbl):
            return
        area_id = state.get("area_id", 0)
        area_name = state.get("area_name", "")
        if not area_id and not area_name:
            text = ""
        elif self._area_mgr.loaded and area_id:
            full = self._area_mgr.get_full_path(area_id)
            text = full if (full and full != str(area_id)) else area_name
        else:
            text = area_name
        try:
            if area_lbl.cget("text") != text:
                area_lbl.config(text=text)
        except Exception:
            pass

    def _refresh_area_capsule(self):
        state = self.rooms_state.get(self.current_room)
        if not state or not self._widget_alive(self.area_val_label):
            return
        area_id = state.get("area_id", 0)
        area_name = state.get("area_name", "")
        if not area_id and not area_name:
            text = "—"
        elif self._area_mgr.loaded and area_id:
            full = self._area_mgr.get_full_path(area_id)
            text = full if (full and full != str(area_id)) else area_name
        else:
            text = area_name or "—"
        try:
            if self.area_val_label.cget("text") != text:
                self.area_val_label.config(text=text)
        except Exception:
            pass

    def _prefetch_current_room_urls(self):
        room_id = self.current_room
        if not room_id:
            return
        qn = 10000
        platform_ = "web"
        if self._live_quality_var:
            qn = dict(QUALITY_OPTIONS).get(self._live_quality_var.get(), 10000)
        if self._live_platform_var:
            platform_ = dict(PLATFORM_OPTIONS).get(
                self._live_platform_var.get(), "web")
        try:
            live_player.url_provider.prefetch_async(room_id, qn=qn,
                                                     platform_=platform_)
        except Exception:
            pass

    def _toggle_live_dialog(self):
        if self._live_dialog and self._live_dialog.winfo_exists():
            self._live_dialog.lift()
            self._live_dialog.focus_set()
            return
        self._open_live_dialog()

    def _open_live_dialog(self):
        dlg = tk.Toplevel(self.root)
        dlg.title(f"直播画面 · 房间 {self.current_room}")
        dlg.configure(bg=BG_ROOT)
        dlg.geometry("860x560")
        dlg.minsize(560, 380)
        dlg.transient(self.root)
        dlg.protocol("WM_DELETE_WINDOW", self._on_live_dialog_close)

        bar = tk.Frame(dlg, bg=BG_PANEL)
        bar.pack(fill=tk.X, padx=8, pady=(8, 4))
        self._live_room_lbl = tk.Label(bar, text=f"房间 {self.current_room}",
                                        fg=FG_MAIN, bg=BG_PANEL,
                                        font=FONT_HEAD)
        self._live_room_lbl.pack(side=tk.LEFT, padx=(4, 12))

        tk.Label(bar, text="画质", fg=FG_SUB, bg=BG_PANEL,
                 font=FONT_SMALL).pack(side=tk.LEFT)
        self._live_quality_var = tk.StringVar(value=QUALITY_OPTIONS[0][0])
        ttk.Combobox(bar, textvariable=self._live_quality_var,
                     state="readonly",
                     values=[n for n, _ in QUALITY_OPTIONS],
                     width=8).pack(side=tk.LEFT, padx=(4, 10))

        tk.Label(bar, text="协议", fg=FG_SUB, bg=BG_PANEL,
                 font=FONT_SMALL).pack(side=tk.LEFT)
        self._live_platform_var = tk.StringVar(value=PLATFORM_OPTIONS[0][0])
        ttk.Combobox(bar, textvariable=self._live_platform_var,
                     state="readonly",
                     values=[n for n, _ in PLATFORM_OPTIONS],
                     width=18).pack(side=tk.LEFT, padx=(4, 10))

        tk.Label(bar, text="线路", fg=FG_SUB, bg=BG_PANEL,
                 font=FONT_SMALL).pack(side=tk.LEFT)
        self._live_line_var = tk.StringVar(value="线路 1")
        self._live_line_combo = ttk.Combobox(bar, textvariable=self._live_line_var,
                                              state="readonly", values=["线路 1"],
                                              width=10)
        self._live_line_combo.pack(side=tk.LEFT, padx=(4, 10))
        self._live_line_combo.bind("<<ComboboxSelected>>", self._on_line_selected)

        self._live_play_btn = tk.Button(bar, text=PLAY_BTN_TEXT,
                                         command=self._on_live_play_click,
                                         bg=PLAY_BTN_BG, fg=PLAY_BTN_FG,
                                         activebackground=PLAY_BTN_ACTIVE_BG,
                                         activeforeground=PLAY_BTN_ACTIVE_FG,
                                         font=FONT_HEAD, relief=tk.FLAT, bd=0,
                                         padx=16, pady=4, cursor="hand2")
        self._live_play_btn.pack(side=tk.LEFT, padx=(0, 6))

        tk.Button(bar, text="在浏览器打开流地址",
                  command=self._on_open_stream_in_browser,
                  bg=BG_CARD, fg=INFO, activebackground=BG_HOVER,
                  activeforeground=INFO, font=FONT_SMALL, relief=tk.FLAT,
                  bd=0, padx=12, pady=4,
                  cursor="hand2").pack(side=tk.RIGHT)

        video_wrap = tk.Frame(dlg, bg="black", highlightthickness=1,
                              highlightbackground=BORDER)
        video_wrap.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 4))
        self._live_canvas = tk.Canvas(video_wrap, bg="black",
                                       highlightthickness=0, bd=0)
        self._live_canvas.pack(fill=tk.BOTH, expand=True)

        self._live_status_lbl = tk.Label(dlg, text="就绪。点击「播放」开始。",
                                          fg=FG_SUB, bg=BG_ROOT,
                                          font=FONT_SMALL, anchor=tk.W)
        self._live_status_lbl.pack(fill=tk.X, padx=12, pady=(0, 8))

        self._live_dialog = dlg
        dlg.bind("<space>", self._on_live_space)
        dlg.focus_set()
        self._prefetch_current_room_urls()

    def _on_live_space(self, _event=None):
        if not (self._live_dialog and self._live_dialog.winfo_exists()):
            return "break"
        self._on_live_play_click()
        return "break"

    def _populate_line_options(self, urls):
        if not self._widget_alive(self._live_line_combo):
            return
        self._live_line_urls = list(urls)
        names = [f"线路 {i + 1}" for i in range(len(urls))]
        try:
            self._live_line_combo.config(values=names)
            if names:
                self._live_line_var.set(names[0])
        except Exception:
            pass

    def _on_line_selected(self, _event=None):
        if not self._live_player or not self._live_player.is_playing():
            return
        try:
            idx = self._live_line_combo.current()
            if idx < 0:
                return
            if idx == self._live_player.current_url_index:
                return
            self._live_player.switch_line(idx)
        except Exception as e:
            log_err(f"切换线路失败: {e}")

    def _on_live_dialog_close(self):
        self._stop_live_player()
        if self._live_dialog and self._live_dialog.winfo_exists():
            try:
                self._live_dialog.destroy()
            except Exception:
                pass
        self._live_dialog = None
        self._live_canvas = None
        self._live_status_lbl = None
        self._live_play_btn = None
        self._live_room_lbl = None
        self._live_line_combo = None

    def _set_live_status(self, text, color=FG_SUB):
        if self._widget_alive(self._live_status_lbl):
            try:
                self._live_status_lbl.config(text=text, fg=color)
            except Exception:
                pass

    def _stop_live_player(self):
        p = self._live_player
        self._live_player = None
        if self._render_after_id and self._live_canvas:
            try:
                self._live_canvas.after_cancel(self._render_after_id)
            except Exception:
                pass
        self._render_after_id = None
        if p is not None:
            try:
                p.stop()
            except Exception as e:
                log_err(f"停止播放器异常: {e}")
        if self._widget_alive(self._live_play_btn):
            try:
                self._live_play_btn.config(text=PLAY_BTN_TEXT,
                                            bg=PLAY_BTN_BG, fg=PLAY_BTN_FG,
                                            activebackground=PLAY_BTN_ACTIVE_BG,
                                            activeforeground=PLAY_BTN_ACTIVE_FG,
                                            state=tk.NORMAL)
            except Exception:
                pass
        self._set_live_status("已停止。", FG_SUB)

    def _try_get_cached_urls(self, room_id, qn, platform_):
        try:
            return live_player.url_provider.get_cached(room_id, qn=qn,
                                                         platform_=platform_)
        except Exception:
            return None

    def _on_live_play_click(self):
        if not (self._live_dialog and self._live_dialog.winfo_exists()):
            return
        if self._live_player is not None and self._live_player.is_playing():
            self._stop_live_player()
            return
        qn = dict(QUALITY_OPTIONS).get(self._live_quality_var.get(), 10000)
        platform_ = dict(PLATFORM_OPTIONS).get(self._live_platform_var.get(),
                                                "web")
        room_id = self.current_room
        if not room_id:
            self._set_live_status("当前没有可播放的房间。", DANGER)
            return
        cached = self._try_get_cached_urls(room_id, qn, platform_)
        if cached:
            self._set_live_status("使用缓存开始播放...", SUCCESS)
            self._on_live_play_ready(cached)
            return
        self._set_live_status(
            f"正在获取直播流（房间 {room_id}, 画质 {qn}, {platform_}）...",
            FG_SUB)
        if self._widget_alive(self._live_play_btn):
            try:
                self._live_play_btn.config(state=tk.DISABLED)
            except Exception:
                pass

        def _worker():
            try:
                info = live_player.url_provider.fetch_sync(room_id, qn=qn,
                                                            platform_=platform_)
                try:
                    self.root.after(0, lambda: self._on_live_play_ready(info))
                except Exception:
                    pass
            except Exception as e:
                err = str(e)
                try:
                    self.root.after(0,
                                    lambda: self._on_live_play_failed(err))
                except Exception:
                    pass
        threading.Thread(target=_worker, daemon=True).start()

    def _on_live_play_ready(self, info):
        if not (self._live_dialog and self._live_dialog.winfo_exists()):
            return
        if self._widget_alive(self._live_play_btn):
            try:
                self._live_play_btn.config(state=tk.NORMAL)
            except Exception:
                pass
        if not info:
            self._on_live_play_failed("未获取到 URL 信息")
            return
        urls = info.get("urls", [])
        if not urls:
            self._on_live_play_failed("接口返回空 URL 列表")
            return
        fmt = info.get("format", "flv")
        url = urls[0]
        self._live_last_url = url
        try:
            self._live_player = live_player.PyAVPlayer(self._live_canvas)
            self._live_player.on_status = (
                lambda text, color="info": self._set_live_status(
                    text, {"ok": SUCCESS, "warn": WARN,
                           "info": INFO}.get(color, FG_SUB)))
            self._live_player.on_error = (
                lambda msg: self._set_live_status(f"错误: {msg}", DANGER))
            self._live_player.on_stream_ended = (
                lambda: self._set_live_status("直播流已结束", FG_SUB))
            self._live_player.play(urls)
            self._populate_line_options(urls)
            if self._widget_alive(self._live_play_btn):
                self._live_play_btn.config(text=STOP_BTN_TEXT,
                                            bg=STOP_BTN_BG, fg=STOP_BTN_FG,
                                            activebackground=STOP_BTN_ACTIVE_BG,
                                            activeforeground=STOP_BTN_ACTIVE_FG)
            self._set_live_status(
                f"正在播放：{fmt.upper()} · 共 {len(urls)} 条线路", SUCCESS)
            self._render_loop()
        except Exception as e:
            self._on_live_play_failed(f"启动播放器失败: {e}")

    def _on_live_play_failed(self, err):
        if self._widget_alive(self._live_play_btn):
            try:
                self._live_play_btn.config(state=tk.NORMAL,
                                            text=PLAY_BTN_TEXT,
                                            bg=PLAY_BTN_BG, fg=PLAY_BTN_FG,
                                            activebackground=PLAY_BTN_ACTIVE_BG,
                                            activeforeground=PLAY_BTN_ACTIVE_FG)
            except Exception:
                pass
        self._set_live_status(f"播放失败：{err}", DANGER)
        log_err(f"直播流播放失败: {err}")

    def _render_loop(self):
        if self._live_player is None:
            return
        if not self._live_player.is_playing():
            return
        if not self._widget_alive(self._live_canvas):
            return
        try:
            self._live_player.update_canvas()
        except Exception:
            return
        try:
            self._render_after_id = self._live_canvas.after(16, self._render_loop)
        except Exception:
            self._render_after_id = None

    def _on_open_stream_in_browser(self):
        u = self._live_last_url
        if not u:
            self._set_live_status("还没有可用的流地址，请先点「播放」。", WARN)
            return
        try:
            webbrowser.open(u)
        except Exception as e:
            self._set_live_status(f"打开浏览器失败：{e}", DANGER)

    def _build_pk_panel(self):
        header = tk.Frame(self.pk_panel, bg=BG_PANEL)
        header.pack(fill=tk.X, padx=18, pady=(12, 6))
        tk.Label(header, text="PK 对决", fg=DANGER, bg=BG_PANEL,
                 font=FONT_PK_BIG).pack(side=tk.LEFT)
        tk.Button(header, text="关闭", command=self._close_pk_panel,
                  bg=BG_CARD, fg=FG_SUB, activebackground=BG_HOVER,
                  activeforeground=FG_MAIN, font=FONT_TINY, relief=tk.FLAT,
                  bd=0, padx=10, pady=2,
                  cursor="hand2").pack(side=tk.RIGHT)
        tk.Button(header, text="刷新", command=self._refresh_pk_data,
                  bg=BG_CARD, fg=ACCENT, activebackground=BG_HOVER,
                  activeforeground=ACCENT, font=FONT_TINY, relief=tk.FLAT,
                  bd=0, padx=10, pady=2,
                  cursor="hand2").pack(side=tk.RIGHT, padx=(0, 4))
        self.pk_status_lbl = tk.Label(header, text="", fg=FG_SUB, bg=BG_PANEL,
                                       font=FONT_SMALL)
        self.pk_status_lbl.pack(side=tk.RIGHT, padx=(0, 12))

        info = tk.Frame(self.pk_panel, bg=BG_PANEL)
        info.pack(fill=tk.X, padx=18, pady=(0, 6))

        my_side = tk.Frame(info, bg=BG_PANEL)
        my_side.pack(side=tk.LEFT, fill=tk.X, expand=True)
        my_avatar_wrap = tk.Frame(my_side, bg=BG_PANEL, width=64, height=64,
                                   cursor="hand2")
        my_avatar_wrap.pack(side=tk.LEFT)
        my_avatar_wrap.pack_propagate(False)
        self.pk_my_avatar = tk.Label(my_avatar_wrap, bg=BG_PANEL, text="",
                                       bd=0, relief=tk.FLAT, anchor=tk.CENTER,
                                       cursor="hand2")
        self.pk_my_avatar.pack(fill=tk.BOTH, expand=True)
        self.pk_my_avatar.bind("<Button-1>",
                                lambda e: self._show_pk_side_detail("my"))
        my_avatar_wrap.bind("<Button-1>",
                             lambda e: self._show_pk_side_detail("my"))
        my_col = tk.Frame(my_side, bg=BG_PANEL)
        my_col.pack(side=tk.LEFT, padx=(10, 0), fill=tk.X, expand=True)
        self.pk_my_name_lbl = tk.Label(my_col, text="我", fg=SUCCESS,
                                        bg=BG_PANEL, font=FONT_PK_BIG,
                                        anchor=tk.W, cursor="hand2")
        self.pk_my_name_lbl.pack(fill=tk.X, anchor=tk.W)
        self.pk_my_name_lbl.bind("<Button-1>",
                                  lambda e: self._show_pk_side_detail("my"))
        self.pk_my_uid_lbl = tk.Label(my_col, text="", fg=FG_DIM, bg=BG_PANEL,
                                       font=FONT_TINY, anchor=tk.W)
        self.pk_my_uid_lbl.pack(fill=tk.X, anchor=tk.W)
        self.pk_my_votes_lbl = tk.Label(my_col, text="0 票", fg=SUCCESS,
                                         bg=BG_PANEL, font=FONT_PK, anchor=tk.W)
        self.pk_my_votes_lbl.pack(fill=tk.X, anchor=tk.W, pady=(2, 0))

        tk.Label(info, text="  VS  ", fg=WARN, bg=BG_PANEL,
                 font=FONT_PK_BIG).pack(side=tk.LEFT, padx=12)

        oppo_side = tk.Frame(info, bg=BG_PANEL)
        oppo_side.pack(side=tk.LEFT, fill=tk.X, expand=True)
        oppo_col = tk.Frame(oppo_side, bg=BG_PANEL)
        oppo_col.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.pk_oppo_name_lbl = tk.Label(oppo_col, text="对手", fg=INFO,
                                          bg=BG_PANEL, font=FONT_PK_BIG,
                                          anchor=tk.E, justify=tk.RIGHT,
                                          cursor="hand2")
        self.pk_oppo_name_lbl.pack(fill=tk.X, anchor=tk.E)
        self.pk_oppo_name_lbl.bind("<Button-1>",
                                    lambda e: self._show_pk_side_detail("oppo"))
        self.pk_oppo_uid_lbl = tk.Label(oppo_col, text="", fg=FG_DIM,
                                         bg=BG_PANEL, font=FONT_TINY,
                                         anchor=tk.E)
        self.pk_oppo_uid_lbl.pack(fill=tk.X, anchor=tk.E)
        self.pk_oppo_votes_lbl = tk.Label(oppo_col, text="0 票", fg=INFO,
                                           bg=BG_PANEL, font=FONT_PK,
                                           anchor=tk.E)
        self.pk_oppo_votes_lbl.pack(fill=tk.X, anchor=tk.E, pady=(2, 0))
        oppo_avatar_wrap = tk.Frame(oppo_side, bg=BG_PANEL, width=64, height=64,
                                     cursor="hand2")
        oppo_avatar_wrap.pack(side=tk.RIGHT, padx=(10, 0))
        oppo_avatar_wrap.pack_propagate(False)
        self.pk_oppo_avatar = tk.Label(oppo_avatar_wrap, bg=BG_PANEL, text="",
                                        bd=0, relief=tk.FLAT, anchor=tk.CENTER,
                                        cursor="hand2")
        self.pk_oppo_avatar.pack(fill=tk.BOTH, expand=True)
        self.pk_oppo_avatar.bind("<Button-1>",
                                  lambda e: self._show_pk_side_detail("oppo"))
        oppo_avatar_wrap.bind("<Button-1>",
                               lambda e: self._show_pk_side_detail("oppo"))

        bar_wrap = tk.Frame(self.pk_panel, bg=BG_PANEL)
        bar_wrap.pack(fill=tk.X, padx=18, pady=(10, 4))
        lbl_row = tk.Frame(bar_wrap, bg=BG_PANEL)
        lbl_row.pack(fill=tk.X, pady=(0, 2))
        self.pk_my_bar_pct = tk.Label(lbl_row, text="我方 0.0%", fg=SUCCESS,
                                       bg=BG_PANEL, font=FONT_TINY, anchor=tk.W)
        self.pk_my_bar_pct.pack(side=tk.LEFT)
        self.pk_oppo_bar_pct = tk.Label(lbl_row, text="对手 0.0%", fg=INFO,
                                         bg=BG_PANEL, font=FONT_TINY, anchor=tk.E)
        self.pk_oppo_bar_pct.pack(side=tk.RIGHT)
        self.pk_bar_canvas = tk.Canvas(bar_wrap, bg=BG_PANEL, height=20,
                                        highlightthickness=0, bd=0)
        self.pk_bar_canvas.pack(fill=tk.X)
        self.pk_bar_canvas.bind("<Configure>", self._on_pk_bar_resize)

        scale_row = tk.Frame(bar_wrap, bg=BG_PANEL)
        scale_row.pack(fill=tk.X, pady=(1, 0))
        scale_row.grid_columnconfigure(0, weight=1)
        scale_row.grid_columnconfigure(1, weight=1)
        scale_row.grid_columnconfigure(2, weight=1)
        tk.Label(scale_row, text="0", fg=FG_DIM, bg=BG_PANEL,
                 font=FONT_TINY).grid(row=0, column=0, sticky="w")
        tk.Label(scale_row, text="50", fg=FG_DIM, bg=BG_PANEL,
                 font=FONT_TINY).grid(row=0, column=1)
        tk.Label(scale_row, text="100", fg=FG_DIM, bg=BG_PANEL,
                 font=FONT_TINY).grid(row=0, column=2, sticky="e")

        lead_row = tk.Frame(self.pk_panel, bg=BG_PANEL)
        lead_row.pack(fill=tk.X, padx=18, pady=(4, 12))
        self.pk_lead_lbl = tk.Label(lead_row, text="", fg=FG_SUB, bg=BG_PANEL,
                                     font=FONT_SMALL)
        self.pk_lead_lbl.pack()

    def _toggle_pk_panel(self):
        state = self.rooms_state.get(self.current_room)
        if not state:
            return
        state["pk_manual_open"] = not state.get("pk_manual_open", False)
        self._refresh_pk_panel()

    def _close_pk_panel(self):
        state = self.rooms_state.get(self.current_room)
        if not state:
            return
        pk = state.get("pk", {})
        if pk.get("active"):
            return
        state["pk_manual_open"] = False
        self._refresh_pk_panel()

    def _refresh_pk_data(self):
        state = self.rooms_state.get(self.current_room)
        if not state:
            return
        if self.refresh_pk_cb:
            try:
                self.refresh_pk_cb(self.current_room)
            except Exception as e:
                log_err(f"刷新 PK 回调异常: {e}")
        self._refresh_pk_panel()

    def _make_capsule(self, parent, key):
        f = tk.Frame(parent, bg=BG_CARD)
        f.pack(side=tk.LEFT, padx=(0, 6))
        tk.Label(f, text=key, fg=FG_DIM, bg=BG_CARD, font=FONT_TINY,
                 padx=8, pady=3).pack(side=tk.LEFT)
        val = tk.Label(f, text="-", fg=FG_MAIN, bg=BG_CARD, font=FONT_SMALL,
                       padx=8, pady=3)
        val.pack(side=tk.LEFT)
        return {"frame": f, "val": val}

    def _show_user_detail(self, uid=0, room_id=0, name="", face=""):
        if not self._root_alive():
            return
        if not uid and not room_id:
            return
        try:
            dlg = UserDetailDialog(self.root, uid=uid, room_id=room_id,
                                    initial_name=name, initial_face=face)
            self._user_detail_windows.append(dlg)
            self._user_detail_windows = [
                w for w in self._user_detail_windows
                if not getattr(w, "destroyed", True)
                or (w.win and w.win.winfo_exists())]
        except Exception as e:
            log_err(f"打开用户详情失败: {e}")

    def _show_anchor_detail(self, rid):
        state = self.rooms_state.get(rid)
        if not state:
            return
        self._show_user_detail(uid=state.get("anchor_uid", 0), room_id=rid,
                                name=state.get("anchor_name", ""),
                                face=state.get("anchor_face", ""))

    def _show_current_anchor_detail(self):
        rid = self.current_room
        if not rid:
            return
        self._show_anchor_detail(rid)

    def _show_pk_side_detail(self, side):
        state = self.rooms_state.get(self.current_room)
        if not state:
            return
        pk = state.get("pk", {})
        if side == "my":
            uid = pk.get("my_uid", 0) or 0
            room_id = pk.get("my_room_id", 0) or self.current_room
            name = pk.get("my_name", "")
            face = pk.get("my_face", "")
        else:
            uid = pk.get("oppo_uid", 0) or 0
            room_id = pk.get("oppo_room_id", 0) or 0
            name = pk.get("oppo_name", "")
            face = pk.get("oppo_face", "")
        if not uid and not room_id:
            log("PK 面板暂无对手/我方的 UID 和房间号", "UI", show=False)
            return
        self._show_user_detail(uid=uid, room_id=room_id, name=name, face=face)

    def _open_dialog_safely(self, opener, name="子窗口"):
        if not self._root_alive():
            return None
        try:
            return opener()
        except tk.TclError as e:
            log_err(f"{name} TclError: {e}")
        except Exception as e:
            log_err(f"{name} 异常: {e}")
            try:
                import traceback
                traceback.print_exc()
            except Exception:
                pass
        return None

    def _toggle_user_center(self):
        try:
            from dialogs import AccountDialog
        except Exception as e:
            log_err(f"无法加载 dialogs 模块: {e}")
            return
        callbacks = {"login": self._open_login_dialog,
                     "switch": self._switch_account,
                     "logout": self._logout_account}
        refresh_cb = self.on_account_changed_cb
        self._open_dialog_safely(
            lambda: AccountDialog(self.root, callbacks, refresh_cb),
            "AccountDialog")

    def _open_login_dialog(self):
        try:
            from dialogs import LoginDialog
        except Exception as e:
            log_err(f"无法加载 dialogs 模块: {e}")
            return
        self._open_dialog_safely(
            lambda: LoginDialog(self.root, self._on_account_changed),
            "LoginDialog")

    def _on_account_changed(self):
        cb = self.on_account_changed_cb
        if not cb:
            return
        try:
            cb()
        except Exception as e:
            log_err(f"账号变更回调异常: {e}")

    def _switch_account(self, mid):
        cb = self.switch_account_cb
        if not cb:
            log_err("未配置 switch_account_cb")
            return
        try:
            cb(mid)
        except Exception as e:
            log_err(f"切换账号失败: {e}")

    def _logout_account(self):
        cb = self.logout_account_cb
        if not cb:
            log_err("未配置 logout_account_cb")
            return
        try:
            cb()
        except Exception as e:
            log_err(f"退出登录失败: {e}")

    def _open_room_manager(self):
        if self._room_mgr_window and self._room_mgr_window.winfo_exists():
            self._room_mgr_window.lift()
            self._room_mgr_window.focus_set()
            self._refresh_room_mgr()
            return
        win = tk.Toplevel(self.root)
        win.title("房间管理")
        win.configure(bg=BG_ROOT)
        win.transient(self.root)
        win.geometry("640x520")
        try:
            self.root.update_idletasks()
            x = self.root.winfo_x() + (self.root.winfo_width() - 640) // 2
            y = self.root.winfo_y() + (self.root.winfo_height() - 520) // 2
            win.geometry(f"640x520+{max(x, 0)}+{max(y, 0)}")
        except Exception:
            pass
        header = tk.Frame(win, bg=BG_PANEL)
        header.pack(fill=tk.X, padx=12, pady=(12, 8))
        tk.Label(header, text="房间列表", fg=FG_MAIN, bg=BG_PANEL,
                 font=FONT_TITLE).pack(side=tk.LEFT)
        self._mgr_count_label = tk.Label(header,
                                          text=f"{len(self.room_ids)} 个",
                                          fg=FG_DIM, bg=BG_PANEL,
                                          font=FONT_SMALL)
        self._mgr_count_label.pack(side=tk.RIGHT)
        body = tk.Frame(win, bg=BG_PANEL, highlightthickness=1,
                        highlightbackground=BORDER)
        body.pack(fill=tk.BOTH, expand=True, padx=12)
        canvas = tk.Canvas(body, bg=BG_PANEL, highlightthickness=0, bd=0)
        sb = tk.Scrollbar(body, orient=tk.VERTICAL, command=canvas.yview,
                          bg=BG_PANEL, troughcolor=BG_PANEL,
                          activebackground=BG_HOVER, bd=0, highlightthickness=0,
                          width=8, relief=tk.FLAT)
        self._mgr_list_inner = tk.Frame(canvas, bg=BG_PANEL)
        self._mgr_list_inner.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self._mgr_list_inner,
                             anchor=tk.NW, width=600)
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        bottom = tk.Frame(win, bg=BG_ROOT)
        bottom.pack(fill=tk.X, padx=12, pady=12)
        tk.Button(bottom, text="添加直播间", command=self._on_add_room,
                  bg=ACCENT, fg="#0d1117", activebackground="#26b8a4",
                  activeforeground="#0d1117", font=FONT_HEAD, relief=tk.FLAT,
                  bd=0, padx=20, pady=6,
                  cursor="hand2").pack(side=tk.LEFT)
        tk.Button(bottom, text="关闭", command=self._close_room_manager,
                  bg=BG_CARD, fg=FG_SUB, activebackground=BG_HOVER,
                  activeforeground=FG_MAIN, font=FONT_BODY, relief=tk.FLAT,
                  bd=0, padx=20, pady=6,
                  cursor="hand2").pack(side=tk.RIGHT)

        def _on_close():
            try:
                win.destroy()
            except Exception:
                pass
            self._room_mgr_window = None
        win.protocol("WM_DELETE_WINDOW", _on_close)
        self._room_mgr_window = win
        self._refresh_room_mgr()

    def _close_room_manager(self):
        if self._room_mgr_window and self._room_mgr_window.winfo_exists():
            try:
                self._room_mgr_window.destroy()
            except Exception:
                pass
        self._room_mgr_window = None

    def _refresh_room_mgr(self):
        if not (self._room_mgr_window and
                self._room_mgr_window.winfo_exists()):
            return
        if hasattr(self, "_mgr_count_label") and \
                self._widget_alive(self._mgr_count_label):
            try:
                self._mgr_count_label.config(text=f"{len(self.room_ids)} 个")
            except Exception:
                pass
        for w in self._mgr_list_inner.winfo_children():
            w.destroy()
        if not self.room_ids:
            tk.Label(self._mgr_list_inner, text="暂无房间", fg=FG_DIM,
                     bg=BG_PANEL, font=FONT_BODY).pack(pady=40)
            return
        for rid in self.room_ids:
            self._build_mgr_row(rid)

    def _build_mgr_row(self, rid):
        state = self.rooms_state.get(rid)
        if not state:
            return
        is_cur = (rid == self.current_room)
        bg = BG_CARD if is_cur else BG_PANEL
        bar_bg = ACCENT if is_cur else BG_PANEL
        row = tk.Frame(self._mgr_list_inner, bg=bg)
        row.pack(fill=tk.X, padx=4, pady=2)
        bar = tk.Frame(row, bg=bar_bg, width=3)
        bar.pack(side=tk.LEFT, fill=tk.Y)
        bar.pack_propagate(False)
        inner = tk.Frame(row, bg=bg)
        inner.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=14, pady=10)
        info = tk.Frame(inner, bg=bg)
        info.pack(side=tk.LEFT, fill=tk.X, expand=True)
        anchor_name = state["anchor_name"] or f"房间 {rid}"
        tk.Label(info, text=anchor_name, fg=FG_MAIN, bg=bg, font=FONT_HEAD,
                 anchor=tk.W).pack(fill=tk.X)
        area_text = ""
        area_id = state.get("area_id", 0)
        if self._area_mgr.loaded and area_id:
            full = self._area_mgr.get_full_path(area_id)
            if full and full != str(area_id):
                area_text = f" · {full}"
        if not area_text and state.get("area_name"):
            area_text = f" · {state['area_name']}"
        tk.Label(info, text=f"房间号 {rid}{area_text}", fg=FG_DIM, bg=bg,
                 font=FONT_SMALL, anchor=tk.W).pack(fill=tk.X, pady=(2, 0))
        sub = tk.Frame(inner, bg=bg)
        sub.pack(side=tk.RIGHT)
        conn = state["status"].get("连接", "-")
        live = state["status"].get("直播", "-")
        online = state["status"].get("在线", 0)
        danmu = state["status"].get("弹幕", 0)
        info_text = f"连接 {conn} · 直播 {live} · 在线 {online} · 弹幕 {danmu}"
        tk.Label(sub, text=info_text, fg=FG_SUB, bg=bg,
                 font=FONT_TINY).pack(side=tk.LEFT, padx=(0, 12))
        tk.Button(sub, text="切换", command=lambda r=rid: self._mgr_switch(r),
                  bg=BG_HOVER, fg=FG_MAIN, activebackground=BG_CARD,
                  activeforeground=ACCENT, font=FONT_SMALL, relief=tk.FLAT,
                  bd=0, padx=12, pady=4,
                  cursor="hand2").pack(side=tk.LEFT, padx=2)
        tk.Button(sub, text="删除", command=lambda r=rid: self._mgr_remove(r),
                  bg=BG_HOVER, fg=DANGER, activebackground=BG_CARD,
                  activeforeground=DANGER, font=FONT_SMALL, relief=tk.FLAT,
                  bd=0, padx=12, pady=4,
                  cursor="hand2").pack(side=tk.LEFT, padx=2)

    def _mgr_switch(self, rid):
        self._switch_room(rid)
        self._refresh_room_mgr()

    def _mgr_remove(self, rid):
        if len(self.room_ids) <= 1:
            try:
                from tkinter import messagebox
                messagebox.showwarning("提示", "至少需要保留一个直播间",
                                        parent=self._room_mgr_window)
            except Exception:
                pass
            return
        name = self.rooms_state.get(rid, {}).get("anchor_name") or f"房间 {rid}"
        try:
            from tkinter import messagebox
            ok = messagebox.askyesno("确认删除", f"确定不再监听 {name}？",
                                      parent=self._room_mgr_window)
        except Exception:
            ok = True
        if not ok:
            return
        if self.remove_room_cb:
            try:
                res = self.remove_room_cb(rid)
                if isinstance(res, tuple) and len(res) >= 2:
                    good, err = res[0], res[1]
                    if not good:
                        try:
                            from tkinter import messagebox
                            messagebox.showerror("删除失败", err or "未知错误",
                                                  parent=self._room_mgr_window)
                        except Exception:
                            pass
            except Exception as e:
                log_err(f"删除房间异常: {e}")

    def _on_add_room(self):
        if not self.add_room_cb:
            return
        parent = self._room_mgr_window if (
            self._room_mgr_window and self._room_mgr_window.winfo_exists()
        ) else self.root
        dlg = tk.Toplevel(parent)
        dlg.title("添加直播间")
        dlg.configure(bg=BG_PANEL)
        dlg.transient(parent)
        try:
            dlg.grab_set()
        except Exception:
            pass
        dlg.resizable(False, False)
        w, h = 400, 220
        try:
            parent.update_idletasks()
            x = parent.winfo_x() + (parent.winfo_width() - w) // 2
            y = parent.winfo_y() + (parent.winfo_height() - h) // 2
            dlg.geometry(f"{w}x{h}+{max(x, 0)}+{max(y, 0)}")
        except Exception:
            dlg.geometry(f"{w}x{h}")
        tk.Label(dlg, text="添加直播间", fg=FG_MAIN, bg=BG_PANEL,
                 font=FONT_TITLE).pack(pady=(22, 6))
        tk.Label(dlg, text="输入 B 站直播间号（纯数字）", fg=FG_SUB,
                 bg=BG_PANEL, font=FONT_SMALL).pack()
        entry_wrap = tk.Frame(dlg, bg=BG_INPUT, highlightthickness=1,
                              highlightbackground=BORDER)
        entry_wrap.pack(padx=30, pady=14, fill=tk.X)
        entry = tk.Entry(entry_wrap, bg=BG_INPUT, fg=FG_MAIN,
                         insertbackground=FG_MAIN, font=FONT_BODY,
                         relief=tk.FLAT, bd=0)
        entry.pack(fill=tk.X, padx=12, pady=8)
        entry.focus_set()
        err_label = tk.Label(dlg, text="", fg=DANGER, bg=BG_PANEL,
                             font=FONT_SMALL)
        err_label.pack()
        btn_row = tk.Frame(dlg, bg=BG_PANEL)
        btn_row.pack(pady=(8, 0))

        def _close_add_dlg():
            try:
                dlg.grab_release()
            except Exception:
                pass
            try:
                dlg.destroy()
            except Exception:
                pass

        def _submit():
            txt = entry.get().strip()
            if not txt:
                err_label.config(text="请输入房间号")
                return
            if not txt.isdigit():
                err_label.config(text="房间号必须为纯数字")
                return
            rid = int(txt)
            if rid <= 0:
                err_label.config(text="房间号必须为正整数")
                return
            try:
                res = self.add_room_cb(rid)
            except Exception as e:
                err_label.config(text=f"异常: {e}")
                return
            if isinstance(res, tuple) and len(res) >= 2:
                good, err = res[0], res[1]
            else:
                good, err = True, ""
            if not good:
                err_label.config(text=err or "添加失败")
                return
            _close_add_dlg()

        tk.Button(btn_row, text="取消", command=_close_add_dlg, bg=BG_CARD,
                  fg=FG_SUB, activebackground=BG_HOVER,
                  activeforeground=FG_MAIN, font=FONT_BODY, relief=tk.FLAT,
                  padx=22, pady=6, cursor="hand2",
                  bd=0).pack(side=tk.LEFT, padx=6)
        tk.Button(btn_row, text="添加", command=_submit, bg=ACCENT,
                  fg="#0d1117", activebackground="#26b8a4",
                  activeforeground="#0d1117", font=FONT_HEAD, relief=tk.FLAT,
                  padx=22, pady=6, cursor="hand2",
                  bd=0).pack(side=tk.LEFT, padx=6)
        entry.bind("<Return>", lambda e: _submit())
        entry.bind("<Escape>", lambda e: _close_add_dlg())
        dlg.protocol("WM_DELETE_WINDOW", _close_add_dlg)

    def _on_account_click(self):
        try:
            self.account_cb()
        except Exception as e:
            log_err(f"账号菜单异常: {e}")

    def _on_login_click(self):
        self._on_account_click()

    def _start_avatar_worker(self):
        threading.Thread(target=self._avatar_worker, daemon=True).start()

    def _avatar_worker(self):
        while True:
            try:
                url = self.avatar_requests.get(timeout=1.0)
            except queue.Empty:
                continue
            if not url or url in self.avatar_cache:
                self.avatar_pending.discard(url)
                continue
            try:
                img = avatar_cache.load_image(url)
                if img is None:
                    self.avatar_pending.discard(url)
                    continue
                self.avatar_done.put((url, img))
            except Exception as e:
                log(f"头像加载失败 {url[:60]}: {e}", "WARN", show=False)
                self.avatar_pending.discard(url)

    def _request_avatar(self, url):
        if not url:
            return
        if url.startswith("http://"):
            url = "https://" + url[7:]
        if url in self.avatar_cache or url in self.avatar_pending:
            return
        self.avatar_pending.add(url)
        self.avatar_requests.put(url)

    def _poll(self):
        if not self._root_alive():
            return
        try:
            while True:
                kind, *p = self.q.get_nowait()
                try:
                    self._handle(kind, *p)
                except Exception as e:
                    log_err(f"事件处理异常: {e}")
        except queue.Empty:
            pass
        try:
            while True:
                url, img = self.avatar_done.get_nowait()
                try:
                    photos = {
                        "tiny": ImageTk.PhotoImage(img.resize((20, 20),
                                                               Image.LANCZOS),
                                                    master=self.root),
                        "card": ImageTk.PhotoImage(img.resize((32, 32),
                                                               Image.LANCZOS),
                                                    master=self.root),
                        "rank": ImageTk.PhotoImage(img.resize((32, 32),
                                                               Image.LANCZOS),
                                                    master=self.root),
                        "big": ImageTk.PhotoImage(img.resize((56, 56),
                                                              Image.LANCZOS),
                                                   master=self.root),
                        "pk": ImageTk.PhotoImage(img.resize((64, 64),
                                                             Image.LANCZOS),
                                                  master=self.root),
                    }
                    self.avatar_cache[url] = photos
                    self.avatar_pending.discard(url)
                    if self._account_face_url == url:
                        try:
                            self.account_btn.config(
                                image=photos["tiny"],
                                text=" " + (account.account_info.get("uname")
                                            or "账号"))
                            self._account_avatar_photo = photos["tiny"]
                        except Exception:
                            pass
                    for rid, st in self.rooms_state.items():
                        if st.get("anchor_face") == url:
                            refs = self.room_cards.get(rid)
                            if refs and self._widget_alive(refs.get("avatar")):
                                refs["avatar"].config(image=photos["card"],
                                                       text="")
                                refs["avatar"].image = photos["card"]
                    cur_st = self.rooms_state.get(self.current_room)
                    if cur_st:
                        if cur_st.get("anchor_face") == url:
                            if self._widget_alive(self.header_avatar_label):
                                self.header_avatar_label.config(
                                    image=photos["big"], text="")
                                self._header_avatar_photo = photos["big"]
                        pk = cur_st.get("pk", {})
                        if pk.get("active") or cur_st.get("pk_manual_open"):
                            if pk.get("my_face") == url or \
                                    pk.get("oppo_face") == url:
                                self._refresh_pk_panel()
                    self._refresh_rank_display()
                except Exception:
                    self.avatar_pending.discard(url)
        except queue.Empty:
            pass
        try:
            if self._root_alive():
                self.root.after(80, self._poll)
        except Exception:
            pass

    def _handle(self, kind, *args):
        if kind == "event":
            rid = args[0]
            msg = args[1]
            style = args[2]
            color_info = args[3] if len(args) > 3 else None
            state = self.rooms_state.get(rid)
            if not state:
                return
            ts = time.strftime("%H:%M:%S")
            if _is_interact_msg(msg):
                state["interact_buffer"].append((ts, msg, style, color_info))
                if len(state["interact_buffer"]) > self.max_interact_lines:
                    state["interact_buffer"] = \
                        state["interact_buffer"][-self.max_interact_lines:]
                if rid == self.current_room and \
                        self._interact_window and \
                        self._interact_window.winfo_exists():
                    self._append_interact(ts, msg, style, color_info)
            else:
                state["event_buffer"].append((ts, msg, style, color_info))
                if len(state["event_buffer"]) > self.max_event_lines:
                    state["event_buffer"] = \
                        state["event_buffer"][-self.max_event_lines:]
                if rid == self.current_room:
                    self._append_event_visible(ts, msg, style, color_info)

        elif kind == "status":
            rid, key, value = args
            state = self.rooms_state.get(rid)
            if not state:
                return
            if key == "rp_win_me":
                self._on_rp_win_me(rid, value)
                return
            if key == "rp_winners":
                self._on_rp_winners(rid, value)
                return
            if key == "area_id":
                state["area_id"] = value
                cached = _AREA_MEM_CACHE.setdefault(rid, {})
                cached["area_id"] = value
                self._update_room_card_area(rid)
                if rid == self.current_room:
                    self._refresh_area_capsule()
                return
            if key == "area_name":
                state["area_name"] = value
                cached = _AREA_MEM_CACHE.setdefault(rid, {})
                cached["area_name"] = value
                self._update_room_card_area(rid)
                if rid == self.current_room:
                    self._refresh_area_capsule()
                return
            if key == "watched":
                state["status"]["watched"] = value
                if rid == self.current_room:
                    self._update_watched_label()
                return
            state["status"][key] = value
            self._update_room_card_status(rid)
            if rid == self.current_room:
                self._update_capsule(key, value)
            self._refresh_room_mgr_if_open()

        elif kind == "title":
            rid, title = args
            state = self.rooms_state.get(rid)
            if not state:
                return
            state["title"] = title
            if rid == self.current_room and \
                    self._widget_alive(self.title_label):
                try:
                    self.title_label.config(text=title)
                except Exception:
                    pass

        elif kind == "rank":
            rid, rank_list = args
            state = self.rooms_state.get(rid)
            if not state:
                return
            state["rank_list"] = list(rank_list)
            for item in rank_list:
                if item.get("face"):
                    self._request_avatar(item["face"])
            if rid == self.current_room:
                self._refresh_rank_display()

        elif kind == "anchor":
            rid = args[0]
            uname = args[1]
            face = args[2]
            uid = args[3] if len(args) > 3 else 0
            state = self.rooms_state.get(rid)
            if not state:
                return
            state["anchor_name"] = uname
            state["anchor_face"] = face or ""
            if uid:
                state["anchor_uid"] = int(uid or 0)
            self._update_room_card_status(rid)
            self._refresh_room_mgr_if_open()
            if rid == self.current_room:
                self._refresh_header_info()

        elif kind == "area":
            rid, area_id, area_name = args
            state = self.rooms_state.get(rid)
            if not state:
                return
            state["area_id"] = area_id or 0
            state["area_name"] = area_name or ""
            _AREA_MEM_CACHE[rid] = {"area_id": state["area_id"],
                                     "area_name": state["area_name"]}
            self._update_room_card_area(rid)
            if rid == self.current_room:
                self._refresh_area_capsule()
            self._refresh_room_mgr_if_open()

        elif kind == "account":
            self._update_account_button(args[0])

        elif kind == "pk":
            rid, pk_data = args
            state = self.rooms_state.get(rid)
            if not state:
                return
            new_pk = dict(pk_data) if pk_data else {}
            if new_pk.get("active") is True:
                state["pk"] = new_pk
                state["pk_last_update"] = time.time()
            else:
                clean = _empty_pk_state()
                clean["active"] = False
                state["pk"] = clean
                state["pk_last_update"] = time.time()
            self._update_room_card_pk(rid)
            if rid == self.current_room:
                self._refresh_pk_panel()

        elif kind == "register_room":
            self._register_room_impl(args[0])

        elif kind == "unregister_room":
            self._unregister_room_impl(args[0])

        elif kind == "emote_image":
            label = args[0]
            img = args[1]
            url = args[2] if len(args) > 2 else ""
            if not self._widget_alive(label):
                return
            try:
                photo = ImageTk.PhotoImage(img, master=self.root)
                label.config(image=photo, text="")
                label.image = photo
                if url:
                    self._emote_image_refs[url] = photo
            except Exception:
                pass

        elif kind == "emote_cover":
            tab_key = args[0]
            img = args[1]
            url = args[2] if len(args) > 2 else ""
            nb = self._emote_panel_nb
            if nb is None or not self._widget_alive(nb):
                return
            try:
                photo = ImageTk.PhotoImage(img, master=self.root)
                self._emote_cover_refs[url] = photo
                for tab_id in nb.tabs():
                    try:
                        w = nb.nametowidget(tab_id)
                    except Exception:
                        continue
                    if id(w) == tab_key:
                        try:
                            nb.tab(tab_id, image=photo, compound="left")
                        except Exception:
                            pass
                        break
            except Exception:
                pass

    def _refresh_room_mgr_if_open(self):
        if self._room_mgr_window and self._room_mgr_window.winfo_exists():
            self._refresh_room_mgr()

    def _pk_timeout_check(self):
        if not self._root_alive():
            return
        try:
            now = time.time()
            for rid, st in list(self.rooms_state.items()):
                pk = st.get("pk", {})
                if not pk.get("active"):
                    continue
                last = st.get("pk_last_update", 0.0)
                if last > 0 and now - last > PK_STALE_TIMEOUT:
                    clean = _empty_pk_state()
                    clean["active"] = False
                    st["pk"] = clean
                    st["pk_last_update"] = now
                    self._update_room_card_pk(rid)
                    if rid == self.current_room:
                        self._refresh_pk_panel()
        except Exception as e:
            log_err(f"PK 超时检查异常: {e}")
        try:
            if self._root_alive():
                self.root.after(5000, self._pk_timeout_check)
        except Exception:
            pass

    def _update_account_button(self, info):
        if not self._widget_alive(self.account_btn):
            return
        if info.get("is_login"):
            name = info.get("uname", "未知")
            face = info.get("face", "")
            if face.startswith("http://"):
                face = "https://" + face[7:]
            if face:
                self._account_face_url = face
                cached = self.avatar_cache.get(face)
                if cached and cached.get("tiny"):
                    try:
                        self.account_btn.config(image=cached["tiny"],
                                                 text=" " + name)
                        self._account_avatar_photo = cached["tiny"]
                    except Exception:
                        pass
                else:
                    self.account_btn.config(image="", text=" " + name)
                    self._request_avatar(face)
            else:
                self.account_btn.config(image="", text=" " + name)
            self.account_btn.config(fg=ACCENT)
        else:
            self.account_btn.config(image="", text="未登录", fg=FG_SUB)

    def register_room(self, room_id):
        self.q.put(("register_room", room_id))

    def unregister_room(self, room_id):
        self.q.put(("unregister_room", room_id))

    def _register_room_impl(self, room_id):
        if room_id in self.rooms_state:
            return
        self.rooms_state[room_id] = self._new_room_state(room_id)
        self.room_ids.append(room_id)
        self._build_room_card(self.list_inner, room_id)
        try:
            if self.list_inner is not None:
                parent_canvas = self.list_inner.master
                if parent_canvas is not None:
                    self._bind_mousewheel_recursive(parent_canvas,
                                                      self.list_inner)
        except Exception:
            pass
        if self._widget_alive(self.room_count_label):
            try:
                self.room_count_label.config(text=f"{len(self.room_ids)}")
            except Exception:
                pass
        self._refresh_title()
        self._update_room_card_status(room_id)
        self._switch_room(room_id)
        self._refresh_room_mgr_if_open()
        log(f"UI 已注册房间 {room_id}", "UI")
        self._fetch_area_info(room_id)
        try:
            live_player.url_provider.prefetch_async(room_id, qn=10000,
                                                     platform_="web")
        except Exception:
            pass

    def _unregister_room_impl(self, room_id):
        if room_id not in self.rooms_state:
            return
        del self.rooms_state[room_id]
        if room_id in self.room_ids:
            self.room_ids.remove(room_id)
        refs = self.room_cards.pop(room_id, None)
        if refs:
            try:
                refs["card"].destroy()
            except Exception:
                pass
        _AREA_MEM_CACHE.pop(room_id, None)
        self._area_fetch_requested.discard(room_id)
        if self._widget_alive(self.room_count_label):
            try:
                self.room_count_label.config(text=f"{len(self.room_ids)}")
            except Exception:
                pass
        self._refresh_title()
        if self.current_room == room_id:
            if self.room_ids:
                self.current_room = self.room_ids[0]
                self._update_card_highlight(self.current_room, True)
                self._refresh_main_panel()
            else:
                self.current_room = 0
                self._refresh_main_panel()
        self._refresh_room_mgr_if_open()
        log(f"UI 已注销房间 {room_id}", "UI")

    def _on_send(self):
        try:
            msg = self.entry.get().strip()
        except Exception:
            return
        if not msg:
            return
        try:
            self.entry.delete(0, tk.END)
        except Exception:
            pass
        try:
            self.send_cb(self.current_room, msg)
        except Exception as e:
            log_err(f"发送异常: {e}")

    def _ensure_medal_tag(self, bg_hex, fg_hex):
        key = f"{bg_hex}|{fg_hex}"
        tag = self._medal_tags.get(key)
        if tag:
            return tag
        safe = key.replace("#", "").replace("|", "_")
        tag = f"medal_{safe}"
        try:
            self.event_text.tag_config(tag, foreground=fg_hex,
                                        background=bg_hex)
        except Exception:
            pass
        self._medal_tags[key] = tag
        return tag

    def _trim_event_text(self):
        try:
            n = int(self.event_text.index('end-1c').split('.')[0])
            if n > self.max_event_lines:
                self.event_text.delete("1.0",
                                        f"{n - self.max_event_lines + 1}.0")
        except Exception:
            pass

    def _insert_msg_with_color(self, msg, style, color_info):
        if style == "medal" and color_info:
            name = color_info.get("uname", "")
            bg = _norm_color(color_info.get("color_main", ""), BG_CARD)
            fg = _norm_color(color_info.get("color_text", ""),
                              _pick_text_color(bg))
            if name and name in msg:
                pre, _, post = msg.partition(name)
                if pre:
                    self.event_text.insert(tk.END, pre, "white")
                tag = self._ensure_medal_tag(bg, fg)
                self.event_text.insert(tk.END, " ", tag)
                self.event_text.insert(tk.END, name, tag)
                self.event_text.insert(tk.END, " ", tag)
                if post:
                    self.event_text.insert(tk.END, post, "white")
                self.event_text.insert(tk.END, "\n")
                return
        self.event_text.insert(tk.END, msg + "\n", style or "white")

    def _append_event_visible(self, ts, msg, style, color_info=None):
        if not self._widget_alive(self.event_text):
            return
        try:
            self.event_text.configure(state=tk.NORMAL)
            self.event_text.insert(tk.END, f"[{ts}] ", "ts")
            self._insert_msg_with_color(msg, style, color_info)
            self._trim_event_text()
            self.event_text.see(tk.END)
            self.event_text.configure(state=tk.DISABLED)
        except Exception:
            pass

    def _rebuild_event_text(self, buffer):
        if not self._widget_alive(self.event_text):
            return
        try:
            self.event_text.configure(state=tk.NORMAL)
            self.event_text.delete("1.0", tk.END)
            for item in buffer:
                ts = item[0]
                msg = item[1]
                style = item[2]
                color_info = item[3] if len(item) > 3 else None
                self.event_text.insert(tk.END, f"[{ts}] ", "ts")
                self._insert_msg_with_color(msg, style, color_info)
            self.event_text.see(tk.END)
            self.event_text.configure(state=tk.DISABLED)
        except Exception:
            pass

    @staticmethod
    def _status_color(key, value):
        if key == "连接":
            return SUCCESS if value == "在线" else DANGER
        if key == "直播":
            if value == "直播中":
                return SUCCESS
            if value == "轮播":
                return WARN
            return FG_DIM
        if key == "人气":
            return WARN
        if key == "在线":
            return ACCENT
        if key == "排名":
            return INFO
        return FG_MAIN

    def _update_capsule(self, key, value):
        cap = self.capsule_labels.get(key)
        if not cap or not self._widget_alive(cap.get("val")):
            return
        color = self._status_color(key, value)
        try:
            cap["val"].config(text=str(value), fg=color)
        except Exception:
            pass

    def _update_watched_label(self):
        state = self.rooms_state.get(self.current_room)
        if not state or not self._widget_alive(self.watched_val_label):
            return
        try:
            v = int(state["status"].get("watched", 0) or 0)
        except Exception:
            v = 0
        try:
            if v >= 10000:
                s = f"{v / 10000:.1f}万"
            else:
                s = str(v)
            self.watched_val_label.config(text=s)
        except Exception:
            pass

    def _update_room_card_pk(self, rid):
        state = self.rooms_state.get(rid)
        refs = self.room_cards.get(rid)
        if not state or not refs:
            return
        pk = state.get("pk", {})
        pk_row = refs.get("pk_row")
        pk_label = refs.get("pk_label")
        if not pk_row or not pk_label:
            return
        try:
            if pk.get("active"):
                my_name = pk.get("my_name") or "我"
                oppo_name = pk.get("oppo_name") or "对手"
                my_votes = pk.get("my_votes", 0)
                oppo_votes = pk.get("oppo_votes", 0)
                txt = f"PK: {my_name} {my_votes} vs {oppo_name} {oppo_votes}"
                pk_label.config(text=txt, fg=DANGER)
                if not pk_row.winfo_ismapped():
                    pk_row.pack(fill=tk.X, pady=(4, 0))
            else:
                if pk_row.winfo_ismapped():
                    pk_row.pack_forget()
        except Exception:
            pass

    def _update_room_card_status(self, rid):
        state = self.rooms_state.get(rid)
        refs = self.room_cards.get(rid)
        if not state or not refs:
            return
        try:
            name = state.get("anchor_name") or f"房间 {rid}"
            if self._widget_alive(refs["name"]):
                refs["name"].config(text=name)
            face = state.get("anchor_face", "")
            if face and self._widget_alive(refs["avatar"]):
                if face.startswith("http://"):
                    face_url = "https://" + face[7:]
                else:
                    face_url = face
                cached = self.avatar_cache.get(face_url)
                if cached and cached.get("card"):
                    refs["avatar"].config(image=cached["card"], text="")
                    refs["avatar"].image = cached["card"]
                else:
                    self._request_avatar(face_url)
            conn = state["status"].get("连接")
            live = state["status"].get("直播")
            if conn != "在线":
                dot_color = DANGER
            elif live == "直播中":
                dot_color = SUCCESS
            elif live == "轮播":
                dot_color = WARN
            else:
                dot_color = FG_DIM
            if self._widget_alive(refs["dot"]):
                refs["dot"].delete("dot")
                refs["dot"].create_oval(2, 2, 8, 8, fill=dot_color,
                                         outline="", tags="dot")
            d = state["status"].get("弹幕", 0)
            if self._widget_alive(refs["stat"]):
                refs["stat"].config(text=f"弹幕 {d}")
        except Exception:
            pass
        self._update_room_card_area(rid)
        self._update_room_card_pk(rid)

    def _refresh_all_room_cards(self):
        for rid in self.room_ids:
            self._update_room_card_status(rid)

    def _load_pk_avatar(self, label, url):
        if not self._widget_alive(label):
            return
        if not url:
            label.config(image="", text="")
            label.image = None
            return
        if url.startswith("http://"):
            url = "https://" + url[7:]
        cached = self.avatar_cache.get(url)
        if cached and cached.get("pk"):
            label.config(image=cached["pk"], text="")
            label.image = cached["pk"]
            self._pk_avatar_refs[id(label)] = cached["pk"]
        else:
            label.config(image="", text="")
            label.image = None
            self._request_avatar(url)

    def _refresh_pk_panel(self):
        state = self.rooms_state.get(self.current_room)
        if not state:
            self.pk_panel.grid_remove()
            return
        pk = state.get("pk", {})
        manual_open = state.get("pk_manual_open", False)
        if not (pk.get("active") or manual_open):
            self.pk_panel.grid_remove()
            return
        self.pk_panel.grid()
        self.pk_panel.update_idletasks()
        if not pk.get("active"):
            self.pk_status_lbl.config(text="当前无 PK")
            self.pk_my_name_lbl.config(text="—", fg=SUCCESS, bg=BG_PANEL,
                                        padx=0, pady=0)
            self.pk_oppo_name_lbl.config(text="—", fg=INFO, bg=BG_PANEL,
                                          padx=0, pady=0)
            self.pk_my_uid_lbl.config(text="")
            self.pk_oppo_uid_lbl.config(text="")
            self.pk_my_votes_lbl.config(text="0 票")
            self.pk_oppo_votes_lbl.config(text="0 票")
            self.pk_lead_lbl.config(text="等待 PK 事件推送...", fg=FG_DIM)
            self.pk_my_bar_pct.config(text="我方 —")
            self.pk_oppo_bar_pct.config(text="对手 —")
            self._draw_pk_placeholder()
            self._load_pk_avatar(self.pk_my_avatar, "")
            self._load_pk_avatar(self.pk_oppo_avatar, "")
            return
        my_name = pk.get("my_name") or "我"
        oppo_name = pk.get("oppo_name") or "对手"
        my_votes = pk.get("my_votes", 0) or 0
        oppo_votes = pk.get("oppo_votes", 0) or 0

        def _short(s, n=12):
            s = str(s or "")
            return s if len(s) <= n else s[:n] + "..."
        my_color = _norm_color(pk.get("my_color", ""), "")
        if my_color:
            self.pk_my_name_lbl.config(text=_short(my_name, 12),
                                        fg=_pick_text_color(my_color),
                                        bg=my_color, padx=6, pady=1)
        else:
            self.pk_my_name_lbl.config(text=_short(my_name, 12), fg=SUCCESS,
                                        bg=BG_PANEL, padx=0, pady=0)
        oppo_color = _norm_color(pk.get("oppo_color", ""), "")
        if oppo_color:
            self.pk_oppo_name_lbl.config(text=_short(oppo_name, 12),
                                          fg=_pick_text_color(oppo_color),
                                          bg=oppo_color, padx=6, pady=1)
        else:
            self.pk_oppo_name_lbl.config(text=_short(oppo_name, 12), fg=INFO,
                                          bg=BG_PANEL, padx=0, pady=0)
        my_uid = pk.get("my_uid", 0) or 0
        oppo_uid = pk.get("oppo_uid", 0) or 0
        my_room = pk.get("my_room_id", 0) or 0
        oppo_room = pk.get("oppo_room_id", 0) or 0

        def _uid_text(uid, room):
            parts = []
            if uid:
                parts.append(f"UID {uid}")
            if room:
                parts.append(f"房间 {room}")
            return " · ".join(parts) if parts else "—"
        self.pk_my_uid_lbl.config(text=_uid_text(my_uid, my_room))
        self.pk_oppo_uid_lbl.config(text=_uid_text(oppo_uid, oppo_room))
        self.pk_my_votes_lbl.config(text=f"{my_votes} 票")
        self.pk_oppo_votes_lbl.config(text=f"{oppo_votes} 票")
        self._load_pk_avatar(self.pk_my_avatar, pk.get("my_face", ""))
        self._load_pk_avatar(self.pk_oppo_avatar, pk.get("oppo_face", ""))
        total = my_votes + oppo_votes
        self.pk_status_lbl.config(text=f"总计 {total} 票")
        self._redraw_pk_bar(my_votes, oppo_votes)
        if my_votes > oppo_votes:
            diff = my_votes - oppo_votes
            self.pk_lead_lbl.config(text=f"{my_name} 领先 {diff} 票", fg=SUCCESS)
        elif oppo_votes > my_votes:
            diff = oppo_votes - my_votes
            self.pk_lead_lbl.config(text=f"{oppo_name} 领先 {diff} 票", fg=INFO)
        else:
            self.pk_lead_lbl.config(text="票数持平", fg=WARN)

    def _on_pk_bar_resize(self, event=None):
        if event is not None:
            if self._pk_bar_last_w == event.width:
                return
            self._pk_bar_last_w = event.width
        state = self.rooms_state.get(self.current_room)
        if not state:
            return
        pk = state.get("pk", {})
        manual_open = state.get("pk_manual_open", False)
        if not (pk.get("active") or manual_open):
            return
        if not self.pk_panel.winfo_ismapped():
            return
        if not pk.get("active"):
            self._draw_pk_placeholder()
        else:
            self._draw_pk_bar_only(pk.get("my_votes", 0) or 0,
                                    pk.get("oppo_votes", 0) or 0)

    def _draw_pk_placeholder(self):
        c = self.pk_bar_canvas
        c.delete("all")
        w = c.winfo_width()
        if w <= 1:
            w = 400
        h = 20
        c.create_rectangle(0, 0, w, h, fill=BG_CARD, outline="")
        c.create_line(w * 0.5, 0, w * 0.5, h, fill=FG_DIM, width=2)
        c.create_rectangle(0, 0, w, h, outline=BORDER, width=1)
        self._pk_bar_last_payload = ("placeholder",)

    def _draw_pk_bar_only(self, my_votes, oppo_votes):
        c = self.pk_bar_canvas
        c.delete("all")
        w = c.winfo_width()
        if w <= 1:
            w = 400
        h = 20
        total = my_votes + oppo_votes
        if total > 0:
            my_ratio = my_votes / total
            oppo_ratio = oppo_votes / total
        else:
            my_ratio = 0.5
            oppo_ratio = 0.5
        mid = w * my_ratio
        if mid > 0:
            c.create_rectangle(0, 0, mid, h, fill=SUCCESS, outline="")
        if w - mid > 0:
            c.create_rectangle(mid, 0, w, h, fill=INFO, outline="")
        for p in (0.25, 0.75):
            x = w * p
            c.create_line(x, 0, x, h, fill=BG_PANEL, width=1)
        c.create_line(w * 0.5, 0, w * 0.5, h, fill=FG_DIM, width=2)
        c.create_line(mid, 0, mid, h, fill=FG_MAIN, width=2)
        c.create_rectangle(0, 0, w, h, outline=BORDER, width=1)
        self._pk_bar_last_w = w
        self._pk_bar_last_payload = ("votes", my_votes, oppo_votes)
        return my_ratio, oppo_ratio

    def _redraw_pk_bar(self, my_votes, oppo_votes):
        my_ratio, oppo_ratio = self._draw_pk_bar_only(my_votes, oppo_votes)
        self.pk_my_bar_pct.config(text=f"我方 {my_ratio * 100:.1f}%")
        self.pk_oppo_bar_pct.config(text=f"对手 {oppo_ratio * 100:.1f}%")

    def _refresh_header_info(self):
        state = self.rooms_state.get(self.current_room)
        if not state or not self._widget_alive(self.anchor_subtitle):
            return
        anchor_name = state.get("anchor_name", "")
        try:
            if anchor_name:
                self.anchor_subtitle.config(
                    text=f"主播 {anchor_name} · 房间 {self.current_room}"
                         f"（点击查看详情）")
            else:
                self.anchor_subtitle.config(text=f"房间 {self.current_room}")
        except Exception:
            pass
        face = state.get("anchor_face", "")
        if face:
            if face.startswith("http://"):
                face_url = "https://" + face[7:]
            else:
                face_url = face
            cached = self.avatar_cache.get(face_url)
            if cached and cached.get("big") and \
                    self._widget_alive(self.header_avatar_label):
                try:
                    self.header_avatar_label.config(image=cached["big"],
                                                     text="")
                    self._header_avatar_photo = cached["big"]
                except Exception:
                    pass
            else:
                if self._widget_alive(self.header_avatar_label):
                    try:
                        self.header_avatar_label.config(image="", text="")
                    except Exception:
                        pass
                self._request_avatar(face_url)
        else:
            if self._widget_alive(self.header_avatar_label):
                try:
                    self.header_avatar_label.config(image="", text="")
                except Exception:
                    pass

    def _refresh_main_panel(self):
        state = self.rooms_state.get(self.current_room)
        if not state:
            if self._widget_alive(self.title_label):
                try:
                    self.title_label.config(text="没有正在监听的直播间")
                except Exception:
                    pass
            if self._widget_alive(self.anchor_subtitle):
                try:
                    self.anchor_subtitle.config(text="")
                except Exception:
                    pass
            if self._widget_alive(self.header_avatar_label):
                try:
                    self.header_avatar_label.config(image="", text="")
                except Exception:
                    pass
            for k in TOP_KEYS:
                self._update_capsule(k, "-")
            if self._widget_alive(self.area_val_label):
                try:
                    self.area_val_label.config(text="—")
                except Exception:
                    pass
            if self._widget_alive(self.watched_val_label):
                try:
                    self.watched_val_label.config(text="0")
                except Exception:
                    pass
            if self._widget_alive(self.event_text):
                try:
                    self.event_text.configure(state=tk.NORMAL)
                    self.event_text.delete("1.0", tk.END)
                    self.event_text.configure(state=tk.DISABLED)
                except Exception:
                    pass
            self.pk_panel.grid_remove()
            return
        if self._widget_alive(self.title_label):
            try:
                self.title_label.config(text=state["title"])
            except Exception:
                pass
        self._refresh_header_info()
        self._refresh_area_capsule()
        self._update_watched_label()
        if not state.get("area_id") and not state.get("area_name"):
            self._fetch_area_info(self.current_room)
        if self._live_dialog and self._live_dialog.winfo_exists():
            try:
                self._live_dialog.title(f"直播画面 · 房间 {self.current_room}")
                if self._widget_alive(self._live_room_lbl):
                    self._live_room_lbl.config(
                        text=f"房间 {self.current_room}")
            except Exception:
                pass
            self._prefetch_current_room_urls()
        if self._interact_window and self._interact_window.winfo_exists():
            try:
                self._interact_window.title(
                    f"互动消息 · 房间 {self.current_room}")
                if self._widget_alive(self._interact_room_lbl):
                    self._interact_room_lbl.config(
                        text=f"房间 {self.current_room}")
                self._interact_room_id = self.current_room
                self._rebuild_interact(state.get("interact_buffer", []))
            except Exception:
                pass
        for k in TOP_KEYS:
            v = state["status"].get(k, "-")
            self._update_capsule(k, v)
        self._rebuild_event_text(state["event_buffer"])
        self._refresh_rank_display()
        self._refresh_pk_panel()

    def _refresh_rank_display(self):
        if not self._widget_alive(self.rank_inner):
            return
        state = self.rooms_state.get(self.current_room)
        rank_list = state["rank_list"] if state else []

        for w in self.rank_inner.winfo_children():
            w.destroy()

        if self._widget_alive(self.rank_count_label):
            try:
                self.rank_count_label.config(text=f"{len(rank_list)} 人")
            except Exception:
                pass

        if not rank_list:
            tk.Label(self.rank_inner, text="暂无数据", fg=FG_DIM,
                     bg=BG_PANEL, font=FONT_BODY).pack(pady=24)
            if self._rank_canvas is not None:
                self._bind_mousewheel_recursive(self._rank_canvas,
                                                 self.rank_inner)
            return

        for i, item in enumerate(rank_list, 1):
            self._build_rank_item(self.rank_inner, i, item)

        if self._rank_canvas is not None:
            self._bind_mousewheel_recursive(self._rank_canvas, self.rank_inner)
            try:
                self._rank_canvas.update_idletasks()
                self._rank_canvas.configure(
                    scrollregion=self._rank_canvas.bbox("all"))
            except Exception:
                pass

    def _build_rank_item(self, parent, rank, item):
        is_top3 = rank <= 3
        bg = BG_CARD if is_top3 else BG_PANEL

        row = tk.Frame(parent, bg=bg)
        row.pack(fill=tk.X, padx=2, pady=2)

        rank_colors = {1: "#ffd700", 2: "#c0c0c0", 3: "#cd7f32"}
        rank_color = rank_colors.get(rank, FG_DIM)
        rank_font = ("Microsoft YaHei UI", 12, "bold") if is_top3 else FONT_SMALL
        tk.Label(row, text=str(rank), fg=rank_color, bg=bg, font=rank_font,
                 width=2).pack(side=tk.LEFT, padx=8, pady=8)

        url = item.get("face", "")
        if url.startswith("http://"):
            url = "https://" + url[7:]
        user_uid = item.get("uid", 0) or 0
        user_name = item.get("uname", "") or ""
        avatar_ph = self.avatar_cache.get(url, {}).get("rank") if url else None

        av_wrap = tk.Frame(row, bg=bg, cursor="hand2")
        av_wrap.pack(side=tk.LEFT, pady=8)
        av = tk.Label(av_wrap, bg=bg, text="", bd=0, relief=tk.FLAT,
                       cursor="hand2")
        av.pack()
        if avatar_ph:
            av.config(image=avatar_ph)
            av.image = avatar_ph
        elif url:
            self._request_avatar(url)

        if user_uid:
            av.bind("<Button-1>",
                     lambda e, u=user_uid, n=user_name, f=url:
                     self._show_user_detail(uid=u, name=n, face=f))
            av_wrap.bind("<Button-1>",
                          lambda e, u=user_uid, n=user_name, f=url:
                          self._show_user_detail(uid=u, name=n, face=f))

        info = tk.Frame(row, bg=bg)
        info.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=10)

        uname = item.get("uname", "?")
        if len(uname) > 10:
            uname = uname[:10] + "..."
        bg_name = _norm_color(item.get("color_main", ""), "")
        fg_name = _norm_color(item.get("color_text", ""), "")
        name_lbl = None
        if bg_name:
            if not fg_name:
                fg_name = _pick_text_color(bg_name)
            name_lbl = tk.Label(info, text=" " + uname + " ", fg=fg_name,
                                 bg=bg_name, font=FONT_BODY, anchor=tk.W,
                                 cursor="hand2")
            name_lbl.pack(fill=tk.X, pady=(1, 0))
        else:
            name_lbl = tk.Label(info, text=uname, fg=FG_MAIN, bg=bg,
                                 font=FONT_BODY, anchor=tk.W, cursor="hand2")
            name_lbl.pack(fill=tk.X)

        if user_uid:
            name_lbl.bind("<Button-1>",
                           lambda e, u=user_uid, n=user_name, f=url:
                           self._show_user_detail(uid=u, name=n, face=f))

        mn = item.get("medal_name", "")
        ml = item.get("medal_level", 0)
        if mn or ml:
            medal_text = "[" + mn + (f" {ml}" if ml else "") + "]"
            mcolor = _norm_color(item.get("color_border", ""), ACCENT)
            tk.Label(info, text=medal_text, fg=mcolor, bg=bg, font=FONT_TINY,
                     anchor=tk.W).pack(fill=tk.X, pady=(2, 0))

        score = item.get("score", 0)
        if score:
            if score >= 10000:
                score_str = f"{score / 10000:.1f}万"
            else:
                score_str = str(score)
            tk.Label(row, text=score_str, fg=WARN, bg=bg, font=FONT_SMALL,
                     anchor=tk.E).pack(side=tk.RIGHT, padx=10)

    def _switch_room(self, rid):
        if rid not in self.rooms_state or rid == self.current_room:
            return
        old = self.current_room
        self.current_room = rid
        if old:
            self._update_card_highlight(old, False)
        self._update_card_highlight(rid, True)
        self._refresh_main_panel()

    def _update_card_highlight(self, rid, is_cur):
        refs = self.room_cards.get(rid)
        if not refs:
            return
        bg = BG_CARD if is_cur else BG_PANEL
        bar_bg = ACCENT if is_cur else BG_PANEL
        for key in ("card", "inner", "row1", "avatar_wrap", "avatar",
                    "name", "sub", "dot", "row2", "stat",
                    "row_area", "area", "pk_row", "pk_label"):
            if key in refs and self._widget_alive(refs[key]):
                try:
                    refs[key].config(bg=bg)
                except Exception:
                    pass
        if self._widget_alive(refs.get("bar")):
            try:
                refs["bar"].config(bg=bar_bg)
            except Exception:
                pass

    def add_event(self, room_id, msg, style=None, color_info=None):
        self.q.put(("event", room_id, msg, style, color_info))

    def update_status(self, room_id, key, value):
        self.q.put(("status", room_id, key, value))

    def update_title(self, room_id, title):
        self.q.put(("title", room_id, title))

    def update_rank_list(self, room_id, rank_list):
        self.q.put(("rank", room_id, list(rank_list)))

    def update_anchor(self, room_id, uname, face, uid=0):
        self.q.put(("anchor", room_id, uname, face, int(uid or 0)))

    def update_area(self, room_id, area_id, area_name=""):
        self.q.put(("area", room_id, area_id, area_name))

    def update_pk(self, room_id, pk_data):
        self.q.put(("pk", room_id, dict(pk_data) if pk_data else {}))

    def update_account(self, info):
        self.q.put(("account", dict(info)))