#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# main.py
"""程序入口"""
import argparse
import asyncio
import faulthandler
import json
import re
import signal
import threading
import time
import tkinter as tk
from pathlib import Path

import account
import auth
import logger
import live_player
from logger import log, log_err
from live import BiliLive
from ui import TkUI
from dialogs import LoginDialog, AccountDialog


try:
    _FAULT_FILE = open("fault.log", "w", buffering=1, encoding="utf-8")
    faulthandler.enable(file=_FAULT_FILE, all_threads=True)
except Exception:
    _FAULT_FILE = None


ROOMS_DIR = Path("rooms")
ROOMS_DIR.mkdir(exist_ok=True)
ROOMS_FILE = ROOMS_DIR / "rooms.json"

_old_rooms = Path("rooms.json")
if _old_rooms.exists() and not ROOMS_FILE.exists():
    try:
        ROOMS_FILE.write_text(_old_rooms.read_text(encoding="utf-8"),
                              encoding="utf-8")
        _old_rooms.unlink()
    except Exception:
        pass

DEFAULT_ROOM_IDS = [1768500100]

# upower 大表情的正则匹配
_UPOWER_RE = re.compile(r"^upower_\[.+\]$")


def load_rooms():
    if not ROOMS_FILE.exists():
        return []
    try:
        data = json.loads(ROOMS_FILE.read_text(encoding="utf-8"))
        rooms = data.get("rooms", [])
        out = []
        for r in rooms:
            try:
                rid = int(r)
                if rid > 0:
                    out.append(rid)
            except Exception:
                pass
        return out
    except Exception:
        return []


def save_rooms(rooms):
    try:
        ROOMS_FILE.write_text(
            json.dumps({"rooms": list(rooms)}, ensure_ascii=False, indent=2),
            encoding="utf-8")
    except Exception as e:
        log_err(f"保存房间列表失败: {e}")


parser = argparse.ArgumentParser()
parser.add_argument("rooms", nargs="*", type=int, default=None)
args, _ = parser.parse_known_args()
if args.rooms:
    ROOM_IDS = list(dict.fromkeys(args.rooms))
else:
    ROOM_IDS = load_rooms() or DEFAULT_ROOM_IDS
ROOM_IDS = list(dict.fromkeys(ROOM_IDS))


def _install_tk_exception_handler(root):
    def _handler(exc_type, exc_val, exc_tb):
        try:
            log_err(f"Tk 回调异常: {exc_type.__name__}: {exc_val}")
        except Exception:
            pass
        try:
            import traceback
            traceback.print_exception(exc_type, exc_val, exc_tb)
        except Exception:
            pass
    root.report_callback_exception = _handler


def _install_asyncio_exception_handler(loop):
    def _handler(loop_, context):
        try:
            exc = context.get("exception")
            silent_types = (
                ConnectionResetError, ConnectionAbortedError,
                ConnectionRefusedError, BrokenPipeError, TimeoutError,
            )
            if isinstance(exc, silent_types):
                return
            msg = context.get("message", "asyncio 未处理异常")
            try:
                log_err(f"asyncio: {msg} ({exc!r})")
            except Exception:
                pass
        except Exception:
            pass
    try:
        loop.set_exception_handler(_handler)
    except Exception:
        pass


def main():
    root = tk.Tk()
    _install_tk_exception_handler(root)

    holder = {
        "loop": None, "lives": {}, "ui": None, "stop_event": None,
        "_account_task_created": False, "rooms": list(ROOM_IDS),
    }

    import queue as _queue
    _ui_queue = _queue.Queue()
    _ui_queue_closed = threading.Event()

    def _post_ui(func, *args, **kwargs):
        if _ui_queue_closed.is_set():
            return False
        try:
            _ui_queue.put((func, args, kwargs))
            return True
        except Exception:
            return False

    def _drain_ui_queue():
        if _ui_queue_closed.is_set():
            return
        for _ in range(200):
            try:
                func, args, kwargs = _ui_queue.get_nowait()
            except _queue.Empty:
                break
            try:
                func(*args, **kwargs)
            except tk.TclError as e:
                log_err(f"UI 操作失败，控件可能已销毁: {e}")
            except Exception as e:
                log_err(f"UI 队列操作异常: {e}")
        try:
            if root.winfo_exists():
                root.after(30, _drain_ui_queue)
        except tk.TclError:
            _ui_queue_closed.set()
        except Exception:
            _ui_queue_closed.set()

    def _persist_rooms():
        save_rooms(holder["rooms"])

    # ---- 预热 ----
    def prewarm_all():
        def _audio_worker():
            try:
                result = live_player.prewarm_audio()
                if result:
                    sr, ch, _lat = result
                    log(f"音频设备预热完成：{sr}Hz / {ch}ch", "PLAYER")
                else:
                    log("音频设备预热失败：未检测到可用输出设备，"
                        "播放时将自动静音", "PLAYER")
            except Exception as e:
                log_err(f"音频设备预热异常: {e}")
        threading.Thread(target=_audio_worker, daemon=True,
                         name="audio-prewarm").start()
        log("音频设备预热已启动", "PLAYER")
        try:
            live_player.prewarm_all_rooms(
                holder["rooms"], qn=10000, platform_="web",
                on_done=_on_prewarm_done)
            log(f"URL 预取已启动：{len(holder['rooms'])} 个房间", "PLAYER")
        except Exception as e:
            log_err(f"URL 预取启动失败: {e}")

    def _on_prewarm_done(ok, total):
        try:
            if ok < total:
                log(f"URL 预取完成：成功 {ok}/{total} 个房间", "PLAYER")
            else:
                log(f"URL 预取完成：全部 {total} 个房间", "PLAYER")
        except Exception:
            pass

    # ============================================================
    #  发送弹幕 / 表情
    # ============================================================
    _EMOTE_PREFIXES = ("/emote ", "/e ", "/表情 ", "/t ")

    def send_cb(room_id, msg):
        if not account.has_login():
            log("未登录，无法发送弹幕", "WARN")
            return
        live = holder["lives"].get(room_id)
        loop = holder.get("loop")
        if not live or not loop:
            log(f"房间 {room_id} 尚未连接", "WARN")
            return

        text = (msg or "").strip()
        if not text:
            return

        # 判断是"大表情整条消息"还是"普通弹幕（可含小表情）"
        is_emote = False
        emote_key = None
        for p in _EMOTE_PREFIXES:
            if text.startswith(p):
                is_emote = True
                emote_key = text[len(p):].strip()
                break
        if not is_emote and _UPOWER_RE.match(text):
            is_emote = True
            emote_key = text

        if is_emote and not emote_key:
            log("表情 key 为空", "WARN", room_id=room_id)
            return

        async def _do():
            try:
                if is_emote:
                    target = await live.send_emoticon(emote_key)
                    label = (target or {}).get("emoji") or emote_key
                    _post_ui(holder["ui"].add_event, room_id,
                             f"[我] {label}", "green")
                else:
                    await live.send_danmu(text)
                    _post_ui(holder["ui"].add_event, room_id,
                             f"[我] {text}", "green")
            except Exception as e:
                log_err(f"发送失败: {e}", room_id=room_id)

        try:
            asyncio.run_coroutine_threadsafe(_do(), loop)
        except Exception as e:
            log_err(f"调度发送失败: {e}")

    def send_emoticon_cb(room_id, key):
        if not key:
            return False, "表情 key 为空"
        send_cb(room_id, f"/emote {key}")
        return True, ""

    def list_emoticons_cb(room_id):
        live = holder["lives"].get(room_id)
        if not live:
            return []
        try:
            return live.list_emoticons()
        except Exception as e:
            log_err(f"获取表情列表失败: {e}", room_id=room_id)
            return []

    holder["send_emoticon_cb"] = send_emoticon_cb
    holder["list_emoticons_cb"] = list_emoticons_cb

    # ---- PK ----
    def refresh_pk_cb(room_id):
        live = holder["lives"].get(room_id)
        if not live:
            log("刷新 PK 失败：房间未连接", "PK", room_id=room_id)
            return
        loop = holder.get("loop")
        if not loop:
            return
        try:
            live.replay_pk()
        except Exception as e:
            log_err(f"重放 PK 失败: {e}", room_id=room_id)

        def _do():
            try:
                fut = asyncio.run_coroutine_threadsafe(
                    live._refresh_pk(), loop)
                fut.result(timeout=8)
                log("PK 主动刷新完成", "PK", room_id=room_id)
            except Exception as e:
                log_err(f"主动刷新 PK 失败: {e}", room_id=room_id)
        threading.Thread(target=_do, daemon=True,
                         name=f"pk-refresh-{room_id}").start()

    # ---- 点赞 ----
    def like_report_cb(room_id, count=1000):
        if not account.has_login():
            return False, "未登录"
        live = holder["lives"].get(room_id)
        if not live:
            return False, f"房间 {room_id} 未连接"
        anchor_id = getattr(live, "anchor_uid", 0) or 0
        if anchor_id <= 0:
            return False, "主播 UID 尚未获取，稍后再试"
        my_uid = account.UID
        if not my_uid:
            return False, "未获取到当前账号 UID"

        def _do():
            try:
                from like_report import report_like_sync
            except Exception as e:
                log_err(f"点赞模块加载失败: {e}")
                return
            ok, msg = report_like_sync(room_id, anchor_id, my_uid, count)
            if ok:
                log(f"点赞上报成功：{msg}", "LIKE", room_id=room_id)
                try:
                    _post_ui(holder["ui"].add_event, room_id,
                             f"[点赞] 一次性上报 {count} 个", "yellow")
                except Exception:
                    pass
            else:
                log_err(f"点赞上报失败: {msg}", room_id=room_id)
        threading.Thread(target=_do, daemon=True,
                         name=f"like-report-{room_id}").start()
        return True, ""

    def _rp_ui_event(room_id, msg, style="yellow"):
        try:
            ui_ref = holder.get("ui")
            if ui_ref is None:
                return
            _post_ui(ui_ref.add_event, int(room_id or 0), msg, style)
        except Exception:
            pass

    # ---- 添加 / 删除房间 ----
    def add_room_cb(room_id):
        if room_id <= 0:
            return False, "房间号必须为正整数"
        if room_id in holder["lives"]:
            return False, f"房间 {room_id} 已在监听中"
        loop = holder.get("loop")
        if not loop:
            return False, "后台线程未就绪"
        try:
            loop.call_soon_threadsafe(_spawn_room, room_id)
        except Exception as e:
            return False, f"调度失败: {e}"
        return True, ""

    def _spawn_room(room_id):
        if room_id in holder["lives"]:
            return

        async def _create():
            try:
                live = BiliLive(room_id)
                await live.init_session()
                holder["lives"][room_id] = live
                live.set_ui(holder["ui"])

                async def _register_rp(_rid=room_id, _live=live):
                    for _ in range(60):
                        if getattr(_live, "anchor_uid", 0):
                            try:
                                from red_packet import red_packet_manager
                                red_packet_manager.register_room(
                                    _rid, _live.anchor_uid)
                                log(f"红包监听已注册 房间 {_rid} "
                                    f"(UID={_live.anchor_uid})", "RP")
                            except Exception as e:
                                log_err(f"注册红包监听失败: {e}")
                            return
                        await asyncio.sleep(1)
                asyncio.create_task(_register_rp())

                async def print_msg(msg, style=None, color_info=None,
                                     _rid=room_id):
                    _post_ui(holder["ui"].add_event, _rid, msg,
                             style, color_info)
                live.set_print_fn(print_msg)

                _post_ui(holder["ui"].register_room, room_id)

                for k, v in [
                    ("连接", "在线"), ("直播", "未知"), ("人气", 0),
                    ("在线", 0), ("排名", 0), ("弹幕", 0),
                    ("礼物", 0), ("SC", 0), ("粉丝", 0),
                ]:
                    _post_ui(holder["ui"].update_status, room_id, k, v)
                _post_ui(holder["ui"].update_rank_list, room_id, [])

                try:
                    live_player.url_provider.prefetch_async(
                        room_id, qn=10000, platform_="web")
                except Exception:
                    pass

                async def _prefetch_emotes(_rid=room_id, _live=live):
                    try:
                        pkgs = await _live.fetch_emoticons()
                        n_pkg = len(pkgs or [])
                        n_em = sum(len(p.get("emoticons", []))
                                   for p in (pkgs or []))
                        log(f"表情列表就绪：{n_pkg} 个分区 / {n_em} 个表情",
                            "EMOTE", show=False, room_id=_rid)
                    except Exception:
                        pass
                asyncio.create_task(_prefetch_emotes())

                if not holder["_account_task_created"]:
                    live.account_task = asyncio.create_task(
                        live.update_account_loop())
                    holder["_account_task_created"] = True

                if room_id not in holder["rooms"]:
                    holder["rooms"].append(room_id)
                    _persist_rooms()

                log(f"已启动监听", "MAIN", room_id=room_id)
                await live.main_loop()
            except Exception as e:
                log_err(f"启动失败: {e}", room_id=room_id)
                holder["lives"].pop(room_id, None)
                _post_ui(holder["ui"].unregister_room, room_id)

        asyncio.create_task(_create())

    def remove_room_cb(room_id):
        if room_id not in holder["lives"]:
            return False, f"房间 {room_id} 不在监听列表"
        if len(holder["rooms"]) <= 1:
            return False, "至少需要保留一个直播间"
        loop = holder.get("loop")
        if not loop:
            return False, "后台线程未就绪"
        try:
            loop.call_soon_threadsafe(_remove_room, room_id)
        except Exception as e:
            return False, f"调度失败: {e}"
        return True, ""

    def _remove_room(room_id):
        try:
            from red_packet import red_packet_manager
            red_packet_manager.unregister_room(room_id)
        except Exception:
            pass
        live = holder["lives"].pop(room_id, None)
        if live:
            try:
                live.stop()
            except Exception:
                pass
            try:
                asyncio.create_task(live.close())
            except Exception as e:
                log_err(f"关闭连接异常: {e}", room_id=room_id)
        if room_id in holder["rooms"]:
            holder["rooms"].remove(room_id)
            _persist_rooms()
        _post_ui(holder["ui"].unregister_room, room_id)
        log("已停止监听", "MAIN", room_id=room_id)

    # ---- 账号 ----
    def refresh_account():
        def _do():
            loop = asyncio.new_event_loop()
            try:
                info = loop.run_until_complete(auth.fetch_account_info())
                for k in info:
                    account.account_info[k] = info[k]
                if info.get("is_login"):
                    data = account.load_accounts()
                    mid = str(info.get("mid"))
                    if mid and mid != "0":
                        acc = data["accounts"].get(mid, {})
                        acc["cookie"] = account.get_cookie_dict()
                        acc["uname"] = info.get("uname", "")
                        acc["face"] = info.get("face", "")
                        acc["mid"] = info.get("mid", 0)
                        acc["level"] = info.get("level", 0)
                        acc["coin"] = info.get("coin", 0)
                        acc["bcoin"] = info.get("bcoin", 0)
                        acc["vip_status"] = info.get("vip_status", 0)
                        acc["vip_label"] = info.get("vip_label", "")
                        acc["saved_at"] = time.time()
                        data["accounts"][mid] = acc
                        data["current"] = mid
                        account.save_accounts(data)
                _post_ui(_safe_update_account, info)
            except Exception as e:
                log_err(f"刷新账号失败: {e}")
            finally:
                try:
                    loop.close()
                except Exception:
                    pass
        threading.Thread(target=_do, daemon=True,
                         name="refresh-account").start()

    def _safe_update_account(info):
        try:
            ui_ref = holder.get("ui")
            if ui_ref is not None and root.winfo_exists():
                ui_ref.update_account(info)
        except tk.TclError as e:
            log_err(f"更新账号 UI 失败(窗口已销毁): {e}")
        except Exception as e:
            log_err(f"更新账号 UI 失败: {e}")

    def trigger_reconnect():
        for rid, live in list(holder["lives"].items()):
            try:
                live.request_relogin()
            except Exception as e:
                log_err(f"重连请求失败: {e}", room_id=rid)

    def _open_dialog_safely(opener, name="对话框"):
        if not root.winfo_exists():
            return None
        try:
            return opener()
        except tk.TclError as e:
            log_err(f"{name} 已关闭: {e}")
        except Exception as e:
            log_err(f"{name} 异常: {e}")
            try:
                import traceback
                traceback.print_exc()
            except Exception:
                pass
        return None

    def open_login():
        def _open():
            def on_saved():
                try:
                    trigger_reconnect()
                except Exception as e:
                    log_err(f"重连失败: {e}")
                try:
                    refresh_account()
                except Exception as e:
                    log_err(f"刷新账号失败: {e}")
            return LoginDialog(root, on_saved)
        _open_dialog_safely(_open, "登录对话框")

    def do_logout():
        def _do():
            loop = asyncio.new_event_loop()
            try:
                try:
                    ok = loop.run_until_complete(auth.api_logout())
                    if ok:
                        log("服务端 Token 已失效", "AUTH")
                except Exception as e:
                    log_err(f"注销接口异常: {e}")
                cur_mid = str(account.UID)
                new_current = account.remove_account(cur_mid)
                log(f"已退出账号 UID={cur_mid}", "AUTH")
                if new_current:
                    account.apply_account_to_cookie_file(new_current)
                    data = account.load_accounts()
                    acc = data["accounts"].get(new_current, {})
                    log(f"已切换到: {acc.get('uname')}", "AUTH")
                else:
                    try:
                        account.COOKIE_FILE.write_text("", encoding="utf-8")
                    except Exception:
                        pass
                    log("已切换到未登录状态", "AUTH")
                account.reload_headers()
                trigger_reconnect()
            except Exception as e:
                log_err(f"退出登录失败: {e}")
            finally:
                try:
                    loop.close()
                except Exception:
                    pass
        t = threading.Thread(target=_do, daemon=True)
        t.start()
        try:
            root.after(800, refresh_account)
        except Exception:
            pass

    def do_logout_specific(mid):
        def _do():
            try:
                if not account.set_current_account(mid):
                    log_err(f"切换失败: {mid}")
                    return
                if not account.apply_account_to_cookie_file(mid):
                    log_err(f"应用 cookie 失败: {mid}")
                    return
                account.reload_headers()
                loop = asyncio.new_event_loop()
                try:
                    try:
                        ok = loop.run_until_complete(auth.api_logout())
                        if ok:
                            log(f"服务端注销成功 UID={mid}", "AUTH")
                    except Exception:
                        pass
                finally:
                    try:
                        loop.close()
                    except Exception:
                        pass
                new_current = account.remove_account(mid)
                if new_current:
                    account.apply_account_to_cookie_file(new_current)
                    data = account.load_accounts()
                    acc = data["accounts"].get(new_current, {})
                    log(f"已切换到: {acc.get('uname')}", "AUTH")
                else:
                    try:
                        account.COOKIE_FILE.write_text("",
                                                       encoding="utf-8")
                    except Exception:
                        pass
                    log("已切换到未登录状态", "AUTH")
                account.reload_headers()
                trigger_reconnect()
            except Exception as e:
                log_err(f"退出指定账号失败: {e}")
        t = threading.Thread(target=_do, daemon=True)
        t.start()
        try:
            root.after(800, refresh_account)
        except Exception:
            pass

    def do_switch(mid):
        def _do():
            try:
                if account.set_current_account(mid):
                    account.apply_account_to_cookie_file(mid)
                    account.reload_headers()
                    data = account.load_accounts()
                    acc = data["accounts"].get(mid, {})
                    log(f"已切换到: {acc.get('uname', mid)}", "AUTH")
                    trigger_reconnect()
                else:
                    log_err(f"切换失败: 未找到账号 {mid}")
            except Exception as e:
                log_err(f"切换账号异常: {e}")
        t = threading.Thread(target=_do, daemon=True)
        t.start()
        try:
            root.after(500, refresh_account)
        except Exception:
            pass

    def account_cb():
        def _open():
            return AccountDialog(root, {
                "login": open_login,
                "logout": do_logout,
                "logout_specific": do_logout_specific,
                "switch": do_switch,
                "reconnect": trigger_reconnect,
            }, refresh_account)
        _open_dialog_safely(_open, "账号对话框")

    # ---- UI ----
    try:
        ui = TkUI(root, ROOM_IDS, send_cb, account_cb,
                  add_room_cb=add_room_cb, remove_room_cb=remove_room_cb,
                  refresh_pk_cb=refresh_pk_cb,
                  like_report_cb=like_report_cb,
                  on_account_changed_cb=refresh_account,
                  switch_account_cb=do_switch,
                  logout_account_cb=do_logout,
                  send_emoticon_cb=send_emoticon_cb,
                  list_emoticons_cb=list_emoticons_cb)
    except TypeError as e:
        log(f"TkUI 暂不支持表情回调，将使用 /emote 前缀输入：{e}", "WARN")
        ui = TkUI(root, ROOM_IDS, send_cb, account_cb,
                  add_room_cb=add_room_cb, remove_room_cb=remove_room_cb,
                  refresh_pk_cb=refresh_pk_cb,
                  like_report_cb=like_report_cb,
                  on_account_changed_cb=refresh_account,
                  switch_account_cb=do_switch,
                  logout_account_cb=do_logout)
    holder["ui"] = ui

    try:
        from red_packet import red_packet_manager
        red_packet_manager.on_ui_event = _rp_ui_event
    except Exception:
        pass

    root.after(30, _drain_ui_queue)
    root.after(50, prewarm_all)

    def _restore_rp_state():
        try:
            from red_packet import red_packet_manager
            if red_packet_manager.is_enabled():
                return
            if getattr(red_packet_manager, "_pref_enabled", False):
                if red_packet_manager.start():
                    log("红包已自动恢复运行（上次退出时为开启状态）", "RP")
        except Exception as e:
            log_err(f"恢复红包状态失败: {e}")

    # ---- asyncio ----
    def asyncio_thread():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        holder["loop"] = loop
        _install_asyncio_exception_handler(loop)

        async def run():
            stop_event = asyncio.Event()
            holder["stop_event"] = stop_event
            for rid in ROOM_IDS:
                _spawn_room(rid)
            try:
                await stop_event.wait()
            except asyncio.CancelledError:
                pass
            finally:
                for live in list(holder["lives"].values()):
                    try:
                        live.stop()
                    except Exception:
                        pass
                await asyncio.gather(
                    *[live.close() for live in holder["lives"].values()],
                    return_exceptions=True)
                try:
                    logger.close()
                except Exception:
                    pass

        try:
            loop.run_until_complete(run())
        except Exception as e:
            log_err(f"后台线程异常: {e}")

    if not ROOMS_FILE.exists():
        save_rooms(ROOM_IDS)

    data = account.load_accounts()
    accounts = data.get("accounts", {})
    if len(accounts) == 1:
        mid = list(accounts.keys())[0]
        if account.apply_account_to_cookie_file(mid):
            account.set_current_account(mid)
            account.reload_headers()
            log(f"自动登录: {accounts[mid].get('uname', mid)}", "AUTH")

    log(f"启动房间列表: {ROOM_IDS}", "MAIN")
    threading.Thread(target=asyncio_thread, daemon=True).start()
    root.after(1500, refresh_account)
    root.after(8000, _restore_rp_state)

    def on_close():
        _ui_queue_closed.set()
        while True:
            try:
                _ui_queue.get_nowait()
            except _queue.Empty:
                break
            except Exception:
                break
        try:
            from red_packet import red_packet_manager
            red_packet_manager.stop()
            red_packet_manager.on_ui_event = None
        except Exception:
            pass
        try:
            stop_event = holder.get("stop_event")
            loop = holder.get("loop")
            if stop_event and loop and not loop.is_closed():
                try:
                    loop.call_soon_threadsafe(stop_event.set)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            root.destroy()
        except Exception:
            pass
        try:
            if _FAULT_FILE is not None:
                faulthandler.disable()
                _FAULT_FILE.close()
        except Exception:
            pass

    root.protocol("WM_DELETE_WINDOW", on_close)
    root.mainloop()


if __name__ == "__main__":
    try:
        signal.signal(signal.SIGINT, signal.SIG_IGN)
    except Exception:
        pass
    try:
        main()
    except Exception as e:
        log_err(f"致命异常: {e}")
        import traceback
        traceback.print_exc()
        input("按回车退出...")