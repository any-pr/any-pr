#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# avatar_cache.py
"""头像磁盘 + 内存缓存"""
import io
import hashlib
import urllib.request
from pathlib import Path
from PIL import Image

CACHE_DIR = Path("cache") / "avatars"
CACHE_DIR.mkdir(parents=True, exist_ok=True)

AVATAR_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 Chrome/120 Safari/537.36",
    "Referer": "https://www.bilibili.com/",
    "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9",
}

_mem_pil = {}


def _key(url: str) -> str:
    return hashlib.sha1(url.encode("utf-8")).hexdigest()


def _disk_path(url: str) -> Path:
    return CACHE_DIR / (_key(url) + ".png")


def _normalize(url: str) -> str:
    if url.startswith("http://"):
        return "https://" + url[7:]
    return url


def load_image(url: str):
    """返回 PIL.Image (RGB)。顺序：内存 → 磁盘 → 网络。失败返回 None。"""
    if not url:
        return None
    url = _normalize(url)
    if url in _mem_pil:
        return _mem_pil[url]
    p = _disk_path(url)
    if p.exists():
        try:
            img = Image.open(p).convert("RGB")
            _mem_pil[url] = img
            return img
        except Exception:
            try:
                p.unlink()
            except Exception:
                pass
    try:
        req = urllib.request.Request(url, headers=AVATAR_HEADERS)
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = resp.read()
        if not data:
            return None
        img = Image.open(io.BytesIO(data)).convert("RGB")
        try:
            img.save(p)
        except Exception:
            pass
        _mem_pil[url] = img
        return img
    except Exception:
        return None


def has_cache(url: str) -> bool:
    if not url:
        return False
    url = _normalize(url)
    return url in _mem_pil or _disk_path(url).exists()


def clear():
    try:
        for f in CACHE_DIR.glob("*.png"):
            f.unlink()
    except Exception:
        pass
    _mem_pil.clear()