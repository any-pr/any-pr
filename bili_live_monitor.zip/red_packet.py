# -*- coding: utf-8 -*-
"""B站自动抢红包 + 自动抢天选 + 自动关注/发弹幕

去重策略：lot_id 全局共享 set，同一 lot_id 只处理一次。
开关状态：持久化到 rooms/red_packet_config.json，首次运行默认关闭。
"""
import asyncio
import hashlib
import json
import threading
import time
from pathlib import Path

import aiohttp

import account
from logger import log, log_err

try:
    from pb import build_packet, parse_packets, split_json_objects
except Exception:
    build_packet = None
    parse_packets = None
    split_json_objects = None


CONFIG = {
    "max_listen_seconds": 600,
    "scan_interval": 30,
    "danmu_wait_seconds": 1.5,
    "follow_interval": 300,
}


LOTTERY_INFO_API = ("https://api.live.bilibili.com/xlive/lottery-interface"
                    "/v1/lottery/getLotteryInfoWeb")
RED_POCKET_DRAW_API = ("https://api.live.bilibili.com/xlive/lottery-interface"
                       "/v1/popularityRedPocket/RedPocketDraw")
DANMU_INFO_API = ("https://api.live.bilibili.com/xlive/web-room/v1/index"
                  "/getDanmuInfo")
RELATION_MODIFY_API = "https://api.bilibili.com/x/relation/modify"
DM_SEND_API = "https://api.live.bilibili.com/msg/send"
ANCHOR_LOT_JOIN_API = ("https://api.live.bilibili.com/xlive/lottery-interface"
                       "/v1/AnchorLot/Join")

WINNER_CMDS = (
    "POPULARITY_RED_POCKET_WINNER_LIST",
    "POPULARITY_RED_POCKET_V2_WINNER_LIST",
)
ANCHOR_LOT_START_CMD = "ANCHOR_LOT_START"
ANCHOR_LOT_AWARD_CMD = "ANCHOR_LOT_AWARD"


# ============================================================
#  配置持久化
# ============================================================
_CONFIG_FILE = Path("rooms") / "red_packet_config.json"


def _load_rp_config():
    """读取开关配置。失败或不存在时返回空 dict（一切默认关闭）。"""
    try:
        if _CONFIG_FILE.exists():
            data = json.loads(_CONFIG_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    return {}


def _save_rp_config(cfg):
    """保存开关配置。"""
    try:
        _CONFIG_FILE.parent.mkdir(exist_ok=True)
        _CONFIG_FILE.write_text(
            json.dumps(cfg, ensure_ascii=False, indent=2),
            encoding="utf-8")
    except Exception:
        pass


class RedPacketManager:
    def __init__(self):
        # ---------- 开关状态（首次运行默认关闭） ----------
        _cfg = _load_rp_config()
        self.anchor_enabled = bool(_cfg.get("anchor_enabled", False))
        # 用户偏好：上次退出时红包是否开启
        self._pref_enabled = bool(_cfg.get("enabled", False))
        # 运行时状态：始终初始为 False（需要 start() 才跑）
        self.enabled = False

        self._stop_event = threading.Event()
        self._rooms = {}
        self._lock = threading.Lock()

        self.running_rooms = {}
        self.joined_packets = {}
        self.joined_anchor_lots = {}

        # 全局 lot_id 去重集合
        self._seen_rp_lots = set()
        self._seen_anchor_lots = set()
        self._seen_lots_lock = threading.Lock()

        # 关注 / 弹幕缓存
        self._followed_anchors = {}
        self._follow_lock = threading.Lock()
        self._sent_red_pocket_danmu = {}

        self.stats = {
            "joined": 0,
            "won": 0,
            "gifts": [],
            "anchor_joined": 0,
            "anchor_won": 0,
            "rp_events": [],
        }

        self.on_status_update = None
        self.on_log = None
        self.on_stats_update = None
        self.on_anchor_status_update = None
        self.on_ui_event = None

        self._worker_thread = None

    # ---------- 配置保存 ----------
    def _save_prefs(self):
        _save_rp_config({
            "enabled": bool(self._pref_enabled),
            "anchor_enabled": bool(self.anchor_enabled),
        })

    # ---------- lot_id 去重接口 ----------
    def try_mark_rp_lot(self, lot_id):
        return self._try_mark(self._seen_rp_lots, lot_id)

    def try_mark_anchor_lot(self, lot_id):
        return self._try_mark(self._seen_anchor_lots, lot_id)

    def _try_mark(self, target_set, lot_id):
        try:
            lot_id = int(lot_id)
            if lot_id <= 0:
                return False
            with self._seen_lots_lock:
                if lot_id in target_set:
                    return False
                target_set.add(lot_id)
                if len(target_set) > 10000:
                    keep = set(list(target_set)[-5000:])
                    target_set.clear()
                    target_set.update(keep)
                return True
        except Exception:
            return False

    # ---------- 房间注册 ----------
    def register_room(self, room_id, uid):
        try:
            room_id = int(room_id)
            uid = int(uid)
            if room_id <= 0 or uid <= 0:
                return
            with self._lock:
                self._rooms[room_id] = uid
        except Exception:
            pass

    def unregister_room(self, room_id):
        try:
            room_id = int(room_id)
            with self._lock:
                self._rooms.pop(room_id, None)
        except Exception:
            pass

    def get_registered_rooms(self):
        with self._lock:
            return dict(self._rooms)

    # ---------- 启停 ----------
    def start(self):
        if self.enabled:
            return True
        if not account.has_login():
            log_err("未登录，无法开启自动抢红包/天选")
            return False
        self.enabled = True
        self._pref_enabled = True
        self._save_prefs()
        self._stop_event.clear()
        self._worker_thread = threading.Thread(
            target=self._run_loop, daemon=True, name="red-packet")
        self._worker_thread.start()
        log("自动抢红包 + 自动抢天选已启动（全价值 · 全房间）", "RP")
        self._fire_status()
        return True

    def stop(self):
        # 无论是否在跑，都要记录用户偏好
        self._pref_enabled = False
        self._save_prefs()
        if not self.enabled:
            return
        self.enabled = False
        self._stop_event.set()
        log("自动抢红包 + 自动抢天选已停止", "RP")
        self._fire_status()

    def is_enabled(self):
        return self.enabled

    # ---------- 天选开关 ----------
    def is_anchor_enabled(self):
        return bool(self.anchor_enabled)

    def set_anchor_enabled(self, v):
        self.anchor_enabled = bool(v)
        self._save_prefs()
        log(f"自动抢天选 {'已开启' if self.anchor_enabled else '已关闭'}", "RP")
        if self.on_anchor_status_update:
            try:
                self.on_anchor_status_update()
            except Exception:
                pass

    # ---------- 统计 ----------
    def get_stats(self):
        return dict(self.stats)

    def get_running_count(self):
        return len(self.running_rooms)

    def get_pending_count(self):
        return len(self.get_registered_rooms())

    # ---------- 事件推送 ----------
    def push_rp_event(self, event_type, payload):
        try:
            payload = dict(payload)
            payload["event_type"] = event_type
            payload["push_ts"] = time.time()

            events = self.stats.setdefault("rp_events", [])
            events.append(payload)
            if len(events) > 200:
                del events[:-200]

            self._fire_stats()

            room_id = int(payload.get("room_id", 0) or 0)
            msg = self._format_rp_event_msg(event_type, payload)
            if msg and self.on_ui_event:
                try:
                    self.on_ui_event(room_id, msg, "yellow")
                except Exception:
                    pass
        except Exception:
            pass

    @staticmethod
    def _format_rp_event_msg(event_type, payload):
        try:
            if event_type == "win_me":
                an = payload.get("award_name", "礼物")
                p = int(payload.get("award_price", 0) or 0)
                ps = f"（{p / 100:.2f}元）" if p > 0 else ""
                tn = int(payload.get("total_num", 0) or 0)
                return f"🎉 红包中奖！{an}{ps} · 共 {tn} 人获奖"
            if event_type == "winners":
                winners = payload.get("winners", []) or []
                names = []
                for w in winners[:10]:
                    n = w.get("uname", "?")
                    a = w.get("award_name", "")
                    p = int(w.get("award_price", 0) or 0)
                    if a and p:
                        names.append(f"{n}[{a}{p / 100:.1f}元]")
                    elif a:
                        names.append(f"{n}[{a}]")
                    else:
                        names.append(n)
                s = ", ".join(names)
                more = (f" 等 {len(winners)} 人"
                        if len(winners) > 10 else "")
                return (f"[红包开奖] 红包 {payload.get('lot_id', 0)} · "
                        f"共 {payload.get('total_num', 0)} 人 · "
                        f"中奖: {s}{more}")
            if event_type == "anchor_win":
                an = payload.get("award_name", "礼物")
                n = int(payload.get("num", 1) or 1)
                return f"🎉 天选中奖！{an} x{n}"
        except Exception:
            pass
        return ""

    # ---------- 回调 ----------
    def _fire_status(self):
        if self.on_status_update:
            try:
                self.on_status_update()
            except Exception:
                pass

    def _fire_stats(self):
        if self.on_stats_update:
            try:
                self.on_stats_update(self.get_stats())
            except Exception:
                pass

    def _fire_log(self, level, msg):
        if self.on_log:
            try:
                self.on_log(level, msg)
            except Exception:
                pass
        if level in ("OK", "WIN"):
            log(msg, "RP")

    # ---------- 主循环 ----------
    def _run_loop(self):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(self._async_main())
        except Exception as e:
            log_err(f"红包主循环异常: {e}")
        finally:
            try:
                loop.close()
            except Exception:
                pass

    async def _async_main(self):
        timeout = aiohttp.ClientTimeout(total=30)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            scan_interval = CONFIG["scan_interval"]
            while not self._stop_event.is_set():
                try:
                    await self._scan_and_spawn(session)
                except Exception as e:
                    log_err(f"红包扫描异常: {e}")

                for rid in list(self.running_rooms.keys()):
                    t = self.running_rooms[rid]
                    if t.done():
                        self.running_rooms.pop(rid, None)

                for _ in range(scan_interval):
                    if self._stop_event.is_set():
                        break
                    await asyncio.sleep(1)

    async def _scan_and_spawn(self, session):
        rooms = self.get_registered_rooms()
        if not rooms:
            self._fire_log("INFO", "暂无已监听的直播间")
            return

        spawned = 0
        checked = 0

        for rid, uid in rooms.items():
            if self._stop_event.is_set():
                return
            if rid in self.running_rooms:
                continue

            checked += 1
            packets = await self._get_packets(session, rid)
            if not packets:
                continue

            valid = self._filter_packets(packets)
            if not valid:
                continue

            task = asyncio.create_task(
                self._grab_worker(session, rid, uid))
            self.running_rooms[rid] = task
            spawned += 1
            first = valid[0]
            price = int(first.get("total_price", 0) or 0) / 100
            wait_num = int(first.get("wait_num", 0) or 0)
            self._fire_log(
                "INFO",
                f"房间 {rid} 有红包 · 价值 {price} 元 · "
                f"剩余 {wait_num} 个 · 已启动")

        if spawned == 0:
            self._fire_log(
                "INFO",
                f"扫描完成 · {len(rooms)} 个直播间 · "
                f"检查 {checked} 个 · 无红包")

        self._fire_status()
        self._fire_stats()

    def _filter_packets(self, packets):
        now = time.time()
        valid = []
        for p in packets:
            try:
                end_time = int(p.get("end_time", 0) or 0)
                if end_time <= now + 15:
                    continue
                total_price = int(p.get("total_price", 0) or 0)
                if total_price <= 0:
                    continue
                valid.append(p)
            except Exception:
                continue
        return valid

    async def _get_packets(self, session, room_id):
        try:
            url = f"{LOTTERY_INFO_API}?roomid={room_id}"
            async with session.get(
                url, headers=dict(account.HEADERS),
                cookies=account.get_cookie_dict()
            ) as resp:
                data = await resp.json(content_type=None)
            if not data or data.get("code") != 0:
                return None
            return (data.get("data") or {}).get("popularity_red_pocket")
        except Exception:
            return None

    # ---------- 关注 ----------
    async def _follow_anchor(self, session, anchor_uid, room_id):
        if not anchor_uid:
            return False, "无主播 UID"

        now = time.time()
        with self._follow_lock:
            last = self._followed_anchors.get(anchor_uid, 0)
            if now - last < CONFIG["follow_interval"]:
                return True, "已关注（缓存）"

        csrf = account.CSRF
        if not csrf:
            return False, "无 CSRF"

        try:
            data = {"fid": str(anchor_uid), "act": "1",
                    "re_src": "11", "csrf": csrf}
            headers = {
                "User-Agent": account.HEADERS.get("User-Agent", "Mozilla/5.0"),
                "Referer": f"https://live.bilibili.com/{room_id}",
                "Origin": "https://live.bilibili.com",
                "Content-Type": "application/x-www-form-urlencoded",
            }
            async with session.post(
                RELATION_MODIFY_API, data=data, headers=headers,
                cookies=account.get_cookie_dict()
            ) as resp:
                result = await resp.json(content_type=None)

            if not result:
                return False, "无响应"
            code = result.get("code")
            if code == 0:
                with self._follow_lock:
                    self._followed_anchors[anchor_uid] = now
                return True, "关注成功"
            if code == 22001:
                with self._follow_lock:
                    self._followed_anchors[anchor_uid] = now
                return True, "已关注"
            if code == 22014:
                return False, "关注数已达上限"
            return False, f"[{code}] {result.get('message', '')}"
        except Exception as e:
            return False, str(e)

    # ---------- 发红包弹幕 ----------
    async def _send_red_pocket_danmu(self, session, room_id, msg, lot_id):
        if not msg:
            return True, "无需发送"
        if lot_id in self._sent_red_pocket_danmu:
            return True, "弹幕已发送"

        csrf = account.CSRF
        if not csrf:
            return False, "无 CSRF"

        try:
            rnd = int(time.time())
            data = {
                "color": "16777215", "fontsize": "25", "mode": "1",
                "msg": msg, "rnd": str(rnd), "roomid": str(room_id),
                "bubble": "0", "csrf": csrf, "csrf_token": csrf,
            }
            headers = {
                "User-Agent": account.HEADERS.get("User-Agent", "Mozilla/5.0"),
                "Referer": f"https://live.bilibili.com/{room_id}",
                "Origin": "https://live.bilibili.com",
                "Content-Type": "application/x-www-form-urlencoded",
            }
            async with session.post(
                DM_SEND_API, data=data, headers=headers,
                cookies=account.get_cookie_dict()
            ) as resp:
                result = await resp.json(content_type=None)

            if not result:
                return False, "无响应"
            code = result.get("code")
            if code == 0:
                self._sent_red_pocket_danmu[lot_id] = time.time()
                return True, "弹幕已发送"
            if code in (10030, 10031):
                return False, f"弹幕发送受限 [{code}]"
            if code == 1003212:
                return True, "弹幕已发送（重复）"
            return False, f"[{code}] {result.get('message', '')}"
        except Exception as e:
            return False, str(e)

    # ---------- 抢红包 worker ----------
    async def _grab_worker(self, session, room_id, uid):
        ws_task = asyncio.create_task(
            self._ws_listen_for_win(session, room_id, uid))

        try:
            if room_id not in self.joined_packets:
                self.joined_packets[room_id] = set()
            joined = self.joined_packets[room_id]

            start = time.time()
            max_listen = CONFIG["max_listen_seconds"]

            while not self._stop_event.is_set():
                if time.time() - start > max_listen:
                    break

                packets = await self._get_packets(session, room_id)
                if not packets:
                    break

                valid = self._filter_packets(packets)
                for p in valid:
                    if self._stop_event.is_set():
                        return
                    lot_id = p.get("lot_id")
                    if not lot_id or lot_id in joined:
                        continue

                    user_status = int(p.get("user_status", 2) or 2)
                    if user_status == 1:
                        joined.add(lot_id)
                        continue

                    join_req = int(p.get("join_requirement", 0) or 0)
                    danmu = p.get("danmu", "") or ""
                    sender_uid = int(p.get("sender_uid", 0) or 0)
                    price = int(p.get("total_price", 0) or 0) / 100

                    if join_req == 1:
                        anchor_uid = sender_uid or uid
                        ok, msg = await self._follow_anchor(
                            session, anchor_uid, room_id)
                        if not ok:
                            self._fire_log(
                                "ERR",
                                f"房间 {room_id} 红包 {lot_id} "
                                f"关注失败: {msg}")
                            joined.add(lot_id)
                            continue
                        self._fire_log(
                            "OK",
                            f"房间 {room_id} 红包 {lot_id} · {msg}")

                    if danmu:
                        ok, msg = await self._send_red_pocket_danmu(
                            session, room_id, danmu, lot_id)
                        if not ok:
                            self._fire_log(
                                "ERR",
                                f"房间 {room_id} 红包 {lot_id} "
                                f"弹幕发送失败: {msg}")
                            joined.add(lot_id)
                            continue
                        await asyncio.sleep(
                            CONFIG["danmu_wait_seconds"])
                        self._fire_log(
                            "OK",
                            f"房间 {room_id} 红包 {lot_id} · {msg}")

                    ok, msg = await self._join_packet(
                        session, room_id, uid, lot_id)
                    joined.add(lot_id)

                    if ok:
                        self.stats["joined"] += 1
                        self._fire_log(
                            "OK",
                            f"房间 {room_id} 红包 {lot_id} "
                            f"({price}元) · {msg}")
                    else:
                        self._fire_log(
                            "ERR",
                            f"房间 {room_id} 红包 {lot_id} "
                            f"({price}元) · {msg}")
                    self._fire_stats()

                for _ in range(8):
                    if self._stop_event.is_set():
                        return
                    await asyncio.sleep(1)
        except Exception as e:
            log_err(f"抢红包任务异常 (房间 {room_id}): {e}")
        finally:
            try:
                await asyncio.wait_for(ws_task, timeout=30)
            except asyncio.TimeoutError:
                ws_task.cancel()
                try:
                    await ws_task
                except (Exception, asyncio.CancelledError):
                    pass
            except (Exception, asyncio.CancelledError):
                pass

            self.running_rooms.pop(room_id, None)
            self._fire_status()
            self._fire_stats()

    async def _join_packet(self, session, room_id, uid, lot_id):
        try:
            csrf = account.CSRF
            if not csrf:
                return False, "无 CSRF"

            data = {
                "lot_id": str(lot_id),
                "csrf_token": csrf,
                "csrf": csrf,
                "statistics": ("{'appId':1,'platform':3,"
                               "'version':'7.68.0','abtest':''}"),
                "version": "7.68.0",
                "platform": "android",
                "mobi_app": "android",
                "device": "android",
                "channel": "oppo",
                "c_locale": "zh_CN",
                "build": "7680300",
                "spm_id": "444.8.red_envelope.extract",
                "ruid": str(uid),
                "room_id": str(room_id),
                "session_id": "",
                "jump_from": "26000",
                "visit_id": "",
            }

            headers = {
                "User-Agent": ("Mozilla/5.0 BiliDroid/7.68.0 "
                               "(bbcallen@gmail.com) os/android "
                               "model/LE2100 mobi_app/android "
                               "build/7680300 channel/oppo "
                               "innerVer/7680310 osVer/14 network/2"),
                "Accept": "*/*",
                "Accept-Language": "zh-CN,zh;q=0.9",
                "Origin": "https://live.bilibili.com",
                "Referer": f"https://live.bilibili.com/{room_id}",
            }

            form = aiohttp.FormData()
            for k, v in data.items():
                form.add_field(k, v)

            async with session.post(
                RED_POCKET_DRAW_API, data=form, headers=headers,
                cookies=account.get_cookie_dict()
            ) as resp:
                result = await resp.json(content_type=None)

            if not result:
                return False, "无响应"

            code = result.get("code")
            message = result.get("message", "")

            if code == 0:
                d = result.get("data") or {}
                if d.get("join_status") == 1:
                    return True, "成功参与"
                return True, "已参与"
            if code == 1009114:
                return True, "已参与"
            if code == 1009109:
                return False, "红包已抢完"
            if code == 1009106:
                return False, "需重试"
            if code == 1009107:
                return False, "未关注主播"
            if code == 1009108:
                return False, "未发送弹幕"
            return False, f"[{code}] {message}"
        except Exception as e:
            return False, str(e)

    # ---------- WS 监听 ----------
    async def _ws_listen_for_win(self, session, room_id, my_uid):
        if not build_packet or not parse_packets:
            return

        try:
            info = await self._get_danmu_info(session, room_id)
            if not info:
                return
            token = info.get("token", "")
            host_list = info.get("host_list", [])
            if not token or not host_list:
                return

            for host in host_list:
                if self._stop_event.is_set():
                    return
                try:
                    ok = await self._ws_connect_and_listen(
                        session, host, room_id, my_uid, token)
                    if ok:
                        return
                except Exception:
                    continue
        except Exception as e:
            log_err(f"WS 监听异常 (房间 {room_id}): {e}")

    async def _get_danmu_info(self, session, room_id):
        try:
            headers = dict(account.HEADERS)
            params = {"id": room_id, "type": 0, "web_location": "444.8"}
            async with session.get(
                DANMU_INFO_API, params=params, headers=headers,
                cookies=account.get_cookie_dict()
            ) as resp:
                data = await resp.json(content_type=None)
            if not data or data.get("code") != 0:
                return None
            return data.get("data") or {}
        except Exception:
            return None

    async def _ws_connect_and_listen(self, session, host, room_id,
                                       my_uid, token):
        host_name = host.get("host", "")
        wss_port = host.get("wss_port", 0)
        if not host_name or not wss_port:
            return False

        url = f"wss://{host_name}:{wss_port}/sub"
        headers = {
            "User-Agent": account.HEADERS.get("User-Agent", "Mozilla/5.0"),
            "Origin": "https://live.bilibili.com",
            "Cookie": getattr(account, "cookie_str", "") or "",
        }

        try:
            ws = await session.ws_connect(
                url, headers=headers,
                heartbeat=None, autoping=False,
                max_msg_size=10 * 1024 * 1024,
                timeout=aiohttp.ClientWSTimeout(ws_close=10.0))
        except Exception:
            return False

        try:
            auth = {
                "uid": int(getattr(account, "UID", 0) or 0),
                "roomid": int(room_id),
                "protover": 3,
                "platform": "web",
                "type": 2,
                "key": token,
                "buvid": getattr(account, "BUVID3", "") or "",
                "support_ack": True,
                "queue_uuid": hashlib.md5(
                    str(time.time()).encode()).hexdigest()[:8],
                "scene": "",
            }
            await ws.send_bytes(build_packet(7, json.dumps(auth), 3))

            try:
                resp = await asyncio.wait_for(ws.receive(), timeout=8)
            except asyncio.TimeoutError:
                return False

            if resp.type != aiohttp.WSMsgType.BINARY:
                return False

            authed = False
            for pkt in parse_packets(resp.data):
                if pkt["op"] == 8:
                    try:
                        reply = json.loads(pkt["body"].decode("utf-8"))
                        if reply.get("code") == 0:
                            authed = True
                    except Exception:
                        pass
                    break

            if not authed:
                return False

            hb_task = asyncio.create_task(self._ws_heartbeat(ws))

            start = time.time()
            max_listen = CONFIG["max_listen_seconds"]

            try:
                while not self._stop_event.is_set():
                    if time.time() - start > max_listen:
                        return False
                    try:
                        msg = await asyncio.wait_for(
                            ws.receive(), timeout=30)
                    except asyncio.TimeoutError:
                        continue
                    except (Exception, asyncio.CancelledError):
                        return False

                    if msg.type != aiohttp.WSMsgType.BINARY:
                        if msg.type in (aiohttp.WSMsgType.CLOSE,
                                         aiohttp.WSMsgType.CLOSED,
                                         aiohttp.WSMsgType.ERROR):
                            return False
                        continue

                    try:
                        packets = parse_packets(msg.data)
                    except Exception:
                        continue

                    for pkt in packets:
                        if pkt["op"] != 5:
                            continue
                        try:
                            body_str = pkt["body"].decode(
                                "utf-8", errors="ignore")
                        except Exception:
                            continue

                        for part in split_json_objects(body_str):
                            if not part.strip():
                                continue
                            try:
                                obj = json.loads(part)
                            except Exception:
                                continue
                            cmd = obj.get("cmd", "")

                            if cmd in WINNER_CMDS:
                                if self._handle_winner(
                                        room_id, my_uid, obj):
                                    return True

                            elif cmd == ANCHOR_LOT_START_CMD:
                                await self._handle_anchor_lot_start(
                                    session, room_id, my_uid, obj)

                            elif cmd == ANCHOR_LOT_AWARD_CMD:
                                self._handle_anchor_lot_award(
                                    room_id, my_uid, obj)

            finally:
                hb_task.cancel()
                try:
                    await hb_task
                except (Exception, asyncio.CancelledError):
                    pass
        finally:
            try:
                await ws.close()
            except Exception:
                pass

        return False

    async def _ws_heartbeat(self, ws):
        while True:
            try:
                await asyncio.sleep(25)
                if ws.closed:
                    return
                await ws.send_bytes(build_packet(2, "", 3))
            except asyncio.CancelledError:
                return
            except Exception:
                return

    # ---------- 中奖处理 ----------
    def _handle_winner(self, room_id, my_uid, obj):
        try:
            data = obj.get("data") or {}
            lot_id = int(data.get("lot_id", 0) or 0)
            if not lot_id:
                return False

            if not self.try_mark_rp_lot(lot_id):
                log(f"忽略重复红包开奖 lot_id={lot_id}", "RP",
                    show=False, room_id=room_id)
                return False

            winners = data.get("winner_info", [])
            awards = data.get("awards", {}) or {}
            total_num = data.get("total_num", 0)

            if not isinstance(winners, list):
                return False

            for w in winners:
                if not isinstance(w, (list, tuple)) or len(w) < 2:
                    continue
                try:
                    uid_in_list = int(w[0])
                except Exception:
                    continue

                if uid_in_list != int(my_uid):
                    continue

                award_key = str(w[-1])
                award = awards.get(award_key) or {}
                gift_name = award.get("gift_name", "礼物")
                num = award.get("num", 1)

                self.stats["won"] += 1
                self.stats["gifts"].append({
                    "room_id": room_id,
                    "lot_id": lot_id,
                    "gift_name": gift_name,
                    "num": num,
                    "tag": "红包",
                    "ts": time.time(),
                })
                if len(self.stats["gifts"]) > 100:
                    self.stats["gifts"] = self.stats["gifts"][-100:]

                self._fire_log(
                    "WIN",
                    f"中奖！房间 {room_id} · 红包 {lot_id} · "
                    f"{gift_name} x{num} · 共 {total_num} 人获奖")
                self._fire_stats()
                self.push_rp_event("win_me", {
                    "room_id": room_id,
                    "lot_id": lot_id,
                    "award_name": gift_name,
                    "award_price": 0,
                    "total_num": total_num,
                })
                return True

            self._fire_log(
                "INFO",
                f"房间 {room_id} 红包 {lot_id} 已开奖 · 未中 · "
                f"共 {total_num} 人获奖")
            return False
        except Exception as e:
            log_err(f"解析中奖名单异常: {e}")
            return False

    # ---------- 天选 ----------
    async def _join_anchor_lot(self, session, room_id, lot_id):
        try:
            csrf = account.CSRF
            if not csrf:
                return False, "无 CSRF"
            data = {
                "lot_id": str(lot_id), "csrf": csrf, "csrf_token": csrf,
                "platform": "web", "mobi_app": "web",
                "build": "0", "visit_id": "",
            }
            headers = {
                "User-Agent": account.HEADERS.get(
                    "User-Agent", "Mozilla/5.0"),
                "Accept": "*/*",
                "Accept-Language": "zh-CN,zh;q=0.9",
                "Origin": "https://live.bilibili.com",
                "Referer": f"https://live.bilibili.com/{room_id}",
            }
            form = aiohttp.FormData()
            for k, v in data.items():
                form.add_field(k, v)
            async with session.post(
                ANCHOR_LOT_JOIN_API, data=form, headers=headers,
                cookies=account.get_cookie_dict()
            ) as resp:
                result = await resp.json(content_type=None)
            if not result:
                return False, "无响应"
            code = result.get("code")
            message = result.get("message", "")
            if code == 0:
                return True, "成功参与天选"
            if code in (-403, 1009101, 1009102):
                return True, "已参与"
            return False, f"[{code}] {message}"
        except Exception as e:
            return False, str(e)

    async def _handle_anchor_lot_start(self, session, room_id,
                                        my_uid, obj):
        if not self.anchor_enabled:
            return
        try:
            data = obj.get("data") or {}
            lot_id = data.get("lot_id", 0)
            if not lot_id:
                return

            if room_id not in self.joined_anchor_lots:
                self.joined_anchor_lots[room_id] = set()
            joined = self.joined_anchor_lots[room_id]

            if lot_id in joined:
                return

            try:
                end_time = int(data.get("end_time", 0) or 0)
                if end_time and end_time <= time.time():
                    return
            except Exception:
                pass

            award_name = data.get("award_name", "礼物")
            award_num = data.get("award_num", 1)
            try:
                award_num = int(award_num)
            except Exception:
                award_num = 1

            joined.add(lot_id)
            ok, msg = await self._join_anchor_lot(
                session, room_id, lot_id)

            if ok:
                self.stats["anchor_joined"] += 1
                self._fire_log(
                    "OK",
                    f"房间 {room_id} 天选 {lot_id} "
                    f"({award_name} x{award_num}) · {msg}")
            else:
                self._fire_log(
                    "ERR",
                    f"房间 {room_id} 天选 {lot_id} "
                    f"({award_name} x{award_num}) · {msg}")
            self._fire_stats()
        except Exception as e:
            log_err(f"处理天选开始异常: {e}")

    def _handle_anchor_lot_award(self, room_id, my_uid, obj):
        try:
            data = obj.get("data") or {}
            lot_id = int(data.get("lot_id", 0) or 0)
            if not lot_id:
                return

            if not self.try_mark_anchor_lot(lot_id):
                log(f"忽略重复天选开奖 lot_id={lot_id}", "RP",
                    show=False, room_id=room_id)
                return

            award_name = data.get("award_name", "礼物")
            winner_list = data.get("winner_list", []) or []
            my_uid = int(my_uid)

            for w in winner_list:
                if not isinstance(w, dict):
                    continue
                try:
                    w_uid = int(w.get("uid", 0))
                except Exception:
                    continue
                if w_uid != my_uid:
                    continue

                try:
                    num = int(w.get("award_num", 1) or 1)
                except Exception:
                    num = 1

                self.stats["anchor_won"] += 1
                self.stats["gifts"].append({
                    "room_id": room_id,
                    "lot_id": lot_id,
                    "gift_name": award_name,
                    "num": num,
                    "tag": "天选",
                    "ts": time.time(),
                })
                if len(self.stats["gifts"]) > 100:
                    self.stats["gifts"] = self.stats["gifts"][-100:]

                self._fire_log(
                    "WIN",
                    f"天选中奖！房间 {room_id} · 天选 {lot_id} · "
                    f"{award_name} x{num}")
                self._fire_stats()
                self.push_rp_event("anchor_win", {
                    "room_id": room_id,
                    "lot_id": lot_id,
                    "award_name": award_name,
                    "num": num,
                })
                return
        except Exception as e:
            log_err(f"解析天选中奖名单异常: {e}")


red_packet_manager = RedPacketManager()