#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# live.py
import asyncio
import base64 as _b64
import hashlib
import json
import random
import re
import struct as _struct
import time

import aiohttp
from aiohttp import ClientWSTimeout

import account
from wbi import wbi_signer
from pb import (build_packet, parse_packets, extract_rank_items_from_json,
                _safe_int, split_json_objects, tree_to_json, decode_pb_safe)
from message import (
    handle_message, parse_one, _medal_prefix,
    fetch_online_rank, fetch_pk_info, fetch_universal_info,
    fetch_watched_count,
)
from logger import log, log_err, pb_write, ws_write

REALTIME_API = "https://api.live.bilibili.com"
ROOM_INFO_API = f"{REALTIME_API}/room/v1/Room/get_info"
ANCHOR_INFO_API = f"{REALTIME_API}/live_user/v1/UserInfo/get_anchor_in_room"
DANMU_INFO_API = f"{REALTIME_API}/xlive/web-room/v1/index/getDanmuInfo"
HISTORY_DANMU_API = f"{REALTIME_API}/xlive/web-room/v1/dM/gethistory"
SEND_MSG_API = f"{REALTIME_API}/msg/send"
EMOTICON_API = f"{REALTIME_API}/xlive/web-ucenter/v2/emoticon/GetEmoticons"
_EMOTICON_CACHE_TTL = 300

RANK_CACHE_TTL = 180
RANK_PAGE_SIZE = 100

_ACTIVE_REFRESH_RANK_INTERVAL = 30
_ACTIVE_REFRESH_PK_INTERVAL = 10
_ACTIVE_REFRESH_WATCHED_INTERVAL = 60


class PKStatus:
    def __init__(self):
        self.my_name = "我"
        self.my_uid = 0
        self.my_room_id = 0
        self.my_face = ""
        self.my_votes = 0
        self.oppo_name = "对手"
        self.oppo_uid = 0
        self.oppo_room_id = 0
        self.oppo_face = ""
        self.oppo_votes = 0
        self.active = False
        self.last_output = None
        self.members = []
        self.session_id = ""

    def start(self, my_name="", oppo_name="", **kwargs):
        if my_name:
            self.my_name = my_name
        if oppo_name:
            self.oppo_name = oppo_name
        for k in ("my_uid", "my_room_id", "my_face", "my_votes",
                  "oppo_uid", "oppo_room_id", "oppo_face", "oppo_votes"):
            if k in kwargs and kwargs[k] is not None:
                setattr(self, k, kwargs[k])
        self.active = True
        self.last_output = None

    def update_from_dict(self, data):
        if not self.active:
            return
        data = data or {}
        for k in ("my_name", "my_uid", "my_room_id", "my_face",
                  "my_votes", "oppo_name", "oppo_uid", "oppo_room_id",
                  "oppo_face", "oppo_votes"):
            if k in data and data[k] not in (None, "", 0):
                setattr(self, k, data[k])

    def update_members(self, members, session_id="", my_room_id=0):
        self.members = list(members or [])
        if session_id:
            self.session_id = session_id
        if not self.members:
            return
        my_room = my_room_id or self.my_room_id or self.oppo_room_id
        my_m = None
        if my_room:
            for m in self.members:
                if _safe_int(m.get("room_id", 0)) == my_room:
                    my_m = m
                    break
        if my_m is None:
            try:
                my_m = min(self.members,
                           key=lambda x: _safe_int(x.get("position", 999)))
            except Exception:
                my_m = self.members[0]
        if my_m:
            self.my_name = my_m.get("uname", self.my_name) or self.my_name
            self.my_uid = _safe_int(my_m.get("uid", self.my_uid))
            self.my_room_id = _safe_int(my_m.get("room_id", self.my_room_id))
            self.my_face = my_m.get("face", self.my_face) or self.my_face
            self.my_votes = _safe_int(my_m.get("votes", self.my_votes))
        oppo = None
        for m in self.members:
            if m is my_m:
                continue
            if oppo is None or \
                    _safe_int(m.get("votes", 0)) > _safe_int(oppo.get("votes", 0)):
                oppo = m
        if oppo:
            self.oppo_name = oppo.get("uname", self.oppo_name) or self.oppo_name
            self.oppo_uid = _safe_int(oppo.get("uid", self.oppo_uid))
            self.oppo_room_id = _safe_int(oppo.get("room_id", self.oppo_room_id))
            self.oppo_face = oppo.get("face", self.oppo_face) or self.oppo_face
            self.oppo_votes = _safe_int(oppo.get("votes", self.oppo_votes))

    def end(self):
        self.active = False
        self.my_votes = 0
        self.oppo_votes = 0
        self.members = []
        self.session_id = ""
        self.last_output = None

    def to_dict(self):
        return {
            "active": self.active,
            "my_name": self.my_name, "my_uid": self.my_uid,
            "my_room_id": self.my_room_id, "my_face": self.my_face,
            "my_votes": self.my_votes,
            "oppo_name": self.oppo_name, "oppo_uid": self.oppo_uid,
            "oppo_room_id": self.oppo_room_id, "oppo_face": self.oppo_face,
            "oppo_votes": self.oppo_votes,
            "members": list(self.members), "session_id": self.session_id,
        }

    def should_output(self, key, *args):
        sig = f"{key}_{args}"
        if sig == self.last_output:
            return False
        self.last_output = sig
        return True


class BiliLive:
    def __init__(self, room_id):
        self.room_id = room_id
        self.ws = None
        self.session = None
        self.protover = 3
        self.running = True
        self.shutdown_event = asyncio.Event()
        self.heartbeat_task = None
        self.room_info_task = None
        self.active_pull_task = None
        self.account_task = None
        self.print_fn = None
        self.reconnect_count = 0
        self.danmu_count = 0
        self.gift_count = 0
        self.sc_count = 0
        self.ui = None
        self.anchor_uid = 0
        self.last_rank_sig = None
        self.loop = None
        self.relogin_event = asyncio.Event()
        self.packet_count = 0
        self.byte_count = 0
        self.ws_seq = 0
        self.session_id = 0
        self.rank_cache = {}
        self.pk = PKStatus()
        self.pk_last_action = None
        self.pk_last_data = None
        self.real_room_id = 0
        self._last_live_status = 0
        self._emoticon_cache = []
        self._emoticon_cache_time = 0.0

    def set_ui(self, ui):
        self.ui = ui

    def set_print_fn(self, fn):
        self.print_fn = fn

    def request_relogin(self):
        try:
            self.relogin_event.set()
            if self.ws and self.loop:
                asyncio.run_coroutine_threadsafe(self.ws.close(), self.loop)
        except Exception:
            pass

    def get_real_room_id(self):
        return self.real_room_id or self.room_id

    def is_live(self):
        return self._last_live_status == 1

    def pk_callback(self, action, data):
        self.pk_last_action = action
        self.pk_last_data = data
        data = data or {}
        members = data.get("members")
        session_id = data.get("session_id", "")
        if members:
            my_rid = self.real_room_id or self.room_id
            self.pk.update_members(members, session_id, my_rid)
        if action == "pre":
            oppo_name = data.get("oppo_name", "")
            self.pk.start(oppo_name=oppo_name or "对手",
                          oppo_uid=data.get("oppo_uid", 0),
                          oppo_room_id=data.get("oppo_room_id", 0),
                          oppo_face=data.get("oppo_face", ""))
            self._push_pk_ui()
            if self.print_fn and self.pk.should_output("pre", oppo_name):
                asyncio.create_task(
                    self.print_fn(f"[PK准备] 对手: {oppo_name}", "red"))
        elif action == "start":
            if not self.pk.active:
                self.pk.start(
                    my_name=data.get("my_name", ""),
                    oppo_name=data.get("oppo_name", ""),
                    my_uid=data.get("my_uid", 0),
                    my_room_id=data.get("my_room_id", 0),
                    my_face=data.get("my_face", ""),
                    my_votes=data.get("my_votes", 0),
                    oppo_uid=data.get("oppo_uid", 0),
                    oppo_room_id=data.get("oppo_room_id", 0),
                    oppo_face=data.get("oppo_face", ""),
                    oppo_votes=data.get("oppo_votes", 0))
            else:
                self.pk.update_from_dict(data)
            self._push_pk_ui()
            if self.print_fn and self.pk.should_output("start"):
                asyncio.create_task(self.print_fn(
                    f"[PK开始] {self.pk.my_name} VS {self.pk.oppo_name}", "red"))
        elif action == "update":
            if not self.pk.active:
                self.pk.start(
                    my_name=data.get("my_name", ""),
                    oppo_name=data.get("oppo_name", ""),
                    my_uid=data.get("my_uid", 0),
                    my_room_id=data.get("my_room_id", 0),
                    my_face=data.get("my_face", ""),
                    oppo_uid=data.get("oppo_uid", 0),
                    oppo_room_id=data.get("oppo_room_id", 0),
                    oppo_face=data.get("oppo_face", ""))
            self.pk.update_from_dict(data)
            self._push_pk_ui()
            if self.print_fn and self.pk.should_output(
                    "update", self.pk.my_votes, self.pk.oppo_votes):
                asyncio.create_task(self.print_fn(
                    f"[PK] {self.pk.my_name} ({self.pk.my_votes}) VS "
                    f"{self.pk.oppo_name} ({self.pk.oppo_votes})", "red"))
        elif action == "end":
            self.pk.end()
            self._push_pk_ui()
            if self.print_fn and self.pk.should_output("end"):
                asyncio.create_task(self.print_fn("[PK已结束]", "red"))

    def _push_pk_ui(self):
        if not self.ui:
            return
        try:
            self.ui.update_pk(self.room_id, self.pk.to_dict())
        except Exception:
            pass

    def replay_pk(self):
        if not self.pk_last_action:
            log("无可重放的 PK 数据", "PK", room_id=self.room_id)
            return
        try:
            log(f"重放 PK (action={self.pk_last_action})", "PK",
                room_id=self.room_id)
            self.pk_callback(self.pk_last_action, self.pk_last_data)
        except Exception as e:
            log_err(f"重放 PK 异常: {e}", room_id=self.room_id)

    def _ws_next_seq(self):
        self.ws_seq += 1
        return self.ws_seq

    def _decode_body(self, body, op):
        result = {
            "body_raw": _b64.b64encode(body).decode("ascii") if body else "",
            "body_len": len(body),
        }
        if not body:
            result["body_type"] = "empty"
            result["body"] = None
            return result
        if op == 3 and len(body) >= 4:
            result["body_type"] = "int"
            result["body"] = _struct.unpack_from(">I", body, 0)[0]
            return result
        try:
            text = body.decode("utf-8")
        except Exception:
            result["body_type"] = "binary"
            result["body"] = None
            return result
        stripped = text.strip()
        try:
            result["body_type"] = "json"
            result["body"] = json.loads(stripped)
            return result
        except Exception:
            pass
        try:
            objs = split_json_objects(text)
            if objs:
                parsed = []
                for o in objs:
                    try:
                        parsed.append(json.loads(o))
                    except Exception:
                        parsed.append(o)
                if len(parsed) == 1:
                    result["body_type"] = "json"
                    result["body"] = parsed[0]
                else:
                    result["body_type"] = "json-multi"
                    result["body"] = parsed
                return result
        except Exception:
            pass
        result["body_type"] = "text"
        result["body"] = text
        return result

    def _parsed_lines(self, body_value):
        objs = body_value if isinstance(body_value, list) else [body_value]
        lines = []
        for obj in objs:
            if not isinstance(obj, dict):
                continue
            try:
                r = parse_one(obj, silent=True, room_id=self.room_id,
                              pk_callback=None)
            except Exception:
                continue
            out = r.get("output") or ""
            if out:
                lines.append(out)
        return lines

    def _ws_make_records(self, direction, data, base_tag, note=""):
        records = []
        try:
            packets = parse_packets(data)
        except Exception:
            packets = []
        for pkt in packets:
            pb_write({
                "dir": direction, "tag": base_tag, "op": pkt["op"],
                "protover": pkt["proto_ver"],
                "header_len": pkt.get("header_len", 0),
                "total_len": pkt.get("total_len", 0),
                "body_len": len(pkt["body"]),
                "body_base64": (_b64.b64encode(pkt["body"]).decode("ascii")
                                if pkt["body"] else ""),
            }, room_id=self.room_id)
            rec = {
                "seq": self._ws_next_seq(), "dir": direction,
                "tag": base_tag, "op": pkt["op"],
                "protover": pkt["proto_ver"],
                "header_len": pkt.get("header_len", 0),
                "total_len": pkt.get("total_len", 0),
            }
            decoded = self._decode_body(pkt["body"], pkt["op"])
            rec.update(decoded)
            if decoded.get("body_type") in ("json", "json-multi") and \
                    decoded.get("body") is not None:
                parsed = self._parsed_lines(decoded["body"])
                if parsed:
                    rec["parsed"] = parsed
            if note:
                rec["note"] = note
            records.append(rec)
        if not records:
            records.append({
                "seq": self._ws_next_seq(), "dir": direction,
                "tag": base_tag, "op": -1, "protover": -1,
                "body_len": len(data),
                "body_raw": (_b64.b64encode(data).decode("ascii")
                             if data else ""),
                "body_type": "unparsed", "body": None,
                "note": (note + " " if note else "") + "parse_failed",
            })
        return records

    def _ws_log_records(self, direction, data, base_tag, note=""):
        for rec in self._ws_make_records(direction, data, base_tag, note):
            ws_write(rec, room_id=self.room_id)

    async def _ws_send(self, data, tag="WS_OUT", note=""):
        if not self.ws:
            raise Exception("ws 未连接")
        self._ws_log_records("out", data, tag, note)
        await self.ws.send_bytes(data)

    def _ws_record_in(self, data, tag="WS_IN", note=""):
        self._ws_log_records("in", data, tag, note)

    @staticmethod
    def _is_empty(v):
        return v in (None, "", "?", 0, "0")

    def _merge_rank_list(self, new_list):
        now = time.time()
        for item in new_list:
            uid = item.get("uid", 0)
            if not uid:
                continue
            old = self.rank_cache.get(uid, {})
            merged = dict(old)
            for k, v in item.items():
                if k in ("score", "_last_seen"):
                    continue
                if self._is_empty(v) and not self._is_empty(old.get(k)):
                    continue
                merged[k] = v
            new_score = item.get("score", 0) or 0
            old_score = old.get("score", 0) or 0
            merged["score"] = max(new_score, old_score)
            merged["uid"] = uid
            merged["_last_seen"] = now
            self.rank_cache[uid] = merged
        expired = [uid for uid, it in self.rank_cache.items()
                   if now - it.get("_last_seen", now) > RANK_CACHE_TTL]
        for uid in expired:
            self.rank_cache.pop(uid, None)
        merged_list = sorted(self.rank_cache.values(),
                             key=lambda x: x.get("score", 0),
                             reverse=True)
        return [{k: v for k, v in item.items() if k != "_last_seen"}
                for item in merged_list]

    def status_callback(self, key, value):
        if not self.ui:
            return
        if key == "danmu_add":
            self.danmu_count += value
            self.ui.update_status(self.room_id, "弹幕", self.danmu_count)
        elif key == "gift_add":
            self.gift_count += value
            self.ui.update_status(self.room_id, "礼物", self.gift_count)
        elif key == "sc_add":
            self.sc_count += value
            self.ui.update_status(self.room_id, "SC", self.sc_count)
        elif key == "rank_list":
            merged = self._merge_rank_list(value)
            sig = tuple((r.get("uid"), r.get("score")) for r in merged)
            self.ui.update_status(self.room_id, "在线", len(merged))
            if sig != self.last_rank_sig:
                self.last_rank_sig = sig
                self.ui.update_rank_list(self.room_id, merged)
        else:
            self.ui.update_status(self.room_id, key, value)

    async def init_session(self):
        if self.session is None:
            self.session = aiohttp.ClientSession()

    async def update_account_loop(self):
        last_state = None
        while not self.shutdown_event.is_set():
            try:
                from auth import fetch_account_info
                info = await fetch_account_info()
                if self.ui:
                    self.ui.update_account(info)
                state = (info.get("is_login"), info.get("uname", ""))
                if state != last_state:
                    last_state = state
                    if info.get("is_login"):
                        log(f"当前账号: {info.get('uname')} "
                            f"(UID={info.get('mid')}, Lv{info.get('level')})",
                            "ACCT")
                        data = account.load_accounts()
                        mid = str(info.get("mid"))
                        if mid not in data["accounts"]:
                            account.add_or_update_account(
                                account.get_cookie_dict(), info)
                    else:
                        log("当前未登录", "ACCT")
            except Exception as e:
                log(f"账号刷新失败: {e}", "WARN", show=False)
            try:
                await asyncio.wait_for(self.shutdown_event.wait(), timeout=300)
                break
            except asyncio.TimeoutError:
                pass

    async def fetch_room_info(self):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(f"{ROOM_INFO_API}?room_id={self.room_id}",
                                 headers=account.HEADERS, timeout=10) as resp:
                    data = await resp.json()
                    if data.get("code") == 0:
                        return data.get("data", {})
        except Exception:
            pass
        return {}

    async def fetch_anchor_info(self):
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(f"{ANCHOR_INFO_API}?roomid={self.room_id}",
                                 headers=account.HEADERS, timeout=10) as resp:
                    data = await resp.json()
                    if data.get("code") == 0:
                        return data.get("data", {})
        except Exception:
            pass
        return {}

    async def update_room_info_loop(self):
        last_anchor = 0
        last_ls = -1
        last_pop = -1
        last_fans = -1
        last_title = ""
        last_watched_pull = 0.0
        while not self.shutdown_event.is_set():
            try:
                info = await self.fetch_room_info()
                if info:
                    rid_real = _safe_int(info.get("room_id", 0))
                    if rid_real and rid_real != self.real_room_id:
                        self.real_room_id = rid_real
                        log(f"真实房间号: {rid_real} (短号 {self.room_id})",
                            "ROOM", room_id=self.room_id)
                    ls = info.get("live_status", 0)
                    self._last_live_status = ls
                    st = {0: "未开播", 1: "直播中", 2: "轮播"}.get(ls, "未知")
                    if ls != last_ls:
                        log(f"直播状态变更: {st}", "ROOM", room_id=self.room_id)
                        last_ls = ls
                    self.status_callback("直播", st)
                    pop = info.get("online", 0)
                    title = info.get("title", "")
                    fans = info.get("attention", 0)
                    if pop > 0:
                        self.status_callback("人气", pop)
                        if abs(pop - last_pop) >= max(1, last_pop // 10):
                            log(f"人气更新: {pop}", "ROOM",
                                show=False, room_id=self.room_id)
                            last_pop = pop
                    if title and self.ui:
                        self.ui.update_title(self.room_id, title)
                        if title != last_title:
                            log(f"标题: {title}", "ROOM",
                                room_id=self.room_id)
                            last_title = title
                    if fans:
                        self.status_callback("粉丝", fans)
                        if last_fans != fans:
                            log(f"粉丝: {fans}", "ROOM",
                                show=False, room_id=self.room_id)
                            last_fans = fans
                now = time.time()
                if now - last_watched_pull >= _ACTIVE_REFRESH_WATCHED_INTERVAL:
                    last_watched_pull = now
                    try:
                        rrid = self.real_room_id or self.room_id
                        num, text = await fetch_watched_count(
                            rrid, cookie_str=self._get_cookie_str())
                        if num or text:
                            self.status_callback("watched", num)
                            log(f"看过人数: {text or num}", "WATCHED",
                                show=False, room_id=self.room_id)
                    except Exception as e:
                        log(f"拉取看过人数失败: {e}", "WATCHED",
                            show=False, room_id=self.room_id)
                if time.time() - last_anchor > 120 or not self.anchor_uid:
                    ai = await self.fetch_anchor_info()
                    if ai:
                        u = ai.get("info", {}) or {}
                        uname = u.get("uname", "")
                        face = u.get("face", "")
                        auid = _safe_int(u.get("uid", 0))
                        if auid and auid != self.anchor_uid:
                            self.anchor_uid = auid
                            log(f"主播: {uname} (UID={auid})", "ROOM",
                                room_id=self.room_id)
                        if self.ui and uname:
                            self.ui.update_anchor(self.room_id, uname, face,
                                                    auid)
                    last_anchor = time.time()
            except Exception as e:
                log(f"房间信息刷新异常: {e}", "WARN",
                    show=False, room_id=self.room_id)
            await asyncio.sleep(20)

    @staticmethod
    def _get_cookie_str():
        try:
            return getattr(account, "cookie_str", "") or ""
        except Exception:
            return ""

    async def _http_refresh_rank(self):
        if not self.anchor_uid:
            return False
        room_id = self.real_room_id or self.room_id
        cookie_str = self._get_cookie_str()
        try:
            items, total, _tips = await fetch_online_rank(
                room_id=room_id, ruid=self.anchor_uid,
                page=1, page_size=RANK_PAGE_SIZE, cookie_str=cookie_str)
            if items:
                self.status_callback("rank_list", items)
                if total:
                    self.status_callback("rank", total)
                return True
        except Exception as e:
            log(f"高能榜主动刷新异常: {e}", "RANK",
                show=False, room_id=self.room_id)
        return False

    async def _refresh_pk(self):
        room_id = self.real_room_id or self.room_id
        try:
            pk = await fetch_pk_info(
                room_id=room_id, cookie_str=self._get_cookie_str())
            if pk:
                self.pk_callback("update", pk)
                return
            if self.anchor_uid:
                uni = await fetch_universal_info(
                    room_id=room_id, anchor_uid=self.anchor_uid,
                    cookie_str=self._get_cookie_str())
                if uni:
                    self.pk_callback("update", uni)
        except Exception as e:
            log(f"PK 主动刷新异常: {e}", "PK",
                show=False, room_id=self.room_id)

    async def _refresh_all(self):
        await self._http_refresh_rank()
        await self._refresh_pk()
        log("初始数据刷新完成", "MAIN", room_id=self.room_id)

    async def update_active_pull_loop(self):
        for _ in range(60):
            if self.anchor_uid or self.shutdown_event.is_set():
                break
            await asyncio.sleep(0.5)
        if self.shutdown_event.is_set():
            return
        await self._refresh_all()
        last_rank_time = time.time()
        last_pk_time = time.time()
        while not self.shutdown_event.is_set():
            try:
                await asyncio.wait_for(self.shutdown_event.wait(), timeout=5)
                break
            except asyncio.TimeoutError:
                pass
            if self.shutdown_event.is_set():
                break
            now = time.time()
            if now - last_rank_time >= _ACTIVE_REFRESH_RANK_INTERVAL:
                await self._http_refresh_rank()
                last_rank_time = now
            if now - last_pk_time >= _ACTIVE_REFRESH_PK_INTERVAL:
                await self._refresh_pk()
                last_pk_time = now

    async def async_get(self, url, params=None, need_wbi=False):
        params = params or {}
        if need_wbi:
            try:
                await wbi_signer.ensure_keys(self.session)
                params = wbi_signer.sign(params)
            except Exception:
                pass
        while self.running and not self.shutdown_event.is_set():
            try:
                async with self.session.get(url, params=params,
                                            headers=account.HEADERS,
                                            timeout=10) as resp:
                    data = await resp.json()
                    if data.get("code") == 0:
                        return data
                    if data.get("code") == -352:
                        try:
                            await wbi_signer.ensure_keys(self.session)
                            params = wbi_signer.sign(params)
                        except Exception:
                            pass
                        continue
                    raise Exception(data.get("message", "接口错误"))
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log(f"请求失败 {url}: {e}", "WARN",
                    show=False, room_id=self.room_id)
                await self._wait_or_stop(3)
        raise asyncio.CancelledError()

    async def async_post(self, url, data=None, need_csrf=False):
        data = data or {}
        h = account.HEADERS.copy()
        h["Content-Type"] = "application/x-www-form-urlencoded"
        if need_csrf:
            if not account.CSRF:
                raise Exception("CSRF未设置")
            data["csrf"] = account.CSRF
            data["csrf_token"] = account.CSRF
        async with self.session.post(url, data=data, headers=h,
                                     timeout=10) as resp:
            res = await resp.json()
            if res.get("code") != 0:
                raise Exception(f"{res.get('message')}")
            return res

    async def async_post_multipart(self, url, fields, need_csrf=False):
        h = account.HEADERS.copy()
        form = aiohttp.FormData()
        for k, v in fields.items():
            form.add_field(k, str(v))
        if need_csrf:
            if not account.CSRF:
                raise Exception("CSRF未设置")
            form.add_field("csrf", account.CSRF)
            form.add_field("csrf_token", account.CSRF)
        async with self.session.post(url, data=form, headers=h,
                                     timeout=10) as resp:
            res = await resp.json()
            if res.get("code") != 0:
                raise Exception(
                    f"{res.get('message')} (code={res.get('code')})")
            return res

    async def get_danmu_info(self):
        data = await self.async_get(
            DANMU_INFO_API,
            {"id": self.room_id, "type": 0, "web_location": "444.8"},
            need_wbi=True)
        info = data["data"]
        hosts = info.get("host_list", []) or []
        log(f"弹幕服务器配置成功，共 {len(hosts)} 个节点", "WS",
            room_id=self.room_id)
        return info

    async def send_danmu(self, msg):
        """发送普通弹幕（可含小表情，如 [dog]）"""
        fields = {
            "roomid": self.room_id,
            "msg": msg,
            "room_type": 0,
            "jumpfrom": 86001,
            "reply_mid": 0,
            "reply_attr": 0,
            "replay_dmid": "",
            "statistics": json.dumps(
                {"appId": 100, "platform": 5},
                separators=(",", ":")),
            "reply_type": 0,
            "reply_uname": "",
            "data_extend": json.dumps(
                {"trackid": "-99998"}, ensure_ascii=False),
            "fontsize": 25,
            "color": 16777215,
            "mode": 1,
            "rnd": int(time.time()),
            "bubble": 0,
        }
        await self.async_post_multipart(
            SEND_MSG_API, fields, need_csrf=True)
        log(f"弹幕已发送: {msg}", "SEND", room_id=self.room_id)

    # ============================================================
    #  表情
    # ============================================================
    @staticmethod
    def _extract_prefix_from_unique(unique):
        """从 upower_[X_yyy] 里提取 X。用最后一个下划线分割。

        返回 X 或 None。
        """
        if not unique or not isinstance(unique, str):
            return None
        if not unique.startswith("upower_["):
            return None
        inner = unique[len("upower_["):]
        if inner.endswith("]"):
            inner = inner[:-1]
        if not inner:
            return None
        pos = inner.rfind("_")
        if pos <= 0:
            return None
        prefix = inner[:pos].strip()
        return prefix or None

    @classmethod
    def _derive_pkg_display(cls, pkg_name, top_left, emoticons, pkg_id):
        """推导分区显示名。

        优先级：
        1. top_show.top_left.text（官方标注）
        2. upower_[X_yyy] 里提取 X（出现 >= 3）
        3. emoji 里提取下划线前缀 X（出现 >= 2）
        4. 取第一个 upower_[X_yyy] 的 X
        5. pkg_name（排除无效值）
        6. 兜底：装扮表情 #pkg_id

        注意：emoticons 里的字段名可能是 "unique"
              （fetch_emoticons 标准化后的），也可能是
              "emoticon_unique"（API 原始）。两种都兼容。
        """
        _INVALID = {"装扮表情", "emoji", "通用表情", ""}

        # 1) 官方标注
        if top_left:
            s = (top_left or "").strip()
            if s and s not in _INVALID:
                return s

        # 2) upower_[X_yyy] 里提取前缀并统计
        prefix_count = {}
        for em in emoticons:
            if not isinstance(em, dict):
                continue
            unique = (em.get("unique")
                       or em.get("emoticon_unique")
                       or "")
            prefix = cls._extract_prefix_from_unique(unique)
            if not prefix or prefix in _INVALID:
                continue
            prefix_count[prefix] = prefix_count.get(prefix, 0) + 1
        if prefix_count:
            best_prefix = max(prefix_count, key=prefix_count.get)
            if prefix_count[best_prefix] >= 3 and \
                    2 <= len(best_prefix) <= 40:
                return best_prefix

        # 3) 从 emoji 里提取下划线前缀
        head_count = {}
        for em in emoticons:
            if not isinstance(em, dict):
                continue
            e = em.get("emoji") or em.get("descript") or ""
            if not isinstance(e, str):
                continue
            e = e.strip().strip("[]").strip()
            if "_" not in e:
                continue
            head = e.split("_", 1)[0].strip()
            if not head or head in _INVALID:
                continue
            if not (2 <= len(head) <= 20):
                continue
            head_count[head] = head_count.get(head, 0) + 1
        if head_count:
            best_head = max(head_count, key=head_count.get)
            if head_count[best_head] >= 2:
                return best_head

        # 4) 取第一个 upower_[X_yyy] 的 X
        for em in emoticons:
            if not isinstance(em, dict):
                continue
            unique = (em.get("unique")
                       or em.get("emoticon_unique")
                       or "")
            prefix = cls._extract_prefix_from_unique(unique)
            if prefix and prefix not in _INVALID and len(prefix) >= 2:
                return prefix

        # 5) pkg_name
        if pkg_name:
            s = pkg_name.strip()
            if s and s not in _INVALID:
                return s

        # 6) 兜底
        return f"装扮表情 {pkg_id}"

    async def fetch_emoticons(self, force=False):
        now = time.time()
        if not force and self._emoticon_cache and \
                now - self._emoticon_cache_time < _EMOTICON_CACHE_TTL:
            return self._emoticon_cache
        rid = self.real_room_id or self.room_id
        try:
            data = await self.async_get(
                EMOTICON_API,
                {"platform": "pc", "room_id": rid},
                need_wbi=False)
        except Exception as e:
            log(f"获取表情列表失败: {e}", "EMOTE",
                show=False, room_id=self.room_id)
            return self._emoticon_cache or []

        raw = data.get("data") or {}
        packages = raw.get("data") or []
        if not isinstance(packages, list):
            packages = []

        norm_pkgs = []
        used_names = {}
        for pkg in packages:
            if not isinstance(pkg, dict):
                continue
            pkg_id = _safe_int(pkg.get("pkg_id", 0))
            pkg_name = pkg.get("pkg_name", "") or ""
            pkg_type = _safe_int(pkg.get("pkg_type", 0))
            pkg_descript = pkg.get("pkg_descript", "") or ""
            cover = pkg.get("current_cover", "") or ""

            top_show = pkg.get("top_show") or {}
            top_left = ((top_show.get("top_left") or {}).get("text") or "").strip()

            raw_ems = pkg.get("emoticons") or []
            if not isinstance(raw_ems, list):
                raw_ems = []

            # 标准化字段：emoticon_unique → unique
            norm_ems = []
            for em in raw_ems:
                if not isinstance(em, dict):
                    continue
                norm_ems.append({
                    "emoji": (em.get("emoji") or em.get("descript") or ""),
                    "descript": em.get("descript", "") or "",
                    "unique": em.get("emoticon_unique") or "",
                    "url": em.get("url") or "",
                    "width": _safe_int(em.get("width", 40)) or 40,
                    "height": _safe_int(em.get("height", 40)) or 40,
                    "perm": em.get("perm"),
                    "emoticon_id": _safe_int(em.get("emoticon_id", 0)),
                    "is_dynamic": _safe_int(em.get("is_dynamic", 0)),
                    "bulge_display": _safe_int(em.get("bulge_display", 0)),
                    "in_player_area": _safe_int(em.get("in_player_area", 0)),
                    "emoticon_value_type": _safe_int(
                        em.get("emoticon_value_type", 0)),
                    "pkg_id": pkg_id,
                    "pkg_name": pkg_name,
                })
            if not norm_ems:
                continue

            display_name = self._derive_pkg_display(
                pkg_name, top_left, norm_ems, pkg_id)
            if display_name in used_names:
                display_name = f"{display_name} #{pkg_id}"
            used_names[display_name] = True

            norm_pkgs.append({
                "pkg_id": pkg_id,
                "pkg_name": pkg_name,
                "display_name": display_name,
                "pkg_type": pkg_type,
                "pkg_descript": pkg_descript,
                "cover": cover,
                "emoticons": norm_ems,
            })

        self._emoticon_cache = norm_pkgs
        self._emoticon_cache_time = now
        total = sum(len(p["emoticons"]) for p in norm_pkgs)
        log(f"获取表情列表成功: {len(norm_pkgs)} 个分区 / {total} 个表情",
            "EMOTE", show=False, room_id=self.room_id)
        # 调试日志：打印每个分区的显示名
        for p in norm_pkgs:
            log(f"  分区 {p['pkg_id']:>6} → {p['display_name']} "
                f"({len(p['emoticons'])} 个)", "EMOTE",
                show=False, room_id=self.room_id)
        return norm_pkgs

    def find_emoticon(self, key):
        for pkg in (self._emoticon_cache or []):
            for em in pkg.get("emoticons", []):
                if em.get("emoji") == key or em.get("unique") == key:
                    return em
        return None

    async def send_emoticon(self, key, options_override=None):
        await self.fetch_emoticons()
        target = self.find_emoticon(key)
        if not target:
            await self.fetch_emoticons(force=True)
            target = self.find_emoticon(key)
        if not target:
            raise Exception(f"未找到表情: {key}")

        unique = target.get("unique") or key
        url = target.get("url", "")
        if url.startswith("http://"):
            url = "https://" + url[7:]

        # 大表情：upower_ / room_ 前缀 → dm_type=1
        is_large = (unique.startswith("upower_")
                    or unique.startswith("room_"))

        if is_large:
            msg_text = unique
            fields = {
                "roomid": self.room_id,
                "msg": msg_text,
                "dm_type": 1,
                "emoticonOptions": json.dumps({
                    "bulge_display": target.get("bulge_display", 1) or 1,
                    "emoticon_unique": unique,
                    "height": _safe_int(target.get("height", 40)) or 40,
                    "width": _safe_int(target.get("width", 40)) or 40,
                    "in_player_area": target.get("in_player_area", 1) or 1,
                    "url": url,
                }, ensure_ascii=False),
                "data_extend": json.dumps({"trackid": "-99998"},
                                           ensure_ascii=False),
                "rnd": int(time.time()),
                "fontsize": 25,
                "color": 16777215,
                "mode": 1,
                "bubble": 0,
            }
            if options_override:
                try:
                    opts = json.loads(fields["emoticonOptions"])
                    opts.update(options_override)
                    fields["emoticonOptions"] = json.dumps(
                        opts, ensure_ascii=False)
                except Exception:
                    pass
        else:
            msg_text = target.get("emoji") or unique
            fields = {
                "roomid": self.room_id,
                "msg": msg_text,
                "room_type": 0,
                "jumpfrom": 86001,
                "reply_mid": 0,
                "reply_attr": 0,
                "replay_dmid": "",
                "statistics": json.dumps(
                    {"appId": 100, "platform": 5},
                    separators=(",", ":")),
                "reply_type": 0,
                "reply_uname": "",
                "data_extend": json.dumps({"trackid": "-99998"},
                                           ensure_ascii=False),
                "rnd": int(time.time()),
                "fontsize": 25,
                "color": 16777215,
                "mode": 1,
                "bubble": 0,
            }

        await self.async_post_multipart(
            SEND_MSG_API, fields, need_csrf=True)
        log(f"表情已发送: {msg_text}", "SEND", room_id=self.room_id)
        return target

    def list_emoticons(self):
        return self._emoticon_cache or []

    async def get_history_danmu(self):
        try:
            res = await self.async_get(
                HISTORY_DANMU_API,
                {"roomid": self.room_id, "room_type": 0,
                 "web_location": "444.8"},
                need_wbi=True)
            items = res.get("data", {}).get("room", [])
            log(f"载入历史弹幕 {len(items)} 条", "HIST",
                show=False, room_id=self.room_id)
            for item in items:
                nn = item.get("nickname", "未知")
                text = item.get("text", "")
                mn = ""
                ml = 0
                m = item.get("medal")
                if isinstance(m, list) and len(m) >= 2:
                    try:
                        ml = int(m[0]) if m[0] else 0
                    except Exception:
                        ml = 0
                    if len(m) > 1 and isinstance(m[1], str):
                        mn = m[1]
                prefix = _medal_prefix(mn, ml, 0)
                msg = f"[历史弹幕] {prefix}{nn}: {text}"
                if self.print_fn:
                    await self.print_fn(msg, "dim")
        except Exception as e:
            log(f"历史弹幕获取失败: {e}", "WARN",
                show=False, room_id=self.room_id)

    async def _wait_or_stop(self, seconds):
        try:
            await asyncio.wait_for(self.shutdown_event.wait(), timeout=seconds)
        except asyncio.TimeoutError:
            pass

    async def connect(self, host, port, use_wss, protover, token):
        protocol = "wss" if use_wss else "ws"
        url = f"{protocol}://{host}:{port}/sub"
        try:
            headers = {
                "User-Agent": account.HEADERS["User-Agent"],
                "Origin": "https://live.bilibili.com",
                "Cookie": account.cookie_str,
            }
            self.ws = await self.session.ws_connect(
                url, headers=headers, heartbeat=None,
                timeout=ClientWSTimeout(ws_close=15.0),
                autoclose=True, autoping=False,
                max_msg_size=10 * 1024 * 1024)
            ws_write({
                "seq": self._ws_next_seq(), "dir": "event",
                "tag": "WS_CONNECTED",
                "note": f"{url} protover={protover} session_id={self.session_id}",
            }, room_id=self.room_id)
            auth = {
                "uid": account.UID, "roomid": self.room_id,
                "protover": protover, "platform": "web",
                "type": 2, "key": token, "buvid": account.BUVID3,
                "support_ack": True,
                "queue_uuid": hashlib.md5(
                    str(time.time()).encode()).hexdigest()[:8],
                "scene": "",
            }
            await self._ws_send(build_packet(7, json.dumps(auth), protover),
                                "WS_OUT_AUTH")
            resp = await asyncio.wait_for(self.ws.receive(), timeout=8)
            if resp.type != aiohttp.WSMsgType.BINARY:
                return False
            self._ws_record_in(resp.data, "WS_IN_AUTH_RESP")
            for pkt in parse_packets(resp.data):
                if pkt["op"] == 8:
                    try:
                        reply = json.loads(pkt["body"].decode("utf-8"))
                        if reply.get("code") == 0:
                            self.protover = protover
                            log(f"认证成功 {host}:{port} "
                                f"protover={protover}", "WS",
                                room_id=self.room_id)
                            return True
                    except Exception:
                        pass
                    break
            await self.ws.close()
            return False
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log(f"连接 {url} 异常: {e}", "WS",
                show=False, room_id=self.room_id)
            return False

    async def main_loop(self):
        self.loop = asyncio.get_running_loop()
        log("直播监听启动", "MAIN", room_id=self.room_id)
        while not self.shutdown_event.is_set():
            try:
                info = await self.get_danmu_info()
                token = info["token"]
                host_list = info["host_list"]
            except asyncio.CancelledError:
                break
            except Exception as e:
                log_err(f"获取弹幕服务器失败: {e}", room_id=self.room_id)
                await self._wait_or_stop(random.randint(5, 15))
                continue
            connected = False
            for host in host_list:
                if self.shutdown_event.is_set():
                    break
                for use_wss in [True, False]:
                    if self.shutdown_event.is_set():
                        break
                    port = host["wss_port"] if use_wss else host["ws_port"]
                    if not port:
                        continue
                    for protover in [3, 2]:
                        if self.shutdown_event.is_set():
                            break
                        if await self.connect(host["host"], port, use_wss,
                                                protover, token):
                            connected = True
                            self.reconnect_count = 0
                            self.packet_count = 0
                            self.byte_count = 0
                            self.ws_seq = 0
                            self.session_id += 1
                            log("直播服务器已连接", "WS",
                                room_id=self.room_id)
                            await self.run_connection()
                            break
                    if connected:
                        break
                if connected:
                    break
            if not connected and not self.shutdown_event.is_set():
                self.reconnect_count += 1
                delay = min(60, 5 * (2 ** self.reconnect_count))
                log(f"所有节点均连接失败，{delay}s 后重试 "
                    f"(第 {self.reconnect_count} 次)", "WARN",
                    room_id=self.room_id)
                await self._wait_or_stop(random.randint(delay, delay + 5))

    async def run_connection(self):
        await self.get_history_danmu()
        self.room_info_task = asyncio.create_task(self.update_room_info_loop())
        self.active_pull_task = asyncio.create_task(
            self.update_active_pull_loop())
        self.heartbeat_task = asyncio.create_task(self.heartbeat_loop())
        log("进入连接处理循环", "WS", room_id=self.room_id)
        try:
            while not self.shutdown_event.is_set() and self.ws:
                if self.relogin_event.is_set():
                    self.relogin_event.clear()
                    log("收到重连请求", "WS", room_id=self.room_id)
                    break
                try:
                    msg = await asyncio.wait_for(self.ws.receive(), timeout=60)
                except asyncio.TimeoutError:
                    continue
                except asyncio.CancelledError:
                    self.shutdown_event.set()
                    break
                except Exception as e:
                    log(f"接收异常: {e}", "WARN",
                        show=False, room_id=self.room_id)
                    break
                if msg.type == aiohttp.WSMsgType.BINARY:
                    self.packet_count += 1
                    self.byte_count += len(msg.data)
                    self._ws_record_in(
                        msg.data, "WS_IN",
                        note=f"frames={self.packet_count} "
                             f"total={self.byte_count // 1024}KB")
                    for pkt in parse_packets(msg.data):
                        await self.handle_packet_async(pkt)
                elif msg.type in (aiohttp.WSMsgType.CLOSE,
                                  aiohttp.WSMsgType.CLOSED,
                                  aiohttp.WSMsgType.ERROR):
                    ws_write({
                        "seq": self._ws_next_seq(), "dir": "event",
                        "tag": "WS_CLOSED", "note": f"reason={msg.type}",
                    }, room_id=self.room_id)
                    break
        except Exception as e:
            log_err(f"连接处理异常: {e}", room_id=self.room_id)
        finally:
            for t in (self.room_info_task, self.heartbeat_task,
                      self.active_pull_task):
                if t:
                    t.cancel()
                    try:
                        await t
                    except (Exception, asyncio.CancelledError):
                        pass
            self.room_info_task = None
            self.heartbeat_task = None
            self.active_pull_task = None
            if self.ws:
                try:
                    await asyncio.wait_for(self.ws.close(), timeout=3)
                except Exception:
                    pass

    async def heartbeat_loop(self):
        fail = 0
        while not self.shutdown_event.is_set() and self.ws:
            try:
                await self._ws_send(build_packet(2, "", self.protover),
                                    "WS_OUT_HB")
                fail = 0
            except asyncio.CancelledError:
                break
            except Exception as e:
                fail += 1
                log(f"心跳失败 {fail}/3: {e}", "WARN",
                    show=False, room_id=self.room_id)
                if fail >= 3:
                    break
            try:
                await asyncio.wait_for(self.shutdown_event.wait(), timeout=15)
                break
            except asyncio.TimeoutError:
                pass

    async def handle_packet_async(self, pkt):
        op = pkt["op"]
        body = pkt["body"]
        if op == 5 and body:
            try:
                await handle_message(body, self.print_fn,
                                     self.status_callback, self.room_id,
                                     pk_callback=self.pk_callback)
            except Exception as e:
                log(f"消息处理异常: {e}", "WARN",
                    show=False, room_id=self.room_id)

    async def close(self):
        self.running = False
        self.shutdown_event.set()
        for t in (self.room_info_task, self.heartbeat_task,
                  self.active_pull_task, self.account_task):
            if t:
                t.cancel()
                try:
                    await t
                except (Exception, asyncio.CancelledError):
                    pass
        if self.ws:
            try:
                await asyncio.wait_for(self.ws.close(), timeout=3)
            except Exception:
                pass
        if self.session and not self.session.closed:
            await self.session.close()

    def stop(self):
        self.running = False
        self.shutdown_event.set()