#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# auth.py
"""B 站登录相关 API（含极验验证服务 + 登录桥 + 国家冠字码 + favicon + 直播用户 API）"""
import base64
import socket
import threading
import time
import webbrowser
from pathlib import Path

import aiohttp
import requests
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5
from flask import Flask, jsonify, render_template_string, request, Response

import account
from logger import log, log_err


# ============================================================
#  常量
# ============================================================
API_TIMEOUT = 10

PASSPORT_H = {
    "User-Agent": account.HEADERS["User-Agent"],
    "Referer": "https://passport.bilibili.com/login",
    "Origin": "https://passport.bilibili.com",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Sec-Fetch-Site": "same-site",
    "Sec-Fetch-Mode": "cors",
}

CAPTCHA_URL = "https://passport.bilibili.com/x/passport-login/captcha?source=main_web"
CHALLENGE_TTL = 300

BILI_FAVICON_URL = "https://www.bilibili.com/favicon.ico"
_FAVICON_CACHE_FILE = Path("assets") / "bilibili.ico"

LIVE_UCENTER = "https://api.live.bilibili.com"


# ============================================================
#  原有异步 API
# ============================================================
async def api_qrcode_generate():
    async with aiohttp.ClientSession() as s:
        async with s.get(
            "https://passport.bilibili.com/x/passport-login/web/qrcode/generate",
            headers=PASSPORT_H, timeout=API_TIMEOUT) as resp:
            return await resp.json()


async def api_qrcode_poll(qrcode_key):
    async with aiohttp.ClientSession() as s:
        async with s.get(
            "https://passport.bilibili.com/x/passport-login/web/qrcode/poll",
            params={"qrcode_key": qrcode_key},
            headers=PASSPORT_H, timeout=API_TIMEOUT) as resp:
            data = await resp.json()
            ck = {k: m.value for k, m in resp.cookies.items()}
            return data, ck


async def api_captcha():
    async with aiohttp.ClientSession() as s:
        async with s.get(
            "https://passport.bilibili.com/x/passport-login/captcha",
            params={"source": "main_web"},
            headers=PASSPORT_H, timeout=API_TIMEOUT) as resp:
            return await resp.json()


async def api_get_pubkey():
    async with aiohttp.ClientSession() as s:
        async with s.get(
            "https://passport.bilibili.com/x/passport-login/web/key",
            headers=PASSPORT_H, timeout=API_TIMEOUT) as resp:
            return await resp.json()


def rsa_encrypt_password(pubkey_pem, salt, password):
    key = RSA.importKey(pubkey_pem)
    cipher = PKCS1_v1_5.new(key)
    enc = cipher.encrypt((salt + password).encode("utf-8"))
    return base64.b64encode(enc).decode()


async def api_password_login(username, pw_b64, token, challenge,
                             validate, seccode):
    if seccode and "|" not in seccode:
        seccode = f"{seccode}|jordan"
    url = "https://passport.bilibili.com/x/passport-login/web/login"
    data = {
        "username": username, "password": pw_b64, "keep": 0,
        "token": token, "challenge": challenge,
        "validate": validate, "seccode": seccode,
        "go_url": "https://www.bilibili.com",
        "source": "main_web",
    }
    h = PASSPORT_H.copy()
    h["Content-Type"] = "application/x-www-form-urlencoded"
    async with aiohttp.ClientSession() as s:
        async with s.post(url, data=data, headers=h,
                          timeout=API_TIMEOUT) as resp:
            res = await resp.json()
            ck = {k: m.value for k, m in resp.cookies.items()}
            return res, ck


async def api_sms_send(cid, tel, token, challenge, validate, seccode):
    if seccode and "|" not in seccode:
        seccode = f"{seccode}|jordan"
    url = "https://passport.bilibili.com/x/passport-login/web/sms/send"
    data = {
        "cid": cid, "tel": tel, "source": "main_web",
        "token": token, "challenge": challenge,
        "validate": validate, "seccode": seccode,
    }
    h = PASSPORT_H.copy()
    h["Content-Type"] = "application/x-www-form-urlencoded"
    async with aiohttp.ClientSession() as s:
        async with s.post(url, data=data, headers=h,
                          timeout=API_TIMEOUT) as resp:
            return await resp.json()


async def api_sms_login(cid, tel, code, captcha_key):
    url = "https://passport.bilibili.com/x/passport-login/web/login/sms"
    data = {
        "cid": cid, "tel": tel, "code": code,
        "captcha_key": captcha_key, "source": "main_web",
    }
    h = PASSPORT_H.copy()
    h["Content-Type"] = "application/x-www-form-urlencoded"
    async with aiohttp.ClientSession() as s:
        async with s.post(url, data=data, headers=h,
                          timeout=API_TIMEOUT) as resp:
            res = await resp.json()
            ck = {k: m.value for k, m in resp.cookies.items()}
            return res, ck


async def api_logout():
    if not account.CSRF:
        return False
    try:
        h = account.HEADERS.copy()
        h["Content-Type"] = "application/x-www-form-urlencoded"
        async with aiohttp.ClientSession() as s:
            async with s.post(
                "https://passport.bilibili.com/login/exit/v2",
                data={"biliCSRF": account.CSRF},
                headers=h, timeout=API_TIMEOUT) as resp:
                data = await resp.json()
                return data.get("code") == 0 and data.get("status")
    except Exception:
        return False


async def fetch_account_info():
    info = {"is_login": False, "mid": 0, "uname": "", "face": "", "level": 0,
            "coin": 0.0, "bcoin": 0.0, "vip_status": 0, "vip_label": ""}
    if not account.has_login():
        return info
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(
                "https://api.bilibili.com/x/web-interface/nav",
                headers=account.HEADERS, timeout=API_TIMEOUT) as resp:
                data = await resp.json()
    except Exception as e:
        log(f"账户检测失败: {e}", "ERR")
        return info
    if data.get("code") != 0:
        return info
    d = data.get("data") or {}
    li = d.get("level_info") or {}
    w = d.get("wallet") or {}
    vl = d.get("vip_label") or {}
    face = d.get("face", "")
    if face.startswith("http://"):
        face = "https://" + face[7:]
    info.update({
        "is_login": bool(d.get("isLogin")),
        "mid": int(d.get("mid", 0) or 0),
        "uname": d.get("uname", ""),
        "face": face,
        "level": int(li.get("current_level", 0) or 0),
        "coin": float(d.get("money", 0) or 0),
        "bcoin": float(w.get("bcoin_balance", 0) or 0),
        "vip_status": int(d.get("vipStatus", 0) or 0),
        "vip_label": vl.get("text", ""),
    })
    return info


# ============================================================
#  国家/地区冠字码
# ============================================================
_COUNTRY_CACHE = None


async def api_country_list(use_cache=True):
    global _COUNTRY_CACHE
    if use_cache and _COUNTRY_CACHE is not None:
        return _COUNTRY_CACHE

    url = "https://passport.bilibili.com/web/generic/country/list"
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(url, headers=PASSPORT_H,
                             timeout=API_TIMEOUT) as resp:
                data = await resp.json()
    except Exception as e:
        log(f"获取国家列表失败: {e}", "AUTH", show=False)
        return None

    if data.get("code") != 0:
        return None

    d = data.get("data") or {}
    common = [(str(x.get("country_id", "")), x.get("cname", ""))
              for x in d.get("common", []) if x.get("country_id")]
    others = [(str(x.get("country_id", "")), x.get("cname", ""))
              for x in d.get("others", []) if x.get("country_id")]

    result = {"common": common, "others": others}
    _COUNTRY_CACHE = result
    return result


def clear_country_cache():
    global _COUNTRY_CACHE
    _COUNTRY_CACHE = None


# ============================================================
#  favicon 获取
# ============================================================
_favicon_bytes_cache = None


def _get_favicon_bytes():
    global _favicon_bytes_cache
    if _favicon_bytes_cache:
        return _favicon_bytes_cache

    try:
        if _FAVICON_CACHE_FILE.exists() and _FAVICON_CACHE_FILE.stat().st_size > 0:
            data = _FAVICON_CACHE_FILE.read_bytes()
            _favicon_bytes_cache = data
            return data
    except Exception:
        pass

    try:
        _FAVICON_CACHE_FILE.parent.mkdir(exist_ok=True)
        r = requests.get(
            BILI_FAVICON_URL,
            headers={
                "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                               "AppleWebKit/537.36 Chrome/120 Safari/537.36"),
                "Referer": "https://www.bilibili.com/",
            },
            timeout=10)
        if r.status_code == 200 and len(r.content) > 100:
            _FAVICON_CACHE_FILE.write_bytes(r.content)
            _favicon_bytes_cache = r.content
            return r.content
    except Exception as e:
        log(f"下载 favicon 失败: {e}", "AUTH", show=False)

    return None


# ============================================================
#  极验验证服务（Flask）
# ============================================================
_geetest_state = {
    "gt": "", "challenge": "", "token": "",
    "challenge_time": 0,
    "validate": "", "seccode": "", "validate_challenge": "",
    "validate_time": 0,
}

_geetest_session = requests.Session()
_geetest_session.headers.update({
    "User-Agent": (
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
    ),
    "Referer": "https://passport.bilibili.com/login",
    "Origin": "https://passport.bilibili.com",
    "Accept": "application/json, text/plain, */*",
})

_geetest_app = Flask("bili_geetest")


GEETEST_PAGE = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<meta name="theme-color" content="#00a1d6">
<title>B站人机验证</title>
<link rel="icon" type="image/x-icon" href="/favicon.ico">
<link rel="shortcut icon" type="image/x-icon" href="/favicon.ico">
<link rel="apple-touch-icon" href="/favicon.ico">
<style>
  * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
  html, body { margin: 0; padding: 0; background: #f4f5f7; height: 100%; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif;
    color: #222; padding: 24px 16px;
    padding-bottom: calc(16px + env(safe-area-inset-bottom));
    font-size: 16px;
    display: flex; flex-direction: column;
    min-height: 100vh;
  }
  .card {
    background: #fff; border-radius: 16px; padding: 22px;
    margin: 0 auto; max-width: 480px; width: 100%;
    box-shadow: 0 4px 16px rgba(0,0,0,.06);
  }
  h2 { margin: 0 0 8px; font-size: 18px; font-weight: 600; text-align: center; }
  .sub { font-size: 13px; color: #888; text-align: center; margin-bottom: 18px; }
  #captcha-box {
    margin: 6px 0 14px; min-height: 50px;
    display: flex; justify-content: center; align-items: center;
  }
  .ttl {
    font-size: 12px; color: #f60; text-align: center;
    margin-top: 8px; min-height: 16px;
  }
  .ttl.warn { color: #c33; font-weight: 600; }
  .status {
    font-size: 14px; text-align: center; margin-top: 16px;
    min-height: 22px; line-height: 1.5;
  }
  .status.ok { color: #2a8f2a; font-weight: 600; }
  .status.err { color: #c33; }
  .done-box { display: none; text-align: center; padding: 30px 16px; }
  .done-box.show { display: block; }
  .done-icon { font-size: 60px; line-height: 1; margin-bottom: 14px; }
  .done-title { font-size: 20px; font-weight: 600; color: #2a8f2a; margin-bottom: 10px; }
  .done-tip { font-size: 14px; color: #666; line-height: 1.7; }
  .done-tip strong { color: #00a1d6; }
</style>
<script src="https://static.geetest.com/static/js/gt.0.4.9.js"></script>
</head>
<body>

<div class="card" id="verify-card">
  <h2>B站人机验证</h2>
  <div class="sub">请完成下方验证，完成后回到桌面程序</div>
  <div id="captcha-box">加载验证码中...</div>
  <div class="ttl" id="ttl"></div>
  <div class="status" id="status"></div>
</div>

<div class="card done-box" id="done-card">
  <div class="done-icon">✓</div>
  <div class="done-title">验证成功</div>
  <div class="done-tip">
    请回到<strong>桌面程序</strong>，登录将自动继续。<br>
    本页面可以关闭。
  </div>
</div>

<script>
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var ttlTimer = null;
  var submitted = false;

  function setStatus(text, cls) {
    var el = $("status");
    el.textContent = text || "";
    el.className = "status" + (cls ? " " + cls : "");
  }

  function startTtlCountdown(seconds) {
    if (ttlTimer) clearInterval(ttlTimer);
    var left = seconds;
    function tick() {
      var el = $("ttl");
      if (left <= 0) {
        el.textContent = "验证已超时，请刷新页面重新验证";
        el.className = "ttl warn";
        clearInterval(ttlTimer); ttlTimer = null;
        return;
      }
      var m = Math.floor(left / 60), s = left % 60;
      el.textContent = "剩余有效时间 " + m + ":" + (s < 10 ? "0" + s : s);
      el.className = "ttl" + (left <= 60 ? " warn" : "");
      left--;
    }
    tick();
    ttlTimer = setInterval(tick, 1000);
  }

  function showDone() {
    $("verify-card").style.display = "none";
    $("done-card").classList.add("show");
  }

  function initCaptcha() {
    setStatus("加载验证码中...");
    $("captcha-box").innerHTML = "加载验证码中...";

    fetch("/api/captcha", { cache: "no-store" })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (!data.gt || !data.challenge) {
          setStatus("获取验证参数失败，请刷新页面重试", "err");
          return;
        }
        startTtlCountdown(data.ttl || 300);

        initGeetest({
          gt: data.gt,
          challenge: data.challenge,
          offline: false, new_captcha: true,
          product: "popup", lang: "zh-cn", width: "100%"
        }, function (captcha) {
          $("captcha-box").innerHTML = "";
          captcha.appendTo("#captcha-box");
          setStatus("请点击上方按钮完成验证");

          captcha.onSuccess(function () {
            if (submitted) return;
            submitted = true;

            var r = captcha.getValidate();
            setStatus("验证成功，正在提交...", "ok");

            fetch("/api/submit-geetest", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(r)
            })
            .then(function (res) { return res.json(); })
            .then(function (d) {
              if (d.ok) {
                showDone();
                if (ttlTimer) clearInterval(ttlTimer);
                try {
                  if (window.navigator && window.navigator.vibrate) {
                    window.navigator.vibrate(200);
                  }
                } catch (e) {}
              } else {
                submitted = false;
                setStatus("提交失败：" + (d.msg || ""), "err");
              }
            })
            .catch(function (e) {
              submitted = false;
              setStatus("网络错误：" + e, "err");
            });
          });

          captcha.onError(function (e) {
            setStatus("验证出错，请刷新重试", "err");
          });
        });
      })
      .catch(function (e) {
        setStatus("初始化失败：" + e, "err");
      });
  }

  initCaptcha();
})();
</script>
</body>
</html>
"""


def _geetest_fetch_captcha():
    r = _geetest_session.get(CAPTCHA_URL, timeout=10)
    data = r.json()
    if data.get("code") != 0:
        raise RuntimeError(f"captcha 接口失败: {data}")
    g = data["data"]["geetest"]
    _geetest_state["gt"] = g.get("gt", "")
    _geetest_state["challenge"] = g.get("challenge", "")
    _geetest_state["token"] = data["data"].get("token", "")
    _geetest_state["challenge_time"] = time.time()
    _geetest_state["validate"] = ""
    _geetest_state["seccode"] = ""
    _geetest_state["validate_challenge"] = ""


def _geetest_challenge_expired():
    return time.time() - _geetest_state["challenge_time"] > CHALLENGE_TTL


_geetest_callback = None


def set_geetest_callback(cb):
    global _geetest_callback
    _geetest_callback = cb


def _fire_geetest_callback():
    if not _geetest_callback:
        return
    result = {
        "gt": _geetest_state["gt"],
        "challenge": _geetest_state["challenge"],
        "token": _geetest_state["token"],
        "validate": _geetest_state["validate"],
        "seccode": _geetest_state["seccode"],
    }
    try:
        _geetest_callback(result)
    except Exception as e:
        print(f"[!] 极验回调异常: {e}")


@_geetest_app.route("/")
def _geetest_index():
    try:
        _geetest_fetch_captcha()
    except Exception as e:
        print(f"[!] 获取 captcha 失败: {e}")
    return render_template_string(GEETEST_PAGE)


@_geetest_app.route("/favicon.ico")
def _geetest_favicon():
    data = _get_favicon_bytes()
    if not data:
        return Response(b"", status=204)
    return Response(
        data,
        mimetype="image/x-icon",
        headers={
            "Cache-Control": "public, max-age=86400",
            "Content-Type": "image/x-icon",
        })


@_geetest_app.route("/api/captcha")
def _geetest_api_captcha():
    if not _geetest_state["challenge"] or _geetest_challenge_expired():
        try:
            _geetest_fetch_captcha()
        except Exception as e:
            print(f"[!] 刷新 captcha 失败: {e}")
    left = max(0, int(
        CHALLENGE_TTL - (time.time() - _geetest_state["challenge_time"])))
    return jsonify({
        "gt": _geetest_state["gt"],
        "challenge": _geetest_state["challenge"],
        "ttl": left,
    })


@_geetest_app.route("/api/submit-geetest", methods=["POST"])
def _geetest_api_submit():
    d = request.get_json(force=True) or {}
    validate = d.get("geetest_validate", "")
    seccode = d.get("geetest_seccode", "")
    challenge_from_client = d.get("geetest_challenge", "")

    if challenge_from_client and \
            challenge_from_client != _geetest_state["challenge"]:
        return jsonify({"ok": False, "msg": "challenge 不匹配"})

    if seccode and "|" not in seccode:
        seccode = seccode + "|jordan"
    if not validate or not seccode:
        return jsonify({"ok": False, "msg": "参数为空"})

    _geetest_state["validate"] = validate
    _geetest_state["seccode"] = seccode
    _geetest_state["validate_challenge"] = _geetest_state["challenge"]
    _geetest_state["validate_time"] = time.time()

    print(f"[+] 极验通过: validate={validate[:40]}...")
    _fire_geetest_callback()
    return jsonify({"ok": True})


@_geetest_app.route("/api/status")
def _geetest_api_status():
    return jsonify({
        "has_challenge": bool(_geetest_state["challenge"]),
        "expired": _geetest_challenge_expired(),
        "verified": bool(_geetest_state["validate"]),
    })


class LoginBridge:
    def __init__(self, port=8080):
        self.port = port
        self.host = "0.0.0.0"
        self._thread = None
        self._running = False

        self._geetest_event = threading.Event()
        self._geetest_result = None
        self._geetest_lock = threading.Lock()

    def start(self):
        if self._running:
            return True

        set_geetest_callback(self._on_geetest_ok)

        def _run():
            try:
                _geetest_app.run(
                    host=self.host, port=self.port,
                    debug=False, threaded=True, use_reloader=False)
            except Exception as e:
                log_err(f"验证服务异常退出: {e}")

        self._thread = threading.Thread(target=_run, daemon=True)
        self._thread.start()
        self._running = True
        log(f"验证服务已启动: {self.get_login_url()}", "LOGIN")
        return True

    def stop(self):
        self._running = False

    def _on_geetest_ok(self, result):
        with self._geetest_lock:
            self._geetest_result = dict(result)
        self._geetest_event.set()
        log("收到极验结果", "LOGIN", show=False)

    def reset_geetest(self):
        self._geetest_event.clear()
        with self._geetest_lock:
            self._geetest_result = None

    def wait_geetest(self, timeout=300):
        self._geetest_event.clear()
        with self._geetest_lock:
            self._geetest_result = None
        if not self._geetest_event.wait(timeout):
            return None
        with self._geetest_lock:
            return self._geetest_result

    def get_local_ip(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
        except Exception:
            ip = "127.0.0.1"
        finally:
            s.close()
        return ip

    def get_login_url(self):
        return f"http://{self.get_local_ip()}:{self.port}"

    def open_in_browser(self):
        try:
            webbrowser.open(self.get_login_url())
        except Exception:
            pass


login_bridge = LoginBridge()


# ============================================================
#  密码登录（组合 API）
# ============================================================
async def do_password_login(username: str, password: str,
                            geetest: dict) -> dict:
    key_res = await api_get_pubkey()
    if key_res.get("code") != 0:
        return {"ok": False,
                "msg": f"获取公钥失败: {key_res.get('message')}"}

    hash_val = key_res["data"]["hash"]
    pubkey = key_res["data"]["key"]

    try:
        pw_b64 = rsa_encrypt_password(pubkey, hash_val, password)
    except Exception as e:
        return {"ok": False, "msg": f"密码加密失败: {e}"}

    res, ck = await api_password_login(
        username=username,
        pw_b64=pw_b64,
        token=geetest["token"],
        challenge=geetest["challenge"],
        validate=geetest["validate"],
        seccode=geetest["seccode"],
    )

    code = res.get("code")
    if code != 0:
        return {"ok": False,
                "msg": f"[{code}] {res.get('message', '')}"}

    data = res.get("data") or {}
    status = data.get("status", 0)

    if status == 2:
        return {
            "ok": False,
            "msg": "触发风控，需完成手机验证",
            "risk_url": data.get("url", ""),
            "tmp_token": data.get("tmp_token", ""),
        }

    if not ck:
        return {"ok": False, "msg": "登录成功但未拿到 cookie"}

    try:
        account.save_cookies(ck)
        account.reload_headers()
    except Exception as e:
        log_err(f"保存 cookie 失败: {e}")

    try:
        info = await fetch_account_info()
        if info.get("is_login"):
            account.add_or_update_account(ck, info)
            return {"ok": True, "cookies": ck, "info": info}
    except Exception as e:
        log_err(f"获取账号信息失败: {e}")

    return {"ok": True, "cookies": ck}


# ============================================================
#  直播间用户实用 API
# ============================================================
async def api_get_my_medals(page=1, page_size=10):
    """获取用户持有的粉丝勋章。

    参数：
        page: 页码，从 1 开始
        page_size: 每页数量，最大 10
    返回：
        {
            "ok": bool,
            "items": [...],       # 勋章列表
            "count": num,         # 勋章总数
            "total_page": num,    # 总页数
            "cur_page": num,      # 当前页
            "msg": str,           # 失败原因
        }
    """
    if not account.has_login():
        return {"ok": False, "msg": "未登录"}
    if page_size > 10:
        page_size = 10
    if page < 1:
        page = 1

    url = f"{LIVE_UCENTER}/xlive/app-ucenter/v1/user/GetMyMedals"
    params = {"page": page, "page_size": page_size}
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(url, params=params,
                             headers=account.HEADERS,
                             timeout=API_TIMEOUT) as resp:
                data = await resp.json()
    except Exception as e:
        return {"ok": False, "msg": f"请求失败: {e}"}

    if data.get("code") != 0:
        return {"ok": False,
                "msg": f"[{data.get('code')}] {data.get('message')}"}

    d = data.get("data") or {}
    page_info = d.get("page_info") or {}
    return {
        "ok": True,
        "items": d.get("items") or [],
        "count": d.get("count", 0),
        "total_page": page_info.get("total_page", 1),
        "cur_page": page_info.get("cur_page", page),
    }


async def api_get_all_medals(max_pages=20):
    """自动翻页获取用户所有粉丝勋章。

    max_pages 用于防止极端情况下无限翻页。
    """
    all_items = []
    page = 1
    total_page = 1
    while page <= max_pages:
        r = await api_get_my_medals(page=page, page_size=10)
        if not r.get("ok"):
            if all_items:
                # 部分成功，返回已拿到的
                return {"ok": True, "items": all_items,
                        "count": len(all_items),
                        "partial": True, "msg": r.get("msg")}
            return {"ok": False, "msg": r.get("msg"), "items": []}
        all_items.extend(r.get("items") or [])
        total_page = r.get("total_page", 1)
        if page >= total_page:
            break
        page += 1
    return {"ok": True, "items": all_items, "count": len(all_items)}


async def api_wear_medal(medal_id):
    """佩戴指定粉丝勋章。"""
    if not account.has_login():
        return {"ok": False, "msg": "未登录"}
    if not account.CSRF:
        return {"ok": False, "msg": "缺少 CSRF，请重新登录"}

    url = f"{LIVE_UCENTER}/xlive/web-room/v1/fansMedal/wear"
    h = account.HEADERS.copy()
    h["Content-Type"] = "application/x-www-form-urlencoded"
    data = {
        "medal_id": medal_id,
        "csrf": account.CSRF,
        "csrf_token": account.CSRF,
    }
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post(url, data=data, headers=h,
                              timeout=API_TIMEOUT) as resp:
                res = await resp.json()
    except Exception as e:
        return {"ok": False, "msg": f"请求失败: {e}"}

    if res.get("code") != 0:
        return {"ok": False,
                "msg": f"[{res.get('code')}] {res.get('message')}"}
    return {"ok": True, "msg": res.get("message", "佩戴成功")}


async def api_live_sign():
    """直播签到（每天一次）。"""
    if not account.has_login():
        return {"ok": False, "msg": "未登录"}

    url = f"{LIVE_UCENTER}/xlive/web-ucenter/v1/sign/DoSign"
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(url, headers=account.HEADERS,
                             timeout=API_TIMEOUT) as resp:
                data = await resp.json()
    except Exception as e:
        return {"ok": False, "msg": f"请求失败: {e}"}

    if data.get("code") != 0:
        return {
            "ok": False,
            "msg": f"[{data.get('code')}] {data.get('message')}",
            "data": data.get("data"),
        }
    return {
        "ok": True,
        "msg": data.get("message", "签到成功"),
        "data": data.get("data"),
    }


async def api_get_sign_info():
    """本月直播签到信息。"""
    if not account.has_login():
        return {"ok": False, "msg": "未登录"}

    url = f"{LIVE_UCENTER}/xlive/web-ucenter/v1/sign/WebGetSignInfo"
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(url, headers=account.HEADERS,
                             timeout=API_TIMEOUT) as resp:
                data = await resp.json()
    except Exception as e:
        return {"ok": False, "msg": f"请求失败: {e}"}

    if data.get("code") != 0:
        return {"ok": False,
                "msg": f"[{data.get('code')}] {data.get('message')}"}
    return {"ok": True, "data": data.get("data") or {}}


async def api_get_last_month_sign():
    """上月直播签到信息。"""
    if not account.has_login():
        return {"ok": False, "msg": "未登录"}

    url = f"{LIVE_UCENTER}/sign/getLastMonthSignDays"
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(url, headers=account.HEADERS,
                             timeout=API_TIMEOUT) as resp:
                data = await resp.json()
    except Exception as e:
        return {"ok": False, "msg": f"请求失败: {e}"}

    if data.get("code") != 0:
        return {"ok": False,
                "msg": f"[{data.get('code')}] {data.get('message')}"}
    return {"ok": True, "data": data.get("data") or {}}


async def api_auto_sign():
    """检查并签到。

    返回：
        {"ok": bool, "already_signed": bool, "msg": str, "info": {...}}
    """
    r = await api_get_sign_info()
    if not r.get("ok"):
        return {"ok": False, "already_signed": False,
                "msg": r.get("msg"), "info": None}

    info = r["data"]
    if info.get("status") == 1:
        return {"ok": True, "already_signed": True,
                "msg": "今日已签到", "info": info}

    sr = await api_live_sign()
    if not sr.get("ok"):
        return {"ok": False, "already_signed": False,
                "msg": sr.get("msg"), "info": info}

    info2 = (await api_get_sign_info()).get("data") or info
    return {"ok": True, "already_signed": False,
            "msg": sr.get("msg", "签到成功"), "info": info2}