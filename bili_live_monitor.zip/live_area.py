# -*- coding: utf-8 -*-
import json
import time
import urllib.parse
import urllib.request

AREA_LIST_API = "https://api.live.bilibili.com/room/v1/Area/getList"
REFERER = "https://live.bilibili.com/"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
      "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36")

CACHE_TTL = 86400


class LiveAreaManager:
    """B 站直播分区管理器，负责拉取、缓存和查询分区信息。"""

    def __init__(self):
        self._parent_areas = []
        self._sub_areas = {}
        self._name_to_id = {}
        self._id_to_info = {}
        self._last_fetch = 0

    def fetch(self, force=False):
        """拉取分区列表并建立索引。force=True 时忽略缓存强制刷新。"""
        now = time.time()
        if not force and self._parent_areas and (now - self._last_fetch) < CACHE_TTL:
            return True
        try:
            url = AREA_LIST_API
            req = urllib.request.Request(url, headers={
                "User-Agent": UA,
                "Referer": REFERER,
            })
            with urllib.request.urlopen(req, timeout=10) as r:
                data = json.loads(r.read().decode("utf-8"))
            if data.get("code") != 0:
                return False
            self._parse(data.get("data", []))
            self._last_fetch = now
            return True
        except Exception:
            return False

    def _parse(self, data):
        self._parent_areas = []
        self._sub_areas = {}
        self._name_to_id = {}
        self._id_to_info = {}

        for parent in data:
            pid = parent.get("id")
            pname = parent.get("name", "")
            children = parent.get("list", []) or []

            sub_list = []
            for child in children:
                cid = str(child.get("id", ""))
                cname = child.get("name", "")
                pic = child.get("pic", "")
                hot = child.get("hot_status", 0)

                info = {
                    "id": cid,
                    "parent_id": str(pid),
                    "parent_name": pname,
                    "name": cname,
                    "pic": pic,
                    "hot_status": hot,
                }
                sub_list.append(info)
                self._id_to_info[cid] = info
                self._name_to_id.setdefault(cname, cid)

            self._parent_areas.append({
                "id": pid,
                "name": pname,
                "sub_areas": sub_list,
            })
            self._sub_areas[pid] = sub_list

    def get_parent_names(self):
        return [p["name"] for p in self._parent_areas]

    def get_sub_names(self, parent_name):
        for p in self._parent_areas:
            if p["name"] == parent_name:
                return [s["name"] for s in p["sub_areas"]]
        return []

    def get_sub_names_by_id(self, parent_id):
        subs = self._sub_areas.get(int(parent_id), [])
        return [s["name"] for s in subs]

    def find_area_id(self, name):
        """通过子分区名或拼音查找 area_id，失败返回 None。"""
        if not name:
            return None
        if name in self._name_to_id:
            return self._name_to_id[name]
        lower = name.lower()
        for k, v in self._name_to_id.items():
            if k.lower() == lower:
                return v
        return None

    def get_area_info(self, area_id):
        """通过 area_id 获取分区详情。"""
        return self._id_to_info.get(str(area_id))

    def get_area_name(self, area_id):
        info = self.get_area_info(area_id)
        return info["name"] if info else str(area_id)

    def get_full_path(self, area_id):
        """返回 '父分区 / 子分区' 格式的完整路径。"""
        info = self.get_area_info(area_id)
        if not info:
            return str(area_id)
        return f"{info['parent_name']} / {info['name']}"

    @property
    def loaded(self):
        return bool(self._parent_areas)

    @property
    def parent_areas(self):
        return self._parent_areas