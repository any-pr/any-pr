#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""WBI 签名"""
import time
import hashlib
import urllib.parse
from functools import reduce

import account
from logger import log

MIXIN_KEY_ENC_TAB = [
    46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35,
    27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13,
    37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4,
    22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52]


class WbiSigner:
    def __init__(self):
        self.mixin_key = ""
        self.fetched_at = 0

    def _gen(self, raw):
        return reduce(lambda s, i: s + raw[i], MIXIN_KEY_ENC_TAB, "")[:32]

    async def ensure_keys(self, session):
        if self.mixin_key and time.time() - self.fetched_at < 3600:
            return
        async with session.get("https://api.bilibili.com/x/web-interface/nav",
                               headers=account.HEADERS, timeout=10) as resp:
            data = await resp.json()
        wbi = (data.get("data") or {}).get("wbi_img") or {}
        iu = wbi.get("img_url", "")
        su = wbi.get("sub_url", "")
        if not iu or not su:
            raise Exception("WBI keys 失败")
        self.mixin_key = self._gen(iu.rsplit("/", 1)[-1].split(".")[0] +
                                    su.rsplit("/", 1)[-1].split(".")[0])
        self.fetched_at = time.time()
        log(f"WBI 密钥已刷新 ({self.mixin_key[:8]}...)", "WBI", show=False)

    def sign(self, params):
        if not self.mixin_key:
            return params
        p = dict(params)
        p["wts"] = int(time.time())
        parts = []
        for k in sorted(p.keys()):
            v = "".join(c for c in str(p[k]) if c not in "!'()*")
            parts.append((k, v))
        query = urllib.parse.urlencode(parts, quote_via=urllib.parse.quote)
        p["w_rid"] = hashlib.md5((query + self.mixin_key).encode()).hexdigest()
        return p


wbi_signer = WbiSigner()