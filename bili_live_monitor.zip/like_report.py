#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# like_report.py
"""B站直播间点赞批量上报（点一次 = 上报 1000 个赞）

不依赖 messages.py。
优先复用项目里的 wbi.py（wbi_signer 单例），
若 wbi.py 不存在则使用内置 WBI 签名实现兜底。
"""
import asyncio
import hashlib
import time
import urllib.parse

import aiohttp

import account
from logger import log_err, log


LIKE_REPORT_API = ("https://api.live.bilibili.com/xlive/app-ucenter/v1/"
                   "like_info_v3/like/likeReportV3")

_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
       "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36")

_MIXIN_KEY_ENC_TAB = [
    46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35,
    27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13,
    37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4,
    22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52,
]


# ============================================================
#  WBI 签名：优先复用 wbi.py，兜底使用内置实现
# ============================================================
_WBI_SIGNER = None
try:
    from wbi import wbi_signer as _WBI_SIGNER  # type: ignore
except Exception:
    _WBI_SIGNER = None


# ---------- 内置 WBI（wbi.py 不存在时使用） ----------
_WBI_CACHE = {"img_key": "", "sub_key": "", "ts": 0.0}


def _get_mixin_key(img_key, sub_key):
    raw = img_key + sub_key
    return "".join(raw[i] for i in _MIXIN_KEY_ENC_TAB
                   if i < len(raw))[:32]


async def _builtin_fetch_keys(session):
    now = time.time()
    if _WBI_CACHE["img_key"] and now - _WBI_CACHE["ts"] < 43200:
        return _WBI_CACHE["img_key"], _WBI_CACHE["sub_key"]
    try:
        async with session.get(
            "https://api.bilibili.com/x/web-interface/nav",
            headers={"User-Agent": _UA,
                     "Referer": "https://www.bilibili.com/"},
            cookies=account.get_cookie_dict(),
        ) as resp:
            d = await resp.json(content_type=None)
    except Exception as e:
        log(f"获取 WBI keys 失败: {e}", "LIKE", show=False)
        return "", ""

    wbi = ((d.get("data") or {}).get("wbi_img") or {})
    img_url = wbi.get("img_url", "")
    sub_url = wbi.get("sub_url", "")
    if not img_url or not sub_url:
        return "", ""

    img_key = img_url.rsplit("/", 1)[-1].split(".")[0]
    sub_key = sub_url.rsplit("/", 1)[-1].split(".")[0]
    _WBI_CACHE["img_key"] = img_key
    _WBI_CACHE["sub_key"] = sub_key
    _WBI_CACHE["ts"] = now
    return img_key, sub_key


def _builtin_sign(params, img_key, sub_key):
    mixin_key = _get_mixin_key(img_key, sub_key)
    p = dict(params)
    p["wts"] = int(time.time())
    parts = []
    for k in sorted(p.keys()):
        v = "".join(c for c in str(p[k]) if c not in "!'()*")
        parts.append((k, v))
    query = urllib.parse.urlencode(parts, quote_via=urllib.parse.quote)
    p["w_rid"] = hashlib.md5((query + mixin_key).encode()).hexdigest()
    return p


async def _sign_params(session, params):
    """统一签名入口：优先 wbi_signer，否则内置实现。"""
    # 1) 优先复用 wbi.py
    if _WBI_SIGNER is not None:
        try:
            await _WBI_SIGNER.ensure_keys(session)
            if getattr(_WBI_SIGNER, "mixin_key", ""):
                return _WBI_SIGNER.sign(params)
        except Exception:
            pass

    # 2) 兜底：内置
    img_key, sub_key = await _builtin_fetch_keys(session)
    if not img_key or not sub_key:
        return dict(params)
    return _builtin_sign(params, img_key, sub_key)


# ============================================================
#  点赞批量上报
# ============================================================
async def report_like(room_id, anchor_id, uid, count=1000):
    """
    上报一次点赞，count 为一次上报的点赞数（默认 1000）。
    返回 (ok, msg)
    """
    if not account.has_login():
        return False, "未登录"

    csrf = account.CSRF
    if not csrf:
        return False, "无 CSRF"

    try:
        room_id = int(room_id)
        anchor_id = int(anchor_id)
        uid = int(uid)
        count = int(count)
    except Exception:
        return False, "参数错误"

    if room_id <= 0 or anchor_id <= 0 or uid <= 0 or count <= 0:
        return False, "参数错误"

    params = {
        "click_time": count,
        "room_id": room_id,
        "uid": uid,
        "anchor_id": anchor_id,
        "web_location": "444.8",
        "csrf": csrf,
    }

    headers = {
        "User-Agent": _UA,
        "Origin": "https://live.bilibili.com",
        "Referer": (f"https://live.bilibili.com/{room_id}"
                    f"?broadcast_type=0&is_room_feed=1"),
        "Accept": "*/*",
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Content-Length": "0",
        "X-Requested-With": "mark.via",
    }

    try:
        timeout = aiohttp.ClientTimeout(total=15)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            signed = await _sign_params(session, params)
            url = LIKE_REPORT_API + "?" + urllib.parse.urlencode(signed)
            async with session.post(
                url, headers=headers,
                cookies=account.get_cookie_dict()
            ) as resp:
                result = await resp.json(content_type=None)
    except Exception as e:
        return False, f"请求异常: {e}"

    if not result:
        return False, "无响应"

    code = result.get("code")
    if code == 0:
        return True, f"成功上报 {count} 个赞"
    return False, f"[{code}] {result.get('message', '')}"


def report_like_sync(room_id, anchor_id, uid, count=1000):
    """同步包装，供 UI 线程或后台线程直接调用。"""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(
            report_like(room_id, anchor_id, uid, count))
    except Exception as e:
        log_err(f"点赞上报同步异常: {e}")
        return False, str(e)
    finally:
        try:
            loop.close()
        except Exception:
            pass