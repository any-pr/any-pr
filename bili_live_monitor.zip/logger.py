#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# logger.py
"""日志模块
"""
import json
import threading
from pathlib import Path
from datetime import datetime, timezone, timedelta

LOCAL_TZ = timezone(timedelta(hours=8))

LOG_ROOT = Path("logs")
DEBUG_ROOT = Path("debug")
PB_ROOT = DEBUG_ROOT / "PB"
WS_ROOT = DEBUG_ROOT / "ws"

for _d in (LOG_ROOT, DEBUG_ROOT, PB_ROOT, WS_ROOT):
    _d.mkdir(exist_ok=True)

_TS = datetime.now(LOCAL_TZ).strftime("%Y-%m-%d_%H-%M-%S")

_global_fh = open(LOG_ROOT / f"global_{_TS}.log", "a", encoding="utf-8")
_global_lock = threading.Lock()

# room_id -> {"app": fh, "pb": fh, "ws": fh}
_room_handles = {}
_room_lock = threading.Lock()


def _now_iso():
    return datetime.now(LOCAL_TZ).isoformat()


def _now_hm():
    return datetime.now(LOCAL_TZ).strftime("%H:%M:%S")


def _get_room_fhs(room_id):
    """懒加载单个房间的三类文件句柄"""
    with _room_lock:
        if room_id in _room_handles:
            return _room_handles[room_id]

        # 应用日志：logs/room_<rid>/app_<ts>.log
        app_dir = LOG_ROOT / f"room_{room_id}"
        app_dir.mkdir(parents=True, exist_ok=True)

        # PB 数据：debug/PB/room_<rid>/pb_<ts>.jsonl
        pb_dir = PB_ROOT / f"room_{room_id}"
        pb_dir.mkdir(parents=True, exist_ok=True)

        # WS 数据：debug/ws/room_<rid>/ws_<ts>.jsonl
        ws_dir = WS_ROOT / f"room_{room_id}"
        ws_dir.mkdir(parents=True, exist_ok=True)

        fhs = {
            "app": open(app_dir / f"app_{_TS}.log", "a", encoding="utf-8"),
            "pb": open(pb_dir / f"pb_{_TS}.jsonl", "a", encoding="utf-8"),
            "ws": open(ws_dir / f"ws_{_TS}.jsonl", "a", encoding="utf-8"),
        }
        _room_handles[room_id] = fhs
        return fhs


# ---------- 应用日志 ----------
def log(msg, tag="INFO", show=True, room_id=None):
    line = f"[{_now_iso()}][{tag}] {msg}\n"
    try:
        with _global_lock:
            _global_fh.write(line)
            _global_fh.flush()
    except Exception:
        pass
    if room_id is not None:
        try:
            fh = _get_room_fhs(room_id)["app"]
            fh.write(line)
            fh.flush()
        except Exception:
            pass
    if show:
        ts = _now_hm()
        prefix = f"[房间 {room_id}] " if room_id is not None else ""
        try:
            print(f"[{ts}][{tag}] {prefix}{msg}", flush=True)
        except Exception:
            pass


def log_err(msg, room_id=None):
    log(msg, "ERR", room_id=room_id)


# ---------- PB 数据（debug/PB/room_<rid>/pb_<ts>.jsonl） ----------
def pb_write(record, room_id=None):
    if room_id is None:
        return
    try:
        rec = {"ts": _now_iso()}
        rec.update(record)
        fh = _get_room_fhs(room_id)["pb"]
        fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
        fh.flush()
    except Exception:
        pass


# ---------- WS 数据（debug/ws/room_<rid>/ws_<ts>.jsonl） ----------
def ws_write(record, room_id=None):
    if room_id is None:
        return
    try:
        rec = {"ts": _now_iso()}
        rec.update(record)
        fh = _get_room_fhs(room_id)["ws"]
        fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
        fh.flush()
    except Exception:
        pass


def close():
    try:
        _global_fh.close()
    except Exception:
        pass
    with _room_lock:
        for fhs in _room_handles.values():
            for fh in fhs.values():
                try:
                    fh.close()
                except Exception:
                    pass
        _room_handles.clear()