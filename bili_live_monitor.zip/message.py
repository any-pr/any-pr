# -*- coding: utf-8 -*-
import asyncio
import base64
import hashlib
import json
import re
import threading
import time
import urllib.parse

import aiohttp

from logger import log
from pb import (
    _safe_int, _is_valid_name, _first_string, _first_int,
    decode_pb_safe, split_json_objects,
)

PK_STATUS_MAP = {
    101: "连线中", 102: "等待对手", 201: "进行中", 301: "已结束",
    302: "已结束（平局）", 401: "已取消", 501: "已超时",
    601: "已结束（失败）", 610: "已结束（惩罚）", 1001: "已结束（超时）",
}

PK_EVENT_MAP = {
    "PK_BATTLE_START": "PK开始",
    "PK_BATTLE_START_NEW": "PK开始",
    "PK_BATTLE_PROCESS": "PK进行中",
    "PK_BATTLE_PROCESS_NEW": "PK进行中",
    "PK_BATTLE_SETTLE": "PK结算",
    "PK_BATTLE_SETTLE_NEW": "PK结算",
    "PK_BATTLE_PUNISH_END": "PK惩罚结束",
    "PK_BATTLE_END": "PK结束",
}

IMPORTANT_CMDS = {
    "DANMU_MSG", "SEND_GIFT", "SEND_GIFT_V2", "SUPER_CHAT_MESSAGE",
    "SUPER_CHAT_MESSAGE_JPN", "SUPER_CHAT_ENTRANCE",
    "GUARD_BUY", "USER_TOAST_MSG", "GUARD_HONOR_THOUSAND",
    "INTERACT_WORD", "INTERACT_WORD_V2", "DM_INTERACTION",
    "ENTRY_EFFECT", "ENTRY_EFFECT_MUST_RECEIVE",
    "PK_INFO", "PK_BATTLE_PRE", "PK_BATTLE_PRE_NEW",
    "PK_BATTLE_START", "PK_BATTLE_START_NEW",
    "PK_BATTLE_END",
    "PK_BATTLE_VIDEO_PUNISH_BEGIN", "PK_BATTLE_PUNISH_END",
    "PK_BATTLE_PROCESS", "PK_BATTLE_PROCESS_NEW",
    "PK_BATTLE_SETTLE", "PK_BATTLE_SETTLE_NEW",
    "PK_BATTLE_SETTLE_USER", "PK_BATTLE_SETTLE_V2",
    "PK_WIDGET", "PK_BATTLE_ENTRANCE",
    "UNIVERSAL_EVENT_GIFT_V2", "UNIVERSAL_EVENT_GIFT",
    "LIVE", "PREPARING", "WATCHED_CHANGE",
    "ONLINE_RANK_COUNT", "ONLINE_RANK_V2", "ONLINE_RANK_V3",
    "ONLINE_RANK_TOP3",
    "ROOM_REAL_TIME_MESSAGE_UPDATE", "ROOM_CHANGE",
    "COMBO_SEND", "NOTICE_MSG", "COMMON_NOTICE_DANMAKU",
    "LIVE_ANI_RES_UPDATE", "STOP_LIVE_ROOM_LIST", "SYS_MSG",
    "LIKE_INFO_V3_UPDATE", "LIKE_INFO_V3_CLICK",
    "FLOW_REWARD_CARD", "WIDGET_BANNER",
    "POPULARITY_RED_POCKET_V2_NEW", "POPULARITY_RED_POCKET_START",
    "POPULARITY_RED_POCKET_V2_START",
    "POPULARITY_RED_POCKET_NEW",
    "POPULARITY_RED_POCKET_V2_WINNER_LIST",
    "POPULARITY_RED_POCKET_WINNER_LIST",
    "GIFT_STAR_PROCESS", "WIDGET_GIFT_STAR_PROCESS_V2",
    "MESSAGEBOX_USER_GAIN_MEDAL", "CONFIRM_AUTO_FOLLOW",
    "VOICE_JOIN_ROOM_COUNT_INFO", "POPULAR_RANK_CHANGED",
    "VOICE_JOIN_LIST", "RANK_CHANGED", "RANK_CHANGED_V2",
    "AREA_RANK_CHANGED",
    "CUSTOM_NOTICE_CARD",
    "LIVE_OPEN_PLATFORM_GAME", "OPENPLATFORM_GAME_BUTTON_STATUS_CHANGE",
    "LIVE_ROOM_TOAST_MESSAGE",
    "USER_PANEL_RED_ALARM",
    "PLAY_TOGETHER", "MESSAGEBOX_USER_MEDAL_CHANGE",
    "ANCHOR_LOT_START", "ANCHOR_LOT_END", "ANCHOR_LOT_AWARD",
    "HOT_ROOM_NOTIFY", "RECOMMEND_CARD",
    "REVENUE_RANK_CHANGED", "WIDGET_WISH_LIST",
}

_HTTP_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0 Safari/537.36")

_CONTRIBUTION_RANK_API = ("https://api.live.bilibili.com/xlive/"
                          "general-interface/v1/rank/queryContributionRank")
_ONLINE_RANK_API = ("https://api.live.bilibili.com/xlive/general-interface"
                    "/v1/rank/getOnlineGoldRank")
_PK_INFO_API = ("https://api.live.bilibili.com/xlive/general-interface"
                "/v1/battle/getInfoById")
_UNIVERSAL_INFO_API = ("https://api.live.bilibili.com/xlive/web-room/v2"
                       "/universalInteract/UniversalInfoForAudience")
_PK_ACTIVE_STATUS = {101, 102, 201}

_PK_ID_CACHE = {}
_PK_ID_LOCK = threading.Lock()
_SESSION_ID_CACHE = {}
_SESSION_ID_LOCK = threading.Lock()
_WBI_KEYS_CACHE = {"img_key": "", "sub_key": "", "ts": 0.0}
_WBI_KEYS_LOCK = threading.Lock()
_MIXIN_KEY_ENC_TAB = [
    46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35,
    27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13,
    37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4,
    22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52,
]


def _remember_pk_id(room_id, pk_id):
    if not room_id or not pk_id:
        return
    try:
        with _PK_ID_LOCK:
            _PK_ID_CACHE[int(room_id)] = int(pk_id)
    except Exception:
        pass


def _forget_pk_id(room_id):
    try:
        with _PK_ID_LOCK:
            _PK_ID_CACHE.pop(int(room_id), None)
    except Exception:
        pass


def _get_pk_id(room_id):
    try:
        with _PK_ID_LOCK:
            return _PK_ID_CACHE.get(int(room_id), 0)
    except Exception:
        return 0


def _remember_session_id(room_id, session_id):
    if not room_id or not session_id:
        return
    try:
        with _SESSION_ID_LOCK:
            _SESSION_ID_CACHE[int(room_id)] = str(session_id)
    except Exception:
        pass


def _forget_session_id(room_id):
    try:
        with _SESSION_ID_LOCK:
            _SESSION_ID_CACHE.pop(int(room_id), None)
    except Exception:
        pass


def _get_session_id(room_id):
    try:
        with _SESSION_ID_LOCK:
            return _SESSION_ID_CACHE.get(int(room_id), "")
    except Exception:
        return ""


def _get_mixin_key(img_key, sub_key):
    raw = img_key + sub_key
    return "".join(raw[i] for i in _MIXIN_KEY_ENC_TAB if i < len(raw))[:32]


async def _get_wbi_keys(session, force=False):
    with _WBI_KEYS_LOCK:
        now = time.time()
        if not force and _WBI_KEYS_CACHE["img_key"] and \
                now - _WBI_KEYS_CACHE["ts"] < 43200:
            return (_WBI_KEYS_CACHE["img_key"],
                    _WBI_KEYS_CACHE["sub_key"])
    try:
        async with session.get(
            "https://api.bilibili.com/x/web-interface/nav",
            headers={"User-Agent": _HTTP_UA,
                     "Referer": "https://www.bilibili.com/"}
        ) as resp:
            d = await resp.json(content_type=None)
        wbi = ((d.get("data") or {}).get("wbi_img") or {})
        img_url = wbi.get("img_url", "")
        sub_url = wbi.get("sub_url", "")
        if img_url and sub_url:
            img_key = img_url.rsplit("/", 1)[-1].split(".")[0]
            sub_key = sub_url.rsplit("/", 1)[-1].split(".")[0]
            with _WBI_KEYS_LOCK:
                _WBI_KEYS_CACHE["img_key"] = img_key
                _WBI_KEYS_CACHE["sub_key"] = sub_key
                _WBI_KEYS_CACHE["ts"] = time.time()
            return img_key, sub_key
    except Exception:
        pass
    return "", ""


async def _wbi_sign(session, params):
    img_key, sub_key = await _get_wbi_keys(session)
    if not img_key or not sub_key:
        return dict(params)
    mixin_key = _get_mixin_key(img_key, sub_key)
    params = dict(params)
    params["wts"] = int(time.time())
    sorted_items = sorted(params.items())
    query = urllib.parse.urlencode(sorted_items)
    w_rid = hashlib.md5((query + mixin_key).encode()).hexdigest()
    params["w_rid"] = w_rid
    return params


def _fmt_guard(g):
    return {1: "总督", 2: "提督", 3: "舰长"}.get(g, "")


def _medal_prefix(mn, ml, g=0):
    parts = []
    if mn:
        parts.append(mn)
    if ml:
        parts.append(str(ml))
    if g:
        gs = _fmt_guard(g)
        if gs:
            parts.append(gs)
    return ("[" + " ".join(parts) + "] ") if parts else ""


def _int_to_hex(v):
    if isinstance(v, str):
        return v if v.startswith("#") else ""
    if not isinstance(v, int) or v < 0:
        return ""
    return "#{:06X}".format(v & 0xFFFFFF)


def _strip_alpha(c):
    if not isinstance(c, str):
        return c
    if c.startswith("#") and len(c) >= 7:
        return c[:7]
    return c


def _pb_items(tree, field):
    v = tree.get(field)
    if v is None:
        return []
    return v if isinstance(v, list) else [v]


def _pb_str(tree, field):
    for it in _pb_items(tree, field):
        if isinstance(it, dict) and "string" in it:
            s = it["string"]
            if s:
                return s
    return ""


def _pb_int(tree, field):
    for it in _pb_items(tree, field):
        if isinstance(it, dict):
            if "signed" in it and it["signed"] < 0:
                return it["signed"]
            if "varint" in it:
                return it["varint"]
    return 0


def _pb_msg(tree, field):
    for it in _pb_items(tree, field):
        if isinstance(it, dict) and "message" in it:
            return it["message"]
    return {}


def _all_strings(node, max_depth=8):
    out = []

    def _walk(n, depth):
        if depth > max_depth:
            return
        if isinstance(n, dict):
            if "string" in n and isinstance(n["string"], str):
                out.append(n["string"])
            for v in n.values():
                _walk(v, depth + 1)
        elif isinstance(n, list):
            for it in n:
                _walk(it, depth + 1)
    _walk(node, 0)
    return out


def _is_face_url(s):
    if not s or not isinstance(s, str):
        return False
    if not s.startswith("http"):
        return False
    if "hdslb" not in s and "bilivideo" not in s:
        return False
    return any(s.endswith(ext) for ext in
               (".jpg", ".jpeg", ".png", ".webp", ".gif"))


def _find_username(strings, face_url="", exclude=None):
    exclude = exclude or set()
    for s in strings:
        if not s or s == face_url:
            continue
        if s in exclude:
            continue
        if s.startswith("http") or s.startswith("#"):
            continue
        if not (1 <= len(s) <= 30):
            continue
        if s.isdigit():
            continue
        if not any(c.isalnum() or ord(c) > 127 for c in s):
            continue
        return s
    return ""


def _empty_medal():
    return {
        "medal_name": "", "medal_level": 0, "medal_id": 0,
        "bg_color": "", "start_color": "", "end_color": "",
        "border_color": "", "highlight_color": "",
        "text_color": "#FFFFFF", "color_main": "", "color_sub": "",
        "guard_level": 0, "intimacy_limit": 0,
    }


def _parse_medal_pb(medal_msg):
    out = _empty_medal()
    if not isinstance(medal_msg, dict):
        return out
    out["medal_name"] = _pb_str(medal_msg, 1) or ""
    out["medal_level"] = _pb_int(medal_msg, 2) or 0
    out["medal_id"] = _pb_int(medal_msg, 10) or 0
    out["intimacy_limit"] = _pb_int(medal_msg, 12) or 0
    raw_main = _pb_str(medal_msg, 15)
    out["color_main"] = _strip_alpha(raw_main) if raw_main else \
                        _int_to_hex(_pb_int(medal_msg, 3))
    raw_sub = _pb_str(medal_msg, 19) or _pb_str(medal_msg, 16)
    out["color_sub"] = _strip_alpha(raw_sub) if raw_sub else out["color_main"]
    out["text_color"] = _strip_alpha(_pb_str(medal_msg, 18)) or "#FFFFFF"
    out["bg_color"] = _int_to_hex(_pb_int(medal_msg, 3))
    out["start_color"] = _int_to_hex(_pb_int(medal_msg, 4))
    out["end_color"] = _int_to_hex(_pb_int(medal_msg, 5))
    out["border_color"] = _int_to_hex(_pb_int(medal_msg, 6))
    out["highlight_color"] = _int_to_hex(_pb_int(medal_msg, 7))
    return out


def _find_medal_in_tree(tree, depth=0, max_depth=6):
    if depth > max_depth or not isinstance(tree, dict):
        return None
    for _, v in tree.items():
        items = v if isinstance(v, list) else [v]
        for it in items:
            if not isinstance(it, dict):
                continue
            m = it.get("message")
            if isinstance(m, dict):
                name = _pb_str(m, 1)
                lvl = _pb_int(m, 2)
                col = _pb_str(m, 15)
                if name and 1 <= lvl <= 60 and col.startswith("#"):
                    return _parse_medal_pb(m)
                sub = _find_medal_in_tree(m, depth + 1, max_depth)
                if sub:
                    return sub
    return None


def _extract_medal_from_json(member):
    out = _empty_medal()
    if not isinstance(member, dict):
        return out
    for key in ("fans_medal", "medal_info", "medalInfo", "medal"):
        m = member.get(key)
        if isinstance(m, dict):
            out["medal_name"] = m.get("medal_name") or m.get("name") or ""
            out["medal_level"] = _safe_int(m.get("medal_level") or m.get("level") or 0)
            out["guard_level"] = _safe_int(m.get("guard_level", 0))
            for ck in ("medal_color", "medalColor", "color"):
                v = m.get(ck)
                if isinstance(v, int) and v > 0:
                    out["color_main"] = _int_to_hex(v); break
                if isinstance(v, str) and v.startswith("#"):
                    out["color_main"] = _strip_alpha(v); break
            for ck in ("medal_color_border", "medalColorBorder", "border_color"):
                v = m.get(ck)
                if isinstance(v, int) and v > 0:
                    out["border_color"] = _int_to_hex(v); break
                if isinstance(v, str) and v.startswith("#"):
                    out["border_color"] = _strip_alpha(v); break
            for ck in ("medal_color_start", "medalColorStart", "start_color"):
                v = m.get(ck)
                if isinstance(v, int) and v > 0:
                    out["start_color"] = _int_to_hex(v); break
            for ck in ("medal_color_end", "medalColorEnd", "end_color"):
                v = m.get(ck)
                if isinstance(v, int) and v > 0:
                    out["end_color"] = _int_to_hex(v); break
            for ck in ("medal_color_level", "medalColorLevel", "text_color"):
                v = m.get(ck)
                if isinstance(v, int) and v > 0:
                    out["text_color"] = _int_to_hex(v); break
                if isinstance(v, str) and v.startswith("#"):
                    out["text_color"] = _strip_alpha(v); break
            if not out["color_main"]:
                out["color_main"] = out["bg_color"] or out["start_color"] or \
                                    out["border_color"] or ""
            if out["medal_name"]:
                return out
    arr = member.get("medal")
    if isinstance(arr, list) and len(arr) >= 2:
        out["medal_level"] = _safe_int(arr[0])
        out["medal_name"] = arr[1] if isinstance(arr[1], str) else ""
        for idx in (4, 5, 6, 8):
            if idx < len(arr):
                v = arr[idx]
                if isinstance(v, int) and v > 0:
                    if not out["color_main"]:
                        out["color_main"] = _int_to_hex(v)
                    elif not out["border_color"]:
                        out["border_color"] = _int_to_hex(v)
                    elif not out["start_color"]:
                        out["start_color"] = _int_to_hex(v)
                    elif not out["end_color"]:
                        out["end_color"] = _int_to_hex(v)
        if not out["color_main"] and out["border_color"]:
            out["color_main"] = out["border_color"]
    return out


def _extract_color_from_json_member(member):
    m = _extract_medal_from_json(member)
    return m.get("color_main", "")


def _parse_gift_v2_pb(pb_b64):
    out = {
        "uid": 0, "uname": "", "face": "", "name_color": "",
        "gift_id": 0, "gift_name": "", "num": 1,
        "price": 0, "coin_type": "", "batch_id": "", "action": "",
        "medal": {},
    }
    if not pb_b64:
        return out
    try:
        tree = decode_pb_safe(base64.b64decode(pb_b64))
    except Exception:
        return out
    out["uid"] = _pb_int(tree, 1) or 0
    out["uname"] = _pb_str(tree, 2) or ""
    out["face"] = _pb_str(tree, 3) or ""
    out["name_color"] = _pb_str(tree, 4) or ""
    gift = _pb_msg(tree, 10)
    if gift:
        out["gift_id"] = _pb_int(gift, 1) or 0
        out["gift_name"] = _pb_str(gift, 2) or ""
        for pf in (5, 6, 7):
            v = _pb_int(gift, pf)
            if v:
                out["price"] = v
                break
        out["coin_type"] = _pb_str(gift, 8) or ""
        out["batch_id"] = _pb_str(gift, 12) or ""
        out["action"] = _pb_str(gift, 18) or ""
    num = _pb_int(tree, 11)
    if not (0 < num <= 10000) and gift:
        for nf in (11, 13, 17, 4):
            n = _pb_int(gift, nf)
            if 0 < n <= 10000:
                num = n
                break
    out["num"] = num if num > 0 else 1
    if not out["uname"] or out["uname"].startswith("http"):
        un = _find_username(_all_strings(tree), face_url=out["face"])
        if un:
            out["uname"] = un
    if not out["gift_name"] and gift:
        for s in _all_strings(gift):
            if not s or s.startswith("http") or s.startswith("#"):
                continue
            if s == out["uname"] or s == out["face"]:
                continue
            if not (1 <= len(s) <= 20):
                continue
            if any(ord(c) > 127 for c in s):
                out["gift_name"] = s
                break
    if not out["face"]:
        for s in _all_strings(tree):
            if _is_face_url(s):
                out["face"] = s
                break
    out["medal"] = _find_medal_in_tree(tree) or {}
    return out


def _parse_notice_msg(json_obj):
    name = json_obj.get("name", "") or ""
    msg_common = json_obj.get("msg_common", "") or json_obj.get("msg_self", "") or ""
    if not msg_common:
        return None, None
    pk_kw = ["PK", "比赛", "对决", "逆转", "输掉", "赢得", "胜利", "获胜"]
    is_pk = any(kw in msg_common or kw in name for kw in pk_kw)
    if is_pk:
        return f"[PK通知] {name}: {msg_common}", "red"
    try:
        matches = re.findall(r'<%([^%]+)%>', msg_common)
        sender = matches[0].strip() if len(matches) > 0 else "未知"
        receiver = matches[1].strip() if len(matches) > 1 else "未知"
        rest = re.sub(r'<%[^%]+%>', '', msg_common)
        if "投喂" in rest:
            rest = rest.split("投喂", 1)[1]
        m = re.search(r'(\d+)个([^，,。！!\s]+)', rest)
        if m:
            count = m.group(1)
            gift_name = m.group(2)
        else:
            count = "1"
            gift_name = "礼物"
        return f"[礼物广播] {sender} 投喂 {receiver} {count}个{gift_name}", "dim"
    except Exception:
        return None, None


def _extract_pk_member(member):
    if not isinstance(member, dict):
        return {}
    core = member
    for wrap_key in ("user_info", "uinfo", "base", "info"):
        inner = member.get(wrap_key)
        if isinstance(inner, dict) and any(
                inner.get(k) for k in ("uid", "uname", "name", "face")):
            core = {**member, **inner}
            break
    uid = (_safe_int(core.get("uid", 0))
           or _safe_int(core.get("ruid", 0))
           or _safe_int(core.get("mid", 0)))
    room_id = (_safe_int(core.get("room_id", 0))
               or _safe_int(core.get("roomid", 0))
               or _safe_int(core.get("roomId", 0)))
    uname = (core.get("uname") or core.get("best_uname")
             or core.get("nickname") or core.get("name") or "")
    face = (core.get("face") or core.get("avatar")
            or core.get("user_face") or "")
    votes = (_safe_int(core.get("votes", 0))
             or _safe_int(core.get("golds", 0))
             or _safe_int(core.get("score", 0)))
    return {"uid": uid, "room_id": room_id, "uname": uname,
            "face": face, "votes": votes}


def _build_pk_update(my_room, my_info, oppo_info):
    mine = _extract_pk_member(my_info)
    oppo = _extract_pk_member(oppo_info)
    mine_color = ""
    oppo_color = ""
    if isinstance(my_info, dict):
        medal = _find_medal_in_tree(my_info)
        if medal and medal.get("color_main"):
            mine_color = medal["color_main"]
        if not mine_color:
            mine_color = _extract_medal_from_json(my_info).get("color_main", "")
        if not mine_color:
            mine_color = _extract_color_from_json_member(my_info)
    if isinstance(oppo_info, dict):
        medal = _find_medal_in_tree(oppo_info)
        if medal and medal.get("color_main"):
            oppo_color = medal["color_main"]
        if not oppo_color:
            oppo_color = _extract_medal_from_json(oppo_info).get("color_main", "")
        if not oppo_color:
            oppo_color = _extract_color_from_json_member(oppo_info)
    return {
        "active": True,
        "my_votes": mine.get("votes", 0),
        "my_name": mine.get("uname", ""),
        "my_uid": mine.get("uid", 0),
        "my_room_id": mine.get("room_id", 0),
        "my_face": mine.get("face", ""),
        "my_color": mine_color,
        "oppo_votes": oppo.get("votes", 0),
        "oppo_name": oppo.get("uname", ""),
        "oppo_uid": oppo.get("uid", 0),
        "oppo_room_id": oppo.get("room_id", 0),
        "oppo_face": oppo.get("face", ""),
        "oppo_color": oppo_color,
    }


def _handle_dm_interaction(d):
    data_str = d.get("data", "")
    if isinstance(data_str, str):
        try:
            data_obj = json.loads(data_str)
        except Exception:
            return None
    elif isinstance(data_str, dict):
        data_obj = data_str
    else:
        return None
    guide = ""
    content = ""
    cnt = 0
    combo = data_obj.get("combo", [])
    if isinstance(combo, list) and combo:
        c0 = combo[0]
        guide = c0.get("guide", "")
        content = c0.get("content", "")
        cnt = _safe_int(c0.get("cnt", 0))
    if content:
        if cnt > 1:
            return f"[连发弹幕] {guide}「{content}」×{cnt}"
        return f"[连发弹幕] {guide}「{content}」"
    return None


def _handle_guard_buy(d):
    lvl = {1: "总督", 2: "提督", 3: "舰长"}.get(
        _safe_int(d.get("guard_level", 0)), "大航海")
    uname = d.get("username", "未知")
    num = _safe_int(d.get("num", 1)) or 1
    if num > 1:
        return f"[上舰] {uname} 开通 {lvl} ×{num}"
    return f"[上舰] {uname} 开通 {lvl}"


def _handle_user_toast(d):
    lvl = {1: "总督", 2: "提督", 3: "舰长"}.get(
        _safe_int(d.get("guard_level", 0)), "大航海")
    uname = d.get("username", "未知")
    role = d.get("role_name", "") or lvl
    toast = d.get("toast_msg", "")
    if toast and isinstance(toast, str):
        clean = re.sub(r'<%[^%]+%>', '', toast)
        clean = re.sub(r'\s+', ' ', clean).strip()
        return f"[上舰] {clean}"
    return f"[上舰] {uname} 开通 {role}"


def _handle_send_gift(d):
    medal = _extract_medal_from_json(d)
    mn = medal.get("medal_name", "")
    ml = medal.get("medal_level", 0)
    mg = medal.get("guard_level", 0)
    mc = medal.get("color_main", "")
    prefix = _medal_prefix(mn, ml, mg)
    gift_name = d.get('giftName') or d.get('gift_name') or '礼物'
    num = _safe_int(d.get('num', 1)) or 1
    uname = d.get('uname') or '未知'
    action = d.get('action') or '投喂'
    output = f"[礼物] {prefix}{uname} {action} {gift_name} x{num}"
    color_info = None
    if mn and mc:
        color_info = {
            "uname": uname, "color_main": mc,
            "color_text": medal.get("text_color", "#FFFFFF"),
            "medal_name": mn, "medal_level": ml,
        }
    return output, color_info


def _handle_send_gift_v2(d):
    info = _parse_gift_v2_pb(d.get("pb", ""))
    uname = info.get("uname") or "未知"
    gift_name = info.get("gift_name") or "礼物"
    num = info.get("num", 1) or 1
    action = info.get("action") or "送出"
    medal = info.get("medal") or {}
    if medal.get("medal_name"):
        prefix = f"[{medal['medal_name']} {medal['medal_level']}] "
        output = f"[礼物] {prefix}{uname} {action} {gift_name} x{num}"
        color_info = {
            "uname": uname, "color_main": medal.get("color_main", ""),
            "color_text": medal.get("text_color", "#FFFFFF"),
            "medal_name": medal["medal_name"],
            "medal_level": medal["medal_level"],
        }
    else:
        output = f"[礼物] {uname} {action} {gift_name} x{num}"
        color_info = None
    return output, color_info


def _handle_super_chat(d):
    ui = d.get("user_info", {}) or {}
    price = d.get('price', 0)
    msg = d.get('message', '')
    uname = ui.get('uname', '未知')
    medal = _extract_medal_from_json(d)
    mn = medal.get("medal_name", "")
    prefix = f"[{mn} {medal.get('medal_level', 0)}] " if mn else ""
    return f"[SC] {prefix}{uname} 打赏 {price}元: {msg}"


def _handle_entry_effect(d):
    cw = d.get("copy_writing", "") or d.get("copy_writing_v2", "")
    uname = "未知"
    if cw:
        m = re.search(r'<%([^%]+)%>', cw)
        if m:
            uname = m.group(1).strip()
    if uname == "未知":
        ui = d.get("uinfo", {}) or {}
        uname = (ui.get("base", {}) or {}).get("name", "未知")
    return f"[入场] {uname}"


def _handle_gift_star(d):
    tip = d.get("tip", "")
    return f"[礼物星球] {tip}" if tip else "[礼物星球] 已点亮"


def _handle_online_rank_top3(d):
    lst = d.get("list", []) or []
    parts = []
    for it in lst:
        msg = it.get("msg", "")
        rank = _safe_int(it.get("rank", 0))
        clean = re.sub(r'<%[^%]+%>', '', msg).strip()
        if clean:
            parts.append(f"#{rank} {clean}")
    return "[高能榜前三] " + " | ".join(parts) if parts else None


def _handle_popularity_red_pocket_new(d):
    uname = d.get("uname", "未知")
    action = d.get("action", "送出")
    gift_name = d.get("gift_name", "红包")
    num = _safe_int(d.get("num", 1)) or 1
    price = _safe_int(d.get("price", 0)) or 0
    total = num * price
    medal = _extract_medal_from_json(d)
    mn = medal.get("medal_name", "")
    medal_str = f"[{mn} Lv{medal.get('medal_level', 0)}]" if mn else ""
    return (f"[人气红包] {uname} {action} {gift_name} x{num} "
            f"(总价值{total}) {medal_str}".strip())


def _handle_area_rank_changed(d):
    rank_name = d.get("rank_name", "分区")
    rank = _safe_int(d.get("rank", 0))
    if rank <= 0:
        return f"[{rank_name}] 未上榜"
    return f"[{rank_name}] 当前排名 #{rank}"


def _handle_room_change(d):
    title = d.get("title", "")
    area_name = d.get("area_name", "")
    parts = []
    if title:
        parts.append(f"标题: {title}")
    if area_name:
        parts.append(f"分区: {area_name}")
    return "[直播间信息] " + " · ".join(parts) if parts else None


def _handle_super_chat_entrance(d):
    status = _safe_int(d.get("status", 0))
    return "[SC入口] 已开启" if status == 1 else "[SC入口] 已关闭"


def _handle_play_together(d):
    action = d.get("action", "")
    message = d.get("message", "")
    cur = _safe_int(d.get("cur_fleet_num", 0))
    mx = _safe_int(d.get("max_fleet_num", 0))
    if message:
        return f"[一起玩] {message}"
    if action == "switch_off":
        return "[一起玩] 已关闭"
    return f"[一起玩] {action} ({cur}/{mx})"


def _handle_like_click(d):
    uname = d.get("uname", "未知")
    text = d.get("like_text", "")
    return f"[点赞] {uname} {text}".strip()


def _handle_watched_change(d):
    num = _safe_int(d.get("num", 0))
    large = d.get("text_large", "")
    if large:
        return f"[看过] {large}"
    return f"[看过] {num}"


# ============================================================
#  主动拉取：高能榜
# ============================================================
async def fetch_online_rank(room_id, ruid=0, page=1, page_size=100,
                             timeout=8, cookie_str=""):
    if not room_id or not ruid:
        return None, 0, ""
    if page < 1:
        page = 1
    if page_size < 1:
        page_size = 100
    items, total, tips = await _fetch_contribution_rank(
        room_id, ruid, page, page_size, timeout, cookie_str)
    if items is not None:
        return items, total, tips
    return await _fetch_online_gold_rank(
        room_id, ruid, page, page_size, timeout, cookie_str)


async def _fetch_contribution_rank(room_id, ruid, page, page_size,
                                     timeout, cookie_str):
    params = {
        "ruid": int(ruid), "room_id": int(room_id),
        "page": int(page), "page_size": int(page_size),
        "type": "online_rank", "switch": "contribution_rank",
        "platform": "web", "web_location": "444.8",
    }
    headers = {
        "User-Agent": _HTTP_UA,
        "Referer": f"https://live.bilibili.com/{room_id}",
        "Origin": "https://live.bilibili.com",
        "Accept": "*/*",
        "X-Requested-With": "mark.via",
    }
    if cookie_str:
        headers["Cookie"] = cookie_str
    try:
        timeout_obj = aiohttp.ClientTimeout(total=timeout)
        async with aiohttp.ClientSession(timeout=timeout_obj) as s:
            signed = await _wbi_sign(s, params)
            async with s.get(_CONTRIBUTION_RANK_API, params=signed,
                             headers=headers) as resp:
                data = await resp.json(content_type=None)
    except Exception as e:
        log(f"queryContributionRank 失败: {e}", "RANK", show=False)
        return None, 0, ""
    if not isinstance(data, dict) or data.get("code") != 0:
        return None, 0, ""
    d = data.get("data") or {}
    items_raw = d.get("item") or []
    total = _safe_int(d.get("count", 0))
    tips_text = ""
    try:
        cfg = d.get("config") or {}
        tips_text = cfg.get("value_text", "") or ""
    except Exception:
        pass
    if not tips_text:
        tips_text = d.get("count_text", "") or ""
    items = []
    for it in items_raw:
        if not isinstance(it, dict):
            continue
        face = it.get("face", "") or ""
        if face.startswith("http://"):
            face = "https://" + face[7:]
        medal = it.get("medal_info") or {}
        medal_name = ""
        medal_level = 0
        medal_guard = _safe_int(it.get("guard_level", 0))
        color_main = ""
        color_text = "#FFFFFF"
        color_border = ""
        if isinstance(medal, dict) and medal.get("medal_name"):
            medal_name = medal.get("medal_name", "") or ""
            medal_level = _safe_int(medal.get("level", 0))
            medal_guard = _safe_int(medal.get("guard_level", medal_guard))
            color_main = _int_to_hex(_safe_int(
                medal.get("medal_color_start", 0))) or "#FFFFFF"
            color_border = _int_to_hex(_safe_int(
                medal.get("medal_color_border", 0))) or color_main
            uinfo = it.get("uinfo") or {}
            uinfo_medal = (uinfo.get("medal")
                           if isinstance(uinfo, dict) else None)
            if isinstance(uinfo_medal, dict):
                if uinfo_medal.get("v2_medal_color_start"):
                    color_main = _strip_alpha(
                        uinfo_medal["v2_medal_color_start"])
                if uinfo_medal.get("v2_medal_color_border"):
                    color_border = _strip_alpha(
                        uinfo_medal["v2_medal_color_border"])
                if uinfo_medal.get("v2_medal_color_text"):
                    color_text = _strip_alpha(
                        uinfo_medal["v2_medal_color_text"])
        items.append({
            "uid": _safe_int(it.get("uid", 0)),
            "uname": it.get("name", "?") or "?",
            "face": face,
            "score": _safe_int(it.get("score", 0)),
            "rank": _safe_int(it.get("rank", 0)),
            "medal_name": medal_name,
            "medal_level": medal_level,
            "medal_guard": medal_guard,
            "medal_id": 0,
            "color_main": color_main,
            "color_sub": "",
            "color_text": color_text,
            "color_bg": "",
            "color_border": color_border,
        })
    if not items:
        return None, 0, ""
    return items, total, tips_text


async def _fetch_online_gold_rank(room_id, ruid, page, page_size,
                                    timeout, cookie_str):
    params = {"roomId": int(room_id), "ruid": int(ruid),
              "page": int(page), "pageSize": int(page_size)}
    headers = {
        "User-Agent": _HTTP_UA,
        "Referer": f"https://live.bilibili.com/{room_id}",
        "Origin": "https://live.bilibili.com",
        "Accept": "application/json, text/plain, */*",
    }
    if cookie_str:
        headers["Cookie"] = cookie_str
    try:
        timeout_obj = aiohttp.ClientTimeout(total=timeout)
        async with aiohttp.ClientSession(timeout=timeout_obj) as s:
            async with s.get(_ONLINE_RANK_API, params=params,
                             headers=headers) as resp:
                data = await resp.json(content_type=None)
    except Exception as e:
        log(f"getOnlineGoldRank 失败: {e}", "RANK", show=False)
        return None, 0, ""
    if not isinstance(data, dict) or data.get("code") != 0:
        return None, 0, ""
    d = data.get("data") or {}
    items_raw = d.get("OnlineRankItem") or []
    total = _safe_int(d.get("onlineNum", 0))
    tips_text = d.get("tips_text", "") or ""
    items = []
    for it in items_raw:
        if not isinstance(it, dict):
            continue
        face = it.get("face", "") or ""
        if face.startswith("http://"):
            face = "https://" + face[7:]
        medal_name = ""
        medal_level = 0
        medal_guard = 0
        color_main = ""
        color_text = "#FFFFFF"
        color_border = ""
        uinfo = it.get("uinfo") or {}
        uinfo_medal = uinfo.get("medal") if isinstance(uinfo, dict) else None
        if isinstance(uinfo_medal, dict) and uinfo_medal.get("name"):
            medal_name = uinfo_medal.get("name", "") or ""
            medal_level = _safe_int(uinfo_medal.get("level", 0))
            medal_guard = _safe_int(uinfo_medal.get("guard_level", 0))
            color_main = _strip_alpha(
                uinfo_medal.get("v2_medal_color_start", "")) or \
                _int_to_hex(_safe_int(uinfo_medal.get("color_start", 0)))
            color_border = _strip_alpha(
                uinfo_medal.get("v2_medal_color_border", "")) or \
                _int_to_hex(_safe_int(uinfo_medal.get("color_border", 0)))
            color_text = _strip_alpha(
                uinfo_medal.get("v2_medal_color_text", "")) or "#FFFFFF"
        if not medal_name:
            mi = it.get("medalInfo") or {}
            if isinstance(mi, dict) and mi.get("medalName"):
                medal_name = mi.get("medalName", "")
                medal_level = _safe_int(mi.get("level", 0))
                medal_guard = _safe_int(mi.get("guardLevel", 0))
                color_main = _int_to_hex(
                    _safe_int(mi.get("medalColorStart", 0)))
                color_border = _int_to_hex(
                    _safe_int(mi.get("medalColorBorder", 0)))
        items.append({
            "uid": _safe_int(it.get("uid", 0)),
            "uname": it.get("name", "?") or "?",
            "face": face,
            "score": _safe_int(it.get("score", 0)),
            "rank": _safe_int(it.get("userRank", 0)),
            "medal_name": medal_name,
            "medal_level": medal_level,
            "medal_guard": medal_guard,
            "medal_id": 0,
            "color_main": color_main,
            "color_sub": "",
            "color_text": color_text,
            "color_bg": "",
            "color_border": color_border,
        })
    return items, total, tips_text


# ============================================================
#  主动拉取：PK
# ============================================================
async def fetch_pk_info(room_id, pk_id=0, timeout=6, cookie_str=""):
    if not room_id:
        return None
    if not pk_id:
        pk_id = _get_pk_id(room_id)
    if not pk_id:
        return None
    params = {"pk_id": int(pk_id), "room_id": int(room_id), "pk_version": 2}
    headers = {
        "User-Agent": _HTTP_UA,
        "Referer": f"https://live.bilibili.com/{room_id}",
        "Origin": "https://live.bilibili.com",
        "Accept": "application/json, text/plain, */*",
    }
    if cookie_str:
        headers["Cookie"] = cookie_str
    try:
        timeout_obj = aiohttp.ClientTimeout(total=timeout)
        async with aiohttp.ClientSession(timeout=timeout_obj) as s:
            async with s.get(_PK_INFO_API, params=params,
                             headers=headers) as resp:
                data = await resp.json(content_type=None)
    except Exception as e:
        log(f"拉取 PK 信息失败: {e}", "PK", show=False)
        return None
    if not isinstance(data, dict) or data.get("code") != 0:
        return None
    d = data.get("data") or {}
    if not d:
        return None
    status = _safe_int(d.get("status", 0))
    if status and status not in _PK_ACTIVE_STATUS:
        _forget_pk_id(room_id)
        return None
    return _parse_pk_data(d, room_id)


# ============================================================
#  主动拉取：连麦
# ============================================================
async def fetch_universal_info(room_id, anchor_uid=0, session_id="",
                                timeout=8, cookie_str=""):
    if not room_id or not anchor_uid:
        return None
    if not session_id:
        session_id = _get_session_id(room_id)
    if not session_id:
        return None
    headers = {
        "User-Agent": _HTTP_UA,
        "Referer": f"https://live.bilibili.com/{room_id}",
        "Origin": "https://live.bilibili.com",
        "Accept": "*/*",
        "X-Requested-With": "mark.via",
    }
    if cookie_str:
        headers["Cookie"] = cookie_str
    base_params = {
        "biz_session_id": session_id,
        "room_id": int(room_id),
        "anchor_uid": int(anchor_uid),
        "web_location": "444.8",
    }
    try:
        timeout_obj = aiohttp.ClientTimeout(total=timeout)
        async with aiohttp.ClientSession(timeout=timeout_obj) as s:
            signed = await _wbi_sign(s, base_params)
            async with s.get(_UNIVERSAL_INFO_API, params=signed,
                             headers=headers) as resp:
                data = await resp.json(content_type=None)
    except Exception as e:
        log(f"拉取连麦信息失败: {e}", "UNIVERSAL", show=False)
        return None
    if not isinstance(data, dict) or data.get("code") != 0:
        return None
    d = data.get("data") or {}
    if not d:
        return None
    session_status = _safe_int(d.get("session_status", 0))
    if session_status and session_status != 1:
        _forget_session_id(room_id)
        return None
    return _parse_universal_data(d, room_id)


def _parse_universal_data(d, my_room_id):
    if not isinstance(d, dict):
        return None
    my_room_id = _safe_int(my_room_id)
    members = d.get("members") or []
    if not isinstance(members, list) or len(members) < 1:
        return None
    my_member = None
    for m in members:
        if not isinstance(m, dict):
            continue
        if my_room_id and _safe_int(m.get("room_id", 0)) == my_room_id:
            my_member = m
            break
    if my_member is None:
        try:
            sorted_members = sorted(
                [m for m in members if isinstance(m, dict)],
                key=lambda x: _safe_int(x.get("position", 999)))
            if sorted_members:
                my_member = sorted_members[0]
        except Exception:
            my_member = members[0] if members else None
    if my_member is None:
        return None

    def _extract_member(m):
        if not isinstance(m, dict):
            return {}
        uid = _safe_int(m.get("uid", 0))
        room_id = _safe_int(m.get("room_id", 0))
        uname = m.get("uname", "") or ""
        face = m.get("face", "") or ""
        if face.startswith("http://"):
            face = "https://" + face[7:]
        votes = 0
        votes_text = "0"
        bed = m.get("biz_extra_data") or {}
        if isinstance(bed, dict):
            mc = bed.get("multi_conn") or {}
            if isinstance(mc, dict):
                votes = _safe_int(mc.get("price", 0))
                votes_text = mc.get("price_text", "0") or "0"
        return {"uid": uid, "room_id": room_id, "uname": uname,
                "face": face, "votes": votes, "votes_text": votes_text}

    mine = _extract_member(my_member)
    oppo = None
    for m in members:
        if m is my_member or not isinstance(m, dict):
            continue
        cur_votes = _safe_int(
            ((m.get("biz_extra_data") or {}).get("multi_conn") or {})
            .get("price", 0))
        if oppo is None:
            oppo = m
            continue
        oppo_votes = _safe_int(
            ((oppo.get("biz_extra_data") or {}).get("multi_conn") or {})
            .get("price", 0))
        if cur_votes > oppo_votes:
            oppo = m
    if oppo is None:
        oppo = {}
    oppo_extracted = _extract_member(oppo)

    members_out = []
    for m in members:
        if not isinstance(m, dict):
            continue
        face = m.get("face", "") or ""
        if face.startswith("http://"):
            face = "https://" + face[7:]
        votes = 0
        votes_text = "0"
        bed = m.get("biz_extra_data") or {}
        if isinstance(bed, dict):
            mc = bed.get("multi_conn") or {}
            if isinstance(mc, dict):
                votes = _safe_int(mc.get("price", 0))
                votes_text = mc.get("price_text", "0") or "0"
        members_out.append({
            "uid": _safe_int(m.get("uid", 0)),
            "room_id": _safe_int(m.get("room_id", 0)),
            "uname": m.get("uname", "") or "",
            "face": face,
            "position": _safe_int(m.get("position", 0)),
            "votes": votes,
            "votes_text": votes_text,
            "display_name": m.get("display_name", "") or "",
        })

    return {
        "active": True,
        "my_votes": mine.get("votes", 0),
        "my_name": mine.get("uname", ""),
        "my_uid": mine.get("uid", 0),
        "my_room_id": mine.get("room_id", 0),
        "my_face": mine.get("face", ""),
        "my_color": "",
        "oppo_votes": oppo_extracted.get("votes", 0),
        "oppo_name": oppo_extracted.get("uname", ""),
        "oppo_uid": oppo_extracted.get("uid", 0),
        "oppo_room_id": oppo_extracted.get("room_id", 0),
        "oppo_face": oppo_extracted.get("face", ""),
        "oppo_color": "",
        "members": members_out,
        "session_id": d.get("biz_session_id", "") or "",
    }


def _parse_pk_data(d, my_room_id):
    if not isinstance(d, dict):
        return None
    my_room_id = _safe_int(my_room_id)
    init_info = d.get("init_info") or {}
    match_info = d.get("match_info") or {}
    if init_info or match_info:
        init_room = _safe_int(init_info.get("room_id", 0))
        match_room = _safe_int(match_info.get("room_id", 0))
        if my_room_id and match_room == my_room_id:
            return _build_pk_update(my_room_id, match_info, init_info)
        elif my_room_id and init_room == my_room_id:
            return _build_pk_update(my_room_id, init_info, match_info)
        else:
            return _build_pk_update(my_room_id, match_info, init_info)
    members = d.get("members") or []
    if isinstance(members, list) and len(members) >= 1:
        my_member = None
        for m in members:
            if not isinstance(m, dict):
                continue
            if _safe_int(m.get("room_id", 0)) == my_room_id:
                my_member = m
                break
        if my_member is None:
            my_member = members[0]
        oppo_member = None
        for m in members:
            if m is my_member or not isinstance(m, dict):
                continue
            if oppo_member is None:
                oppo_member = m
                continue
            cur_v = _safe_int(m.get("votes", m.get("score", 0)))
            oppo_v = _safe_int(oppo_member.get("votes",
                                                oppo_member.get("score", 0)))
            if cur_v > oppo_v:
                oppo_member = m
        return _build_pk_update(my_room_id, my_member, oppo_member or {})
    if "my_uid" in d or "oppo_uid" in d:
        payload = {
            "active": True,
            "my_votes": _safe_int(d.get("my_votes", d.get("my_score", 0))),
            "my_name": d.get("my_name", d.get("my_uname", "")),
            "my_uid": _safe_int(d.get("my_uid", 0)),
            "my_room_id": _safe_int(d.get("my_room_id", 0)),
            "my_face": d.get("my_face", ""),
            "my_color": d.get("my_color", ""),
            "oppo_votes": _safe_int(d.get("oppo_votes",
                                            d.get("oppo_score", 0))),
            "oppo_name": d.get("oppo_name", d.get("oppo_uname", "")),
            "oppo_uid": _safe_int(d.get("oppo_uid", 0)),
            "oppo_room_id": _safe_int(d.get("oppo_room_id", 0)),
            "oppo_face": d.get("oppo_face", ""),
            "oppo_color": d.get("oppo_color", ""),
        }
        if payload["my_uid"] or payload["oppo_uid"]:
            return payload
    return None


# ============================================================
#  主动拉取：看过人数
# ============================================================
async def fetch_watched_count(room_id, timeout=8, cookie_str=""):
    """主动拉取"看过人数"。

    依次尝试：
      1. getRoomBaseInfo（无需 Wbi）
      2. getInfoByRoom（需要 Wbi 签名）

    返回 (num, text_large)，失败返回 (None, "")。
    """
    if not room_id:
        return None, ""

    headers = {
        "User-Agent": _HTTP_UA,
        "Referer": f"https://live.bilibili.com/{room_id}",
        "Origin": "https://live.bilibili.com",
        "Accept": "application/json, text/plain, */*",
    }
    if cookie_str:
        headers["Cookie"] = cookie_str

    timeout_obj = aiohttp.ClientTimeout(total=timeout)

    # 尝试 1：getRoomBaseInfo（不需要 Wbi 签名）
    try:
        async with aiohttp.ClientSession(timeout=timeout_obj) as s:
            params = {
                "room_ids": str(room_id),
                "req_biz": "web_room_componet",
            }
            async with s.get(
                "https://api.live.bilibili.com/xlive/web-room/v1/index/"
                "getRoomBaseInfo",
                params=params, headers=headers) as resp:
                data = await resp.json(content_type=None)
            if isinstance(data, dict) and data.get("code") == 0:
                d = data.get("data") or {}
                info = None
                if isinstance(d.get("by_room_ids"), dict):
                    info = d["by_room_ids"].get(str(room_id))
                if info is None and str(room_id) in d:
                    info = d.get(str(room_id))
                if isinstance(info, dict):
                    ws = info.get("watched_show") or {}
                    num = _safe_int(ws.get("num", 0))
                    text = ws.get("text_large", "") or ""
                    if num > 0 or text:
                        return num, text
    except Exception as e:
        log(f"getRoomBaseInfo 失败: {e}", "WATCHED", show=False)

    # 尝试 2：getInfoByRoom（需要 Wbi 签名）
    try:
        async with aiohttp.ClientSession(timeout=timeout_obj) as s:
            signed = await _wbi_sign(s, {"room_id": int(room_id)})
            async with s.get(
                "https://api.live.bilibili.com/xlive/web-room/v1/index/"
                "getInfoByRoom",
                params=signed, headers=headers) as resp:
                data = await resp.json(content_type=None)
            if isinstance(data, dict) and data.get("code") == 0:
                d = data.get("data") or {}
                ws = d.get("watched_show") or {}
                num = _safe_int(ws.get("num", 0))
                text = ws.get("text_large", "") or ""
                if num > 0 or text:
                    return num, text
    except Exception as e:
        log(f"getInfoByRoom 失败: {e}", "WATCHED", show=False)

    return None, ""


def parse_one(json_obj, silent=False, room_id=None, pk_callback=None):
    cmd = json_obj.get("cmd")
    res = {"cmd": cmd or "", "output": "", "style": None,
           "status": [], "continue": False, "color_info": None}
    if not cmd or cmd not in IMPORTANT_CMDS:
        return res

    output = ""
    style = None
    status = []
    color_info = None

    if cmd == "DANMU_MSG" and "info" in json_obj:
        info = json_obj["info"]
        text = info[1] if len(info) > 1 and isinstance(info[1], str) else ""
        uname = "未知"
        if len(info) > 2 and isinstance(info[2], list) and len(info[2]) > 1:
            if isinstance(info[2][1], str):
                uname = info[2][1]
        mn = ""
        ml = 0
        gl = 0
        medal_color = ""
        if len(info) > 3 and isinstance(info[3], list):
            m = info[3]
            if len(m) > 0:
                ml = _safe_int(m[0])
            if len(m) > 1 and isinstance(m[1], str) and m[1]:
                mn = m[1]
            for idx in (4, 5, 6, 7):
                if idx < len(m) and isinstance(m[idx], int) and m[idx] > 0:
                    c = _int_to_hex(m[idx])
                    if not medal_color:
                        medal_color = c
            for i2 in (10, 12, 15):
                if len(m) > i2 and isinstance(m[i2], int) and 1 <= m[i2] <= 3:
                    gl = m[i2]
                    break
        emoticon_url = None
        if len(info) > 0 and isinstance(info[0], list):
            for item in info[0]:
                if isinstance(item, dict):
                    if "url" in item and "emoticon_unique" in item:
                        emoticon_url = item.get("url")
                        break
        prefix = _medal_prefix(mn, ml, gl)
        output = f"[弹幕] {prefix}{uname}: {text}"
        if mn and medal_color:
            style = "medal"
            color_info = {
                "uname": uname,
                "color_main": medal_color,
                "color_text": "#FFFFFF",
                "medal_name": mn,
                "medal_level": ml,
            }
        else:
            style = "white"
        if emoticon_url:
            output += f" [表情: {emoticon_url}]"
        status.append(("danmu_add", 1))
        if not silent:
            log(f"弹幕 {uname}: {text[:60]}", "DANMU",
                show=False, room_id=room_id)

    elif cmd == "DM_INTERACTION" and "data" in json_obj:
        out = _handle_dm_interaction(json_obj["data"])
        if out:
            output = out
            style = "cyan"

    elif cmd == "SEND_GIFT" and "data" in json_obj:
        output, color_info = _handle_send_gift(json_obj["data"])
        style = "medal" if color_info else "yellow"
        status.append(("gift_add", 1))
        if not silent:
            log(output, "GIFT", show=False, room_id=room_id)

    elif cmd == "SEND_GIFT_V2" and "data" in json_obj:
        output, color_info = _handle_send_gift_v2(json_obj["data"])
        style = "medal" if color_info else "yellow"
        status.append(("gift_add", 1))
        if not silent:
            log(output, "GIFT", show=False, room_id=room_id)

    elif cmd in ("SUPER_CHAT_MESSAGE", "SUPER_CHAT_MESSAGE_JPN") and \
            "data" in json_obj:
        d = json_obj["data"]
        output = _handle_super_chat(d)
        style = "magenta"
        status.append(("sc_add", 1))
        if not silent:
            log(output, "SC", room_id=room_id)

    elif cmd == "SUPER_CHAT_ENTRANCE" and "data" in json_obj:
        out = _handle_super_chat_entrance(json_obj["data"])
        if out:
            output = out
            style = "dim"

    elif cmd == "GUARD_BUY" and "data" in json_obj:
        output = _handle_guard_buy(json_obj["data"])
        style = "green"
        if not silent:
            log(output, "GUARD", room_id=room_id)

    elif cmd == "USER_TOAST_MSG" and "data" in json_obj:
        output = _handle_user_toast(json_obj["data"])
        style = "green"

    elif cmd == "GUARD_HONOR_THOUSAND" and "data" in json_obj:
        d = json_obj["data"]
        add_list = d.get("add", [])
        del_list = d.get("del", [])
        parts = []
        if add_list:
            parts.append(f"新增 {len(add_list)} 位")
        if del_list:
            parts.append(f"移除 {len(del_list)} 位")
        output = "[千舰荣耀] " + "，".join(parts) if parts else "[千舰荣耀] 无变化"
        style = "magenta"

    elif cmd == "COMBO_SEND" and "data" in json_obj:
        d = json_obj["data"]
        uname = d.get('uname', '未知')
        gift_name = d.get('gift_name') or d.get('giftName') or '礼物'
        combo = d.get('combo_num', 0) or d.get('total_num', 0) or 1
        medal = _extract_medal_from_json(d)
        mn = medal.get("medal_name", "")
        prefix = f"[{mn} {medal.get('medal_level', 0)}] " if mn else ""
        output = f"[礼物连击] {prefix}{uname} 送出 {gift_name} x{combo}"
        style = "yellow"
        if mn and medal.get("color_main"):
            style = "medal"
            color_info = {
                "uname": uname,
                "color_main": medal.get("color_main", ""),
                "color_text": medal.get("text_color", "#FFFFFF"),
                "medal_name": mn,
                "medal_level": medal.get("medal_level", 0),
            }
        status.append(("gift_add", 1))

    elif cmd == "GIFT_STAR_PROCESS" and "data" in json_obj:
        out = _handle_gift_star(json_obj["data"])
        if out:
            output = out
            style = "yellow"

    elif cmd == "WIDGET_GIFT_STAR_PROCESS_V2" and "data" in json_obj:
        d = json_obj["data"]
        output = (f"[{d.get('name','未知活动')}] 进度: "
                  f"{d.get('cur_num',0)}/{d.get('total_num',0)}")
        style = "cyan"

    elif cmd == "PK_INFO" and "data" in json_obj:
        d = json_obj["data"]
        pk_id_in_msg = _safe_int(d.get("pk_id", 0))
        if pk_id_in_msg:
            _remember_pk_id(room_id, pk_id_in_msg)
        sid = d.get("biz_session_id") or d.get("session_id") or ""
        if sid:
            _remember_session_id(room_id, sid)
        payload = _parse_pk_data(d, room_id)
        if payload:
            if sid and "session_id" not in payload:
                payload["session_id"] = sid
            if pk_callback:
                pk_callback("update", payload)
        res["continue"] = True
        return res

    elif cmd in PK_EVENT_MAP:
        d = json_obj.get("data", {}) or {}
        pk_id_in_msg = _safe_int(d.get("pk_id", 0))
        if cmd in ("PK_BATTLE_START", "PK_BATTLE_START_NEW",
                   "PK_BATTLE_PROCESS", "PK_BATTLE_PROCESS_NEW"):
            if pk_id_in_msg:
                _remember_pk_id(room_id, pk_id_in_msg)
        elif cmd in ("PK_BATTLE_END",
                     "PK_BATTLE_SETTLE",
                     "PK_BATTLE_SETTLE_NEW",
                     "PK_BATTLE_PUNISH_END"):
            _forget_pk_id(room_id)
        if pk_callback:
            if cmd in ("PK_BATTLE_START", "PK_BATTLE_START_NEW"):
                init_info = d.get("init_info", {}) or {}
                match_info = d.get("match_info", {}) or {}
                my_rid = _safe_int(room_id) if room_id else 0
                init_room = _safe_int(init_info.get("room_id", 0))
                match_room = _safe_int(match_info.get("room_id", 0))
                if my_rid and match_room == my_rid:
                    payload = _build_pk_update(room_id,
                                                match_info, init_info)
                elif my_rid and init_room == my_rid:
                    payload = _build_pk_update(room_id,
                                                init_info, match_info)
                else:
                    payload = _build_pk_update(room_id,
                                                match_info, init_info)
                log(f"PK_START payload={payload}", "PK",
                    show=False, room_id=room_id)
                pk_callback("start", payload)
                res["continue"] = True
                return res
            elif cmd in ("PK_BATTLE_END",
                         "PK_BATTLE_SETTLE",
                         "PK_BATTLE_SETTLE_NEW",
                         "PK_BATTLE_PUNISH_END"):
                pk_callback("end", None)
            elif cmd in ("PK_BATTLE_PROCESS", "PK_BATTLE_PROCESS_NEW"):
                init_info = d.get("init_info", {}) or {}
                match_info = d.get("match_info", {}) or {}
                my_rid = _safe_int(room_id) if room_id else 0
                init_room = _safe_int(init_info.get("room_id", 0))
                match_room = _safe_int(match_info.get("room_id", 0))
                if my_rid and match_room == my_rid:
                    payload = _build_pk_update(room_id,
                                                match_info, init_info)
                elif my_rid and init_room == my_rid:
                    payload = _build_pk_update(room_id,
                                                init_info, match_info)
                else:
                    payload = _build_pk_update(room_id,
                                                match_info, init_info)
                pk_callback("update", payload)
                res["continue"] = True
                return res
        output = f"[{PK_EVENT_MAP[cmd]}]"
        style = "red"
        if "PK_BATTLE_SETTLE" in cmd:
            dmscore = d.get("dmscore", 0)
            if dmscore:
                output += f" 积分: {dmscore}"

    elif cmd in ("PK_BATTLE_PRE", "PK_BATTLE_PRE_NEW"):
        d = json_obj.get("data", {}) or {}
        uname = d.get("uname", "未知")
        output = f"[PK准备] 对手: {uname}"
        style = "cyan"
        if pk_callback:
            pk_callback("pre", {
                "oppo_name": uname,
                "oppo_uid": _safe_int(d.get("uid", 0)),
                "oppo_room_id": _safe_int(d.get("room_id", 0)),
                "oppo_face": d.get("face", ""),
                "oppo_color": _extract_color_from_json_member(d),
            })

    elif cmd == "PK_BATTLE_VIDEO_PUNISH_BEGIN":
        d = json_obj.get("data", {}) or {}
        init = d.get("init_info", {}) or {}
        match = d.get("match_info", {}) or {}
        winner = (init.get("best_uname")
                  if init.get("winner_type") == 2
                  else match.get("best_uname"))
        output = f"[PK惩罚] 开始惩罚，胜方: {winner or '未知'}"
        style = "red"

    elif cmd == "PK_WIDGET" and "data" in json_obj:
        d = json_obj["data"]
        if d.get("title") and d.get("text"):
            output = f"[PK段位] {d['title']}: {d['text']}"
            style = "red"

    elif cmd == "PK_BATTLE_ENTRANCE" and "data" in json_obj:
        d = json_obj["data"]
        is_open = d.get("is_open", False)
        output = f"[PK入口] {'已开启' if is_open else '已关闭'}"
        style = "cyan"

    elif cmd == "UNIVERSAL_EVENT_GIFT_V2" and "data" in json_obj:
        d = json_obj["data"]
        sid = d.get("biz_session_id") or d.get("session_id") or ""
        if sid:
            _remember_session_id(room_id, sid)
        members = d.get("members", [])
        members_out = []
        for m in members:
            if not isinstance(m, dict):
                continue
            face = m.get("face", "") or ""
            if face.startswith("http://"):
                face = "https://" + face[7:]
            votes = 0
            votes_text = "0"
            bed = m.get("biz_extra_data") or {}
            if isinstance(bed, dict):
                mc = bed.get("multi_conn") or {}
                if isinstance(mc, dict):
                    votes = _safe_int(mc.get("price", 0))
                    votes_text = mc.get("price_text", "0") or "0"
            members_out.append({
                "uid": _safe_int(m.get("uid", 0)),
                "room_id": _safe_int(m.get("room_id", 0)),
                "uname": m.get("uname", "") or "",
                "face": face,
                "position": _safe_int(m.get("position", 0)),
                "votes": votes,
                "votes_text": votes_text,
                "display_name": m.get("display_name", "") or "",
            })
        if len(members) >= 2:
            my_member = None
            oppo_member = None
            for m in members:
                if _safe_int(m.get("room_id", 0)) == room_id:
                    my_member = m
                elif oppo_member is None:
                    oppo_member = m
            if not my_member and not oppo_member:
                my_member, oppo_member = members[0], members[1]
            if my_member and oppo_member:
                me = (my_member.get("biz_extra_data") or {}).get(
                    "multi_conn", {}) or {}
                op = (oppo_member.get("biz_extra_data") or {}).get(
                    "multi_conn", {}) or {}
                my_price = me.get("price", 0)
                oppo_price = op.get("price", 0)
                output = (f"[连麦投喂] {my_member.get('uname','我')} "
                          f"({me.get('price_text','0')}) vs "
                          f"{oppo_member.get('uname','对手')} "
                          f"({op.get('price_text','0')})")
                style = "yellow"
                if pk_callback:
                    pk_callback("update", {
                        "active": True,
                        "my_votes": my_price,
                        "my_name": my_member.get("uname", ""),
                        "my_uid": _safe_int(my_member.get("uid", 0)),
                        "my_room_id": _safe_int(my_member.get("room_id", 0)),
                        "my_face": my_member.get("face", ""),
                        "my_color": _extract_color_from_json_member(my_member),
                        "oppo_votes": oppo_price,
                        "oppo_name": oppo_member.get("uname", ""),
                        "oppo_uid": _safe_int(oppo_member.get("uid", 0)),
                        "oppo_room_id": _safe_int(oppo_member.get("room_id", 0)),
                        "oppo_face": oppo_member.get("face", ""),
                        "oppo_color": _extract_color_from_json_member(oppo_member),
                        "members": members_out,
                        "session_id": sid,
                    })
        res["continue"] = True
        return res

    elif cmd == "UNIVERSAL_EVENT_GIFT" and "data" in json_obj:
        d = json_obj["data"]
        sid = d.get("biz_session_id") or d.get("session_id") or ""
        if sid:
            _remember_session_id(room_id, sid)
        members = d.get("members", [])
        members_out = []
        for m in members:
            if not isinstance(m, dict):
                continue
            face = m.get("face", "") or ""
            if face.startswith("http://"):
                face = "https://" + face[7:]
            votes = 0
            votes_text = "0"
            bed = m.get("biz_extra_data") or {}
            if isinstance(bed, dict):
                mc = bed.get("multi_conn") or {}
                if isinstance(mc, dict):
                    votes = _safe_int(mc.get("price", 0))
                    votes_text = mc.get("price_text", "0") or "0"
            members_out.append({
                "uid": _safe_int(m.get("uid", 0)),
                "room_id": _safe_int(m.get("room_id", 0)),
                "uname": m.get("uname", "") or "",
                "face": face,
                "position": _safe_int(m.get("position", 0)),
                "votes": votes,
                "votes_text": votes_text,
                "display_name": m.get("display_name", "") or "",
            })
        scores = (d.get("multi_conn_info", {}) or {}).get("scores", [])
        if len(members) >= 2:
            my_member = None
            oppo_member = None
            for m in members:
                if _safe_int(m.get("room_id", 0)) == room_id:
                    my_member = m
                elif oppo_member is None:
                    oppo_member = m
            if not my_member and not oppo_member:
                my_member, oppo_member = members[0], members[1]
            if my_member and oppo_member:
                my_price = 0
                oppo_price = 0
                my_text = "0"
                oppo_text = "0"
                my_uid = _safe_int(my_member.get("uid", 0))
                oppo_uid = _safe_int(oppo_member.get("uid", 0))
                for s in scores:
                    if _safe_int(s.get("uid", 0)) == my_uid:
                        my_price = s.get("price", 0)
                        my_text = s.get("price_text", "0")
                    elif _safe_int(s.get("uid", 0)) == oppo_uid:
                        oppo_price = s.get("price", 0)
                        oppo_text = s.get("price_text", "0")
                output = (f"[连麦投喂] {my_member.get('uname','我')} ({my_text}) "
                          f"vs {oppo_member.get('uname','对手')} ({oppo_text})")
                style = "yellow"
                if pk_callback:
                    pk_callback("update", {
                        "active": True,
                        "my_votes": my_price,
                        "my_name": my_member.get("uname", ""),
                        "my_uid": my_uid,
                        "my_room_id": _safe_int(my_member.get("room_id", 0)),
                        "my_face": my_member.get("face", ""),
                        "my_color": _extract_color_from_json_member(my_member),
                        "oppo_votes": oppo_price,
                        "oppo_name": oppo_member.get("uname", ""),
                        "oppo_uid": oppo_uid,
                        "oppo_room_id": _safe_int(oppo_member.get("room_id", 0)),
                        "oppo_face": oppo_member.get("face", ""),
                        "oppo_color": _extract_color_from_json_member(oppo_member),
                        "members": members_out,
                        "session_id": sid,
                    })
        res["continue"] = True
        return res

    elif cmd == "WATCHED_CHANGE" and "data" in json_obj:
        out = _handle_watched_change(json_obj["data"])
        if out:
            output = out
            style = "dim"
            status.append(("watched", _safe_int(
                json_obj["data"].get("num", 0))))
        res["status"] = status
        res["output"] = output
        res["style"] = style
        return res

    elif cmd == "ONLINE_RANK_COUNT" and "data" in json_obj:
        d = json_obj["data"]
        status.append(("rank", d.get("count", 0)))
        res["status"] = status
        res["continue"] = True
        return res

    elif cmd == "ONLINE_RANK_V2" and "data" in json_obj:
        d = json_obj["data"]
        lst = d.get("list", []) or []
        items = []
        for it in lst:
            face = it.get("face", "") or ""
            if face.startswith("http://"):
                face = "https://" + face[7:]
            medal = _extract_medal_from_json(it)
            items.append({
                "uid": _safe_int(it.get("uid", 0)),
                "uname": it.get("uname", "?") or "?",
                "face": face,
                "score": _safe_int(it.get("score", 0)),
                "rank": _safe_int(it.get("rank", 0)),
                "medal_name": medal.get("medal_name", ""),
                "medal_level": medal.get("medal_level", 0),
                "medal_guard": _safe_int(it.get("guard_level", 0)),
                "medal_id": medal.get("medal_id", 0),
                "color_main": medal.get("color_main", ""),
                "color_sub": medal.get("color_sub", ""),
                "color_text": medal.get("text_color", "#FFFFFF"),
                "color_bg": medal.get("bg_color", ""),
                "color_border": medal.get("border_color", ""),
            })
        if items:
            status.append(("rank_list", items))
        res["status"] = status
        res["continue"] = True
        return res

    elif cmd == "ONLINE_RANK_V3" and "data" in json_obj:
        pb_data = json_obj["data"].get("pb")
        if pb_data:
            try:
                decoded = decode_pb_safe(base64.b64decode(pb_data))
                ranks = decoded.get(3, [])
                if not isinstance(ranks, list):
                    ranks = [ranks]
                items = []
                for rank_item in ranks:
                    if not isinstance(rank_item, dict):
                        continue
                    msg = rank_item.get("message", rank_item)
                    uid = _first_int(msg.get(1, [])) if 1 in msg else 0
                    uname = ""
                    if 4 in msg:
                        s = _first_string(msg[4])
                        if _is_valid_name(s):
                            uname = s
                    if not uname:
                        uname = "?"
                    face = ""
                    if 2 in msg:
                        s = _first_string(msg[2], want_url=True)
                        if s:
                            face = s
                    if face.startswith("http://"):
                        face = "https://" + face[7:]
                    medal = _find_medal_in_tree(msg) or {}
                    items.append({
                        "uid": uid,
                        "uname": uname,
                        "face": face,
                        "score": 0,
                        "rank": 0,
                        "medal_name": medal.get("medal_name", ""),
                        "medal_level": medal.get("medal_level", 0),
                        "medal_guard": 0,
                        "medal_id": medal.get("medal_id", 0),
                        "color_main": medal.get("color_main", ""),
                        "color_sub": medal.get("color_sub", ""),
                        "color_text": medal.get("text_color", "#FFFFFF"),
                        "color_bg": medal.get("bg_color", ""),
                        "color_border": medal.get("border_color", ""),
                    })
                if items:
                    status.append(("rank_list", items))
            except Exception as e:
                log(f"ONLINE_RANK_V3 解析异常: {e}", "RANK", show=False)
        res["status"] = status
        res["continue"] = True
        return res

    elif cmd == "ONLINE_RANK_TOP3" and "data" in json_obj:
        out = _handle_online_rank_top3(json_obj["data"])
        if out:
            output = out
            style = "magenta"
        res["output"] = output
        res["style"] = style
        res["continue"] = True
        return res

    elif cmd == "ROOM_REAL_TIME_MESSAGE_UPDATE" and "data" in json_obj:
        d = json_obj["data"]
        status.append(("fans", d.get("fans", 0)))
        res["status"] = status
        res["continue"] = True
        return res

    elif cmd == "ROOM_CHANGE" and "data" in json_obj:
        out = _handle_room_change(json_obj["data"])
        if out:
            output = out
            style = "cyan"
            if not silent:
                log(out, "ROOM", room_id=room_id)

    elif cmd in ("LIVE", "PREPARING"):
        status.append(("live_status", "直播中" if cmd == "LIVE" else "未开播"))
        output = f"[状态] {cmd}"
        style = "cyan"
        if not silent:
            log(f"直播状态变更: {cmd}", "ROOM", room_id=room_id)

    elif cmd == "INTERACT_WORD" and "data" in json_obj:
        d = json_obj["data"]
        uname = (d.get("uname")
                 or (d.get("uinfo", {}) or {}).get("base", {}).get("name", "")
                 or "未知")
        msg_type = _safe_int(d.get("msg_type", 1))
        medal = _extract_medal_from_json(d)
        action = {0: "进入", 1: "进入", 2: "关注", 3: "分享"}.get(
            msg_type, f"互动({msg_type})")
        if medal.get("medal_name"):
            output = (f"[互动] [{medal['medal_name']} {medal['medal_level']}] "
                      f"{uname} {action}")
            style = "medal"
            color_info = {
                "uname": uname,
                "color_main": medal.get("color_main", ""),
                "color_text": medal.get("text_color", "#FFFFFF"),
                "medal_name": medal["medal_name"],
                "medal_level": medal["medal_level"],
            }
        else:
            output = f"[互动] {uname} {action}"
            style = "cyan"
        if not silent:
            log(f"互动 {uname} {action}", "INTERACT",
                show=False, room_id=room_id)

    elif cmd == "INTERACT_WORD_V2" and "data" in json_obj:
        d = json_obj["data"]
        uname = d.get("uname", "未知")
        msg_type = 1
        medal = {}
        pb_data = d.get("pb")
        if pb_data:
            try:
                decoded = decode_pb_safe(base64.b64decode(pb_data))
                s = _pb_str(decoded, 2)
                if _is_valid_name(s):
                    uname = s
                t = _pb_int(decoded, 5)
                if 0 <= t <= 10:
                    msg_type = t
                medal = _find_medal_in_tree(decoded) or {}
            except Exception:
                pass
        if not medal.get("medal_name"):
            medal = _extract_medal_from_json(d)
        action = {0: "进入", 1: "进入", 2: "关注", 3: "分享"}.get(
            msg_type, f"互动({msg_type})")
        if medal.get("medal_name"):
            output = (f"[互动] [{medal['medal_name']} {medal['medal_level']}] "
                      f"{uname} {action}")
            style = "medal"
            color_info = {
                "uname": uname,
                "color_main": medal.get("color_main", ""),
                "color_text": medal.get("text_color", "#FFFFFF"),
                "medal_name": medal["medal_name"],
                "medal_level": medal["medal_level"],
            }
        else:
            output = f"[互动] {uname} {action}"
            style = "cyan"
        if not silent:
            log(f"互动 {uname} {action}", "INTERACT",
                show=False, room_id=room_id)

    elif cmd in ("ENTRY_EFFECT", "ENTRY_EFFECT_MUST_RECEIVE") and \
            "data" in json_obj:
        output = _handle_entry_effect(json_obj["data"])
        style = "green"
        if not silent:
            log(output, "ENTRY", show=False, room_id=room_id)

    elif cmd == "LIKE_INFO_V3_UPDATE":
        cnt = json_obj.get('data', {}).get('click_count', 0)
        output = f"[点赞] {cnt}"
        style = "magenta"

    elif cmd == "LIKE_INFO_V3_CLICK":
        out = _handle_like_click(json_obj.get("data", {}))
        if out:
            output = out
            style = "magenta"

    elif cmd == "SYS_MSG":
        msg = json_obj.get("msg", "")
        if msg:
            output = f"[系统消息] {msg}"
            style = "yellow"

    elif cmd == "NOTICE_MSG":
        out, st = _parse_notice_msg(json_obj)
        if out and not silent:
            log(out, "NOTICE", show=False, room_id=room_id)
        res["continue"] = True
        return res

    elif cmd == "COMMON_NOTICE_DANMAKU":
        d = json_obj.get("data", {})
        text = "".join([s.get("text", "")
                        for s in d.get("content_segments", [])])
        pk_kw = ["PK", "比赛", "对决", "逆转", "输掉", "赢得", "胜利", "获胜"]
        is_pk = any(kw in text for kw in pk_kw)
        if is_pk:
            output = f"[PK通知] {text}"
            style = "red"
        else:
            output = f"[通知] {text}"
            style = "yellow"
        if not silent:
            log(f"通知: {text}", "NOTICE", room_id=room_id)

    elif cmd == "LIVE_ANI_RES_UPDATE":
        items = json_obj.get("data", {}).get("list", [])
        if items:
            title = items[0].get("title", "")
            if title:
                status.append(("animation", title))
                output = f"[动画] {title}"
                style = "cyan"

    elif cmd == "STOP_LIVE_ROOM_LIST":
        rooms = json_obj.get("data", {}).get("room_id_list", [])
        status.append(("stop", len(rooms)))
        res["status"] = status
        res["continue"] = True
        return res

    elif cmd == "FLOW_REWARD_CARD" and "data" in json_obj:
        d = json_obj["data"]
        output = (f"[流量卡] {d.get('anchor_name','未知主播')}: "
                  f"{d.get('description','')} [{d.get('button_text','查看')}]")
        style = "yellow"

    elif cmd == "WIDGET_BANNER" and "data" in json_obj:
        d = json_obj["data"]
        widget_list = d.get("widget_list", {})
        ids = list(widget_list.keys()) if widget_list else []
        output = f"[横幅] 挂件: {', '.join(ids)}" if ids else "[横幅] 无挂件"
        style = "dim"

    elif cmd == "POPULARITY_RED_POCKET_V2_NEW" and "data" in json_obj:
        d = json_obj["data"]
        total = _safe_int(d.get("num", 1)) * _safe_int(d.get("price", 0))
        mi = d.get("medal_info", {}) or {}
        medal_str = (f"[{mi.get('medal_name','')} Lv{mi.get('medal_level',0)}]"
                     if mi.get("medal_name") else "")
        output = (f"[人气红包] {d.get('uname','未知')} "
                  f"{d.get('action','送出')} {d.get('gift_name','红包')} "
                  f"x{d.get('num',1)} (共{total}电池) {medal_str}")
        style = "yellow"
        status.append(("gift_add", 1))

    elif cmd == "POPULARITY_RED_POCKET_NEW" and "data" in json_obj:
        out = _handle_popularity_red_pocket_new(json_obj["data"])
        if out:
            output = out
            style = "yellow"
            status.append(("gift_add", 1))

    elif cmd == "POPULARITY_RED_POCKET_START" and "data" in json_obj:
        d = json_obj["data"]
        awards = d.get("awards", [])
        info = " + ".join([f"{a.get('gift_name','奖励')} x{a.get('num',0)}"
                           for a in awards])
        output = (f"[红包开始] {d.get('sender_name','未知')} 发出红包 "
                  f"(总价值{d.get('total_price',0)}电池，奖励: {info})")
        style = "yellow"

    elif cmd == "POPULARITY_RED_POCKET_V2_START" and "data" in json_obj:
        d = json_obj["data"]
        awards = d.get("awards", [])
        info = " + ".join([f"{a.get('gift_name','奖励')} x{a.get('num',0)}"
                           for a in awards])
        follow = " (需关注)" if d.get("need_follow") else ""
        output = (f"[红包开始] {d.get('sender_name','未知')} 发出红包{follow} "
                  f"(总价值{d.get('total_price',0)}电池，奖励: {info})")
        style = "yellow"

    # ============================================================
    # ★ 红包开奖：lot_id 去重（与 red_packet.py 共享 set）
    # ============================================================
    elif cmd in ("POPULARITY_RED_POCKET_V2_WINNER_LIST",
                 "POPULARITY_RED_POCKET_WINNER_LIST") and "data" in json_obj:
        d = json_obj["data"]
        lot_id = _safe_int(d.get("lot_id", 0))

        # ★ lot_id 去重：同一开奖在 red_packet.py 的 WS 通路可能已经处理过，
        #   这里共享 red_packet_manager._seen_rp_lots，只处理第一次。
        try:
            from red_packet import red_packet_manager
            if not red_packet_manager.try_mark_rp_lot(lot_id):
                # 已被处理过（重复推送 / 旧数据）→ 静默跳过
                res["continue"] = True
                return res
        except Exception:
            # red_packet 未加载时不阻塞主流程
            pass

        total_num = _safe_int(d.get("total_num", 0))
        winners_raw = d.get("winner_info", []) or []
        awards = d.get("awards", {}) or {}
        receive_uname = d.get("receive_uname", "") or ""

        # ---------- 解析每个中奖者 ----------
        winners = []
        for w in winners_raw:
            if not isinstance(w, list) or len(w) < 2:
                continue
            uid = _safe_int(w[0])
            uname = w[1] if isinstance(w[1], str) else ""
            award_key = str(w[3]) if len(w) > 3 else ""
            ts = _safe_int(w[6]) if len(w) > 6 else 0
            anchor_uid = _safe_int(w[7]) if len(w) > 7 else 0

            face = ""
            name_color = ""
            if len(w) > 8 and isinstance(w[8], dict):
                base = w[8].get("base") or {}
                face = base.get("face", "") or ""
                if face.startswith("http://"):
                    face = "https://" + face[7:]
                if not uname:
                    uname = base.get("name", "") or ""
                name_color = base.get("name_color_str", "") or ""

            award_info = awards.get(award_key) or {}
            award_name = award_info.get("award_name", "") or ""
            award_price = _safe_int(award_info.get("award_price", 0))
            award_pic = award_info.get("award_pic", "") or ""

            winners.append({
                "uid": uid,
                "uname": uname or f"UID {uid}",
                "face": face,
                "name_color": name_color,
                "award_key": award_key,
                "award_name": award_name,
                "award_price": award_price,
                "award_pic": award_pic,
                "ts": ts,
                "anchor_uid": anchor_uid,
            })

        # ---------- 判断「我」是否中奖 ----------
        my_uid = 0
        try:
            import account as _acc
            my_uid = _safe_int(getattr(_acc, "UID", 0) or 0)
        except Exception:
            pass

        my_win = None
        if my_uid:
            for w in winners:
                if w["uid"] == my_uid:
                    my_win = w
                    break

        def _fmt_price(p):
            if p <= 0:
                return ""
            return f"{p / 100:.2f}元"

        # ---------- 文本输出 ----------
        if my_win:
            an = my_win["award_name"] or "礼物"
            ps = _fmt_price(my_win["award_price"])
            price_str = f"（{ps}）" if ps else ""
            output = (f"🎉🎉 恭喜你中奖！红包 {lot_id} · "
                      f"{an}{price_str} · 共 {total_num} 人获奖")
            style = "magenta"

            status.append(("rp_win_me", {
                "lot_id": lot_id,
                "award_name": an,
                "award_price": my_win["award_price"],
                "total_num": total_num,
                "receive_uname": receive_uname,
                "ts": my_win["ts"],
            }))
            if not silent:
                log(f"★ 红包中奖: 红包{lot_id} · {an} · "
                    f"{ps or '价值未知'}", "WIN", room_id=room_id)
        else:
            if winners:
                parts = []
                for w in winners[:15]:
                    n = w["uname"]
                    a = w["award_name"]
                    p = _fmt_price(w["award_price"])
                    if a and p:
                        parts.append(f"{n}[{a}{p}]")
                    elif a:
                        parts.append(f"{n}[{a}]")
                    else:
                        parts.append(n)
                output = (f"[红包开奖] 红包 {lot_id} · "
                          f"共 {total_num} 人获奖 · 中奖者: " +
                          ", ".join(parts))
                if len(winners) > 15:
                    output += f" 等 {len(winners)} 人"
            else:
                output = (f"[红包开奖] 红包 {lot_id} · "
                          f"共 {total_num} 人获奖")
            style = "yellow"

        status.append(("rp_winners", {
            "lot_id": lot_id,
            "total_num": total_num,
            "receive_uname": receive_uname,
            "my_uid": my_uid,
            "my_win": my_win,
            "winners": winners,
        }))

        res["status"] = status
        res["output"] = output
        res["style"] = style
        return res

    elif cmd == "MESSAGEBOX_USER_GAIN_MEDAL" and "data" in json_obj:
        d = json_obj["data"]
        output = (f"[获得勋章] {d.get('fan_name','未知')} 获得 "
                  f"{d.get('medal_name','未知勋章')} Lv{d.get('medal_level',0)}，"
                  f"亲密度 +{d.get('intimacy',0)}")
        style = "yellow"

    elif cmd == "MESSAGEBOX_USER_MEDAL_CHANGE" and "data" in json_obj:
        d = json_obj["data"]
        output = (f"[勋章变更] {d.get('medal_name','')} "
                  f"Lv{d.get('medal_level',0)} 亲密度 {d.get('intimacy',0)}")
        style = "yellow"

    elif cmd == "CONFIRM_AUTO_FOLLOW" and "data" in json_obj:
        d = json_obj["data"]
        output = f"[自动关注] 用户 {d.get('uid',0)} 已关注主播 {d.get('ruid',0)}"
        style = "green"

    elif cmd == "VOICE_JOIN_ROOM_COUNT_INFO" and "data" in json_obj:
        d = json_obj["data"]
        output = (f"[语音连麦] 申请:{d.get('apply_count',0)} "
                  f"通知:{d.get('notify_count',0)} "
                  f"红点:{d.get('red_point',0)} 房间状态:{d.get('room_status',0)}")
        style = "cyan"

    elif cmd == "POPULAR_RANK_CHANGED" and "data" in json_obj:
        d = json_obj["data"]
        output = (f"[人气榜] 主播 {d.get('uid','')} 排名 {d.get('rank',0)} "
                  f"({d.get('rank_name_by_type','未知')}) "
                  f"倒计时 {d.get('countdown',0)}s")
        style = "yellow"

    elif cmd == "AREA_RANK_CHANGED" and "data" in json_obj:
        out = _handle_area_rank_changed(json_obj["data"])
        if out:
            output = out
            style = "yellow"

    elif cmd == "VOICE_JOIN_LIST" and "data" in json_obj:
        d = json_obj["data"]
        output = (f"[连麦列表] 申请:{d.get('apply_count',0)} "
                  f"刷新:{d.get('refresh',0)} 红点:{d.get('red_point',0)}")
        style = "cyan"

    elif cmd == "RANK_CHANGED" and "data" in json_obj:
        d = json_obj["data"]
        output = (f"[{d.get('rank_name_by_type','热门榜')}] "
                  f"主播 {d.get('uid','')} 排名 {d.get('rank',0)}")
        style = "yellow"

    elif cmd == "RANK_CHANGED_V2" and "data" in json_obj:
        d = json_obj["data"]
        output = (f"[{d.get('rank_name_by_type','热门榜')}V2] "
                  f"主播 {d.get('uid','')} 排名 {d.get('rank',0)} "
                  f"(类型:{d.get('rank_type',0)}, 子类:{d.get('sub_rank_type',0)}) "
                  f"倒计时 {d.get('countdown',0)}s")
        style = "yellow"

    elif cmd == "CUSTOM_NOTICE_CARD" and "data" in json_obj:
        d = json_obj["data"]
        output = (f"[自定义卡片] 业务:{d.get('business_id','')} "
                  f"状态:{d.get('business_status',0)}")
        style = "magenta"

    elif cmd == "LIVE_OPEN_PLATFORM_GAME" and "data" in json_obj:
        d = json_obj["data"]
        output = (f"[开放游戏] {d.get('msg_type','未知事件')}: "
                  f"{d.get('game_name','未知游戏')} "
                  f"(面板状态:{d.get('panel_status',-1)})")
        style = "green"

    elif cmd == "OPENPLATFORM_GAME_BUTTON_STATUS_CHANGE" and "data" in json_obj:
        d = json_obj["data"]
        st = d.get('status', -1)
        st_text = "显示" if st == 1 else "隐藏" if st == 0 else f"未知({st})"
        output = f"[游戏按钮] 状态:{st_text}"
        style = "green"

    elif cmd == "LIVE_ROOM_TOAST_MESSAGE" and "data" in json_obj:
        d = json_obj["data"]
        output = f"[提示] {d.get('message','')}"
        style = "yellow"

    elif cmd == "WIDGET_GIFT_STAR_PROCESS_V2" and "data" in json_obj:
        d = json_obj["data"]
        output = (f"[{d.get('name','未知活动')}] 进度: "
                  f"{d.get('cur_num',0)}/{d.get('total_num',0)}")
        style = "cyan"

    elif cmd == "USER_PANEL_RED_ALARM" and "data" in json_obj:
        d = json_obj["data"]
        output = (f"[红点提醒] 模块: {d.get('module','未知')}, "
                  f"提醒数: {d.get('alarm_num',0)}")
        style = "magenta"

    elif cmd == "PLAY_TOGETHER" and "data" in json_obj:
        out = _handle_play_together(json_obj["data"])
        if out:
            output = out
            style = "cyan"

    elif cmd == "HOT_ROOM_NOTIFY" and "data" in json_obj:
        d = json_obj["data"]
        output = f"[热门房间] {d.get('title','')} ({d.get('uname','')})"
        style = "yellow"

    elif cmd == "RECOMMEND_CARD" and "data" in json_obj:
        d = json_obj["data"]
        output = f"[推荐卡片] {d.get('title','')}"
        style = "dim"

    elif cmd == "REVENUE_RANK_CHANGED" and "data" in json_obj:
        d = json_obj["data"]
        output = (f"[营收榜] 排名 {d.get('rank',0)} "
                  f"(类型 {d.get('rank_type',0)})")
        style = "yellow"

    elif cmd == "WIDGET_WISH_LIST" and "data" in json_obj:
        d = json_obj["data"]
        output = f"[许愿] {d.get('name','')}: {d.get('status','')}"
        style = "cyan"

    elif cmd == "ANCHOR_LOT_START" and "data" in json_obj:
        d = json_obj["data"]
        award_name = d.get("award_name", "奖品")
        output = f"[抽奖开始] {award_name}"
        style = "yellow"

    elif cmd == "ANCHOR_LOT_END" and "data" in json_obj:
        d = json_obj["data"]
        output = f"[抽奖结束] 奖品ID {d.get('award_id',0)}"
        style = "yellow"

    elif cmd == "ANCHOR_LOT_AWARD" and "data" in json_obj:
        d = json_obj["data"]
        winners = d.get("award_users", [])
        names = [w.get("uname", "?") for w in winners[:10]]
        output = f"[抽奖开奖] 中奖: {', '.join(names)}" if names else "[抽奖开奖]"
        style = "yellow"

    res["output"] = output
    res["style"] = style
    res["status"] = status
    res["color_info"] = color_info
    return res


async def handle_message(body, print_fn=None, status_callback=None,
                          room_id=0, pk_callback=None):
    if not body:
        return ""
    try:
        raw_str = body.decode("utf-8")
    except Exception:
        return ""
    idx = raw_str.find('{')
    if 0 < idx < 16:
        raw_str = raw_str[idx:]
    results = []
    for part in split_json_objects(raw_str):
        if not part.strip():
            continue
        try:
            json_obj = json.loads(part)
        except Exception:
            continue
        r = parse_one(json_obj, silent=False, room_id=room_id,
                      pk_callback=pk_callback)
        for k, v in r.get("status", []):
            if status_callback:
                status_callback(k, v)
        if r.get("continue"):
            continue
        if r.get("output"):
            if print_fn:
                try:
                    await print_fn(r["output"], r.get("style"),
                                   color_info=r.get("color_info"))
                except TypeError:
                    await print_fn(r["output"], r.get("style"))
            results.append(r["output"])
    return "; ".join(results)