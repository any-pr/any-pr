@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ============================================================
echo   Configure pip mirrors (main + 2 fallbacks)
echo   Main    : Tsinghua
echo   Fallback: Aliyun + USTC
echo ============================================================
echo.

python -m pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple
python -m pip config set global.extra-index-url "https://mirrors.aliyun.com/pypi/simple/ https://pypi.mirrors.ustc.edu.cn/simple/"
python -m pip config set global.trusted-host "pypi.tuna.tsinghua.edu.cn mirrors.aliyun.com pypi.mirrors.ustc.edu.cn"

echo.
echo ---------- Current pip config ----------
python -m pip config list
echo ----------------------------------------
echo.

REM ============================================================
REM   Auto install dependencies
REM ============================================================
set "REQ=requirements.txt"
if not exist "%REQ%" (
    echo [ERROR] %REQ% not found in current directory
    echo         Put this script next to requirements.txt
    pause
    exit /b 1
)

echo ============================================================
echo   Installing dependencies from %REQ%
echo ============================================================
echo.

python -m pip install -r "%REQ%"
if !errorlevel! neq 0 (
    echo.
    echo [ERROR] Installation failed, retrying with Tsinghua only...
    python -m pip install -r "%REQ%" -i https://pypi.tuna.tsinghua.edu.cn/simple
    if !errorlevel! neq 0 (
        echo.
        echo [ERROR] Installation failed again, retrying with Aliyun only...
        python -m pip install -r "%REQ%" -i https://mirrors.aliyun.com/pypi/simple/
        if !errorlevel! neq 0 (
            echo.
            echo [ERROR] Installation failed again, retrying with USTC only...
            python -m pip install -r "%REQ%" -i https://pypi.mirrors.ustc.edu.cn/simple
            if !errorlevel! neq 0 (
                echo.
                echo [FATAL] All mirrors failed. Check network or use official PyPI:
                echo         python -m pip install -r %REQ%
                pause
                exit /b 1
            )
        )
    )
)

echo.
echo ============================================================
echo   Done. You can now run:  python main.py
echo ============================================================
pause
endlocal