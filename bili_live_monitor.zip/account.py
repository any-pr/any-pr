#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# account.py
"""Cookie 与多账号管理（统一存放在 accounts/ 目录）"""
import json
import time
from pathlib import Path

from logger import log_err

# 统一目录
ACCOUNTS_DIR = Path("accounts")
ACCOUNTS_DIR.mkdir(exist_ok=True)

COOKIE_FILE = ACCOUNTS_DIR / "cookie.txt"
ACCOUNTS_FILE = ACCOUNTS_DIR / "accounts.json"

# 旧文件自动迁移
_old_cookie = Path("cookie.txt")
_old_accounts = Path("accounts.json")
if _old_cookie.exists() and not COOKIE_FILE.exists():
    try:
        COOKIE_FILE.write_text(_old_cookie.read_text(encoding="utf-8"),
                               encoding="utf-8")
        _old_cookie.unlink()
    except Exception:
        pass
if _old_accounts.exists() and not ACCOUNTS_FILE.exists():
    try:
        ACCOUNTS_FILE.write_text(_old_accounts.read_text(encoding="utf-8"),
                                  encoding="utf-8")
        _old_accounts.unlink()
    except Exception:
        pass

if not COOKIE_FILE.exists():
    try:
        COOKIE_FILE.write_text("", encoding="utf-8")
    except Exception:
        pass

_cookie_dict = {}
cookie_str = ""
UID = 0
BUVID3 = ""
CSRF = ""
SESSDATA = ""

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 Chrome/120 Safari/537.36",
    "Referer": "https://live.bilibili.com/",
    "Origin": "https://live.bilibili.com",
    "Cookie": "",
    "Accept": "application/json,text/plain,*/*",
}

account_info = {"is_login": False, "mid": 0, "uname": "", "face": "", "level": 0,
                "coin": 0.0, "bcoin": 0.0, "vip_status": 0, "vip_label": ""}


def load_cookies():
    try:
        text = COOKIE_FILE.read_text(encoding="utf-8").strip()
    except Exception:
        return {}
    d = {}
    for item in text.split(";"):
        item = item.strip()
        if "=" in item:
            k, v = item.split("=", 1)
            d[k] = v
    return d


def save_cookies(cookie_dict):
    try:
        line = "; ".join(f"{k}={v}" for k, v in cookie_dict.items())
        COOKIE_FILE.write_text(line, encoding="utf-8")
        return True
    except Exception as e:
        log_err(f"保存 cookie 失败: {e}")
        return False


def reload_headers():
    global _cookie_dict, cookie_str, UID, BUVID3, CSRF, SESSDATA
    _cookie_dict = load_cookies()
    cookie_str = "; ".join(f"{k}={v}" for k, v in _cookie_dict.items())
    UID = int(_cookie_dict.get("DedeUserID", 0) or 0)
    BUVID3 = _cookie_dict.get("buvid3", "")
    CSRF = _cookie_dict.get("bili_jct", "")
    SESSDATA = _cookie_dict.get("SESSDATA", "")
    HEADERS["Cookie"] = cookie_str


def get_cookie_dict():
    return _cookie_dict


def has_login():
    return bool(SESSDATA and CSRF and UID)


def load_accounts():
    if not ACCOUNTS_FILE.exists():
        return {"current": None, "accounts": {}}
    try:
        data = json.loads(ACCOUNTS_FILE.read_text(encoding="utf-8"))
        if "accounts" not in data:
            data["accounts"] = {}
        if "current" not in data:
            data["current"] = None
        return data
    except Exception:
        return {"current": None, "accounts": {}}


def save_accounts(data):
    try:
        ACCOUNTS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                                 encoding="utf-8")
    except Exception as e:
        log_err(f"保存账号失败: {e}")


def add_or_update_account(cookie_dict, info):
    data = load_accounts()
    mid = str(info.get("mid") or cookie_dict.get("DedeUserID") or 0)
    if not mid or mid == "0":
        return False
    data["accounts"][mid] = {
        "cookie": cookie_dict,
        "uname": info.get("uname", ""),
        "face": info.get("face", ""),
        "mid": info.get("mid", 0),
        "level": info.get("level", 0),
        "coin": info.get("coin", 0),
        "bcoin": info.get("bcoin", 0),
        "vip_status": info.get("vip_status", 0),
        "vip_label": info.get("vip_label", ""),
        "saved_at": time.time(),
    }
    data["current"] = mid
    save_accounts(data)
    return True


def remove_account(mid):
    data = load_accounts()
    if mid in data["accounts"]:
        del data["accounts"][mid]
    if data.get("current") == mid:
        keys = list(data["accounts"].keys())
        data["current"] = keys[0] if keys else None
    save_accounts(data)
    return data["current"]


def set_current_account(mid):
    data = load_accounts()
    if mid not in data["accounts"]:
        return False
    data["current"] = mid
    save_accounts(data)
    return True


def apply_account_to_cookie_file(mid):
    data = load_accounts()
    acc = data["accounts"].get(mid)
    if not acc:
        return False
    ck = acc.get("cookie", {})
    try:
        line = "; ".join(f"{k}={v}" for k, v in ck.items())
        COOKIE_FILE.write_text(line, encoding="utf-8")
        return True
    except Exception:
        return False


reload_headers()