#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# pb.py
"""Protobuf 解析与封包（纯函数，不写日志）"""
import struct
import zlib
import brotli


def _safe_int(v, default=0):
    try:
        if isinstance(v, bool):
            return default
        return int(v)
    except Exception:
        return default


def _is_valid_name(s):
    if not s or not isinstance(s, str):
        return False
    if s.startswith("http"):
        return False
    if not (1 <= len(s) <= 30):
        return False
    if s.isdigit():
        return False
    if s.strip() == "":
        return False
    return True


def _first_string(v, want_url=False):
    if isinstance(v, str):
        if want_url:
            return v if v.startswith("http") else ""
        return v
    if isinstance(v, list):
        for it in v:
            r = _first_string(it, want_url)
            if r:
                return r
    elif isinstance(v, dict):
        if "string" in v and isinstance(v["string"], str):
            s = v["string"]
            if want_url:
                if s.startswith("http"):
                    return s
            elif s:
                return s
        if "message" in v:
            r = _first_string(v["message"], want_url)
            if r:
                return r
        for k, vv in v.items():
            if k in ("string", "bytes_hex"):
                continue
            r = _first_string(vv, want_url)
            if r:
                return r
    return ""


def _first_int(v):
    if isinstance(v, bool):
        return 0
    if isinstance(v, int):
        return v
    if isinstance(v, list):
        for it in v:
            r = _first_int(it)
            if r:
                return r
    elif isinstance(v, dict):
        for key in ("varint", "signed", "i64"):
            if key in v and isinstance(v[key], int):
                return v[key]
        if "message" in v:
            r = _first_int(v["message"])
            if r:
                return r
    return 0


def read_varint(data, pos):
    value = 0
    shift = 0
    while pos < len(data):
        b = data[pos]
        pos += 1
        value |= (b & 0x7f) << shift
        if not (b & 0x80):
            return value, pos
        shift += 7
        if shift > 64:
            raise Exception("overflow")
    raise Exception("eof")


def decode_varint_signed(v):
    if v >= (1 << 63):
        return v - (1 << 64)
    return v


def decode_pb_safe(data):
    result = {}
    pos = 0
    length = len(data)
    while pos < length:
        start = pos
        try:
            tag, pos = read_varint(data, pos)
            field = tag >> 3
            wire = tag & 7
            if wire == 0:
                value, pos = read_varint(data, pos)
                result.setdefault(field, []).append(
                    {"varint": value, "signed": decode_varint_signed(value)})
            elif wire == 2:
                size, pos = read_varint(data, pos)
                if pos + size > length:
                    value = data[pos:]
                    pos = length
                else:
                    value = data[pos:pos + size]
                    pos += size
                item = {"bytes_hex": value.hex()}
                try:
                    s = value.decode("utf-8")
                    if s.isprintable():
                        item["string"] = s
                except Exception:
                    pass
                if len(value) < 1024 * 1024:
                    try:
                        child = decode_pb_safe(value)
                        if child:
                            item["message"] = child
                    except Exception:
                        pass
                result.setdefault(field, []).append(item)
            elif wire == 1:
                if pos + 8 > length:
                    v = data[pos:]
                    pos = length
                else:
                    v = data[pos:pos + 8]
                    pos += 8
                result.setdefault(field, []).append({"i64": int.from_bytes(v, 'little')})
            elif wire == 5:
                if pos + 4 > length:
                    v = data[pos:]
                    pos = length
                else:
                    v = data[pos:pos + 4]
                    pos += 4
                result.setdefault(field, []).append({"i32": int.from_bytes(v, 'little')})
            else:
                break
        except Exception:
            pos = start + 1
            continue
    return result


def _looks_like_subpacket(body):
    if len(body) < 16:
        return False
    try:
        n = struct.unpack_from(">I", body, 0)[0]
    except Exception:
        return False
    return 16 <= n <= len(body)


def build_packet(op, payload, protover=3):
    body = payload.encode("utf-8")
    header_len = 16
    total_len = header_len + len(body)
    buf = bytearray(total_len)
    struct.pack_into(">I", buf, 0, total_len)
    struct.pack_into(">H", buf, 4, header_len)
    struct.pack_into(">H", buf, 6, protover)
    struct.pack_into(">I", buf, 8, op)
    struct.pack_into(">I", buf, 12, 1)
    buf[header_len:] = body
    return bytes(buf)


def parse_packets(data):
    packets = []
    offset = 0
    total_data_len = len(data)
    while offset + 16 <= total_data_len:
        total_len = struct.unpack_from(">I", data, offset)[0]
        if total_len == 0:
            break
        if total_len < 16 or offset + total_len > total_data_len:
            break
        header_len = struct.unpack_from(">H", data, offset + 4)[0]
        proto_ver = struct.unpack_from(">H", data, offset + 6)[0]
        op = struct.unpack_from(">I", data, offset + 8)[0]
        raw_body = data[offset + header_len:offset + total_len]
        body = raw_body
        if proto_ver == 2:
            try:
                body = zlib.decompress(raw_body)
            except Exception:
                pass
        elif proto_ver == 3:
            try:
                body = brotli.decompress(raw_body)
            except Exception:
                try:
                    body = zlib.decompress(raw_body)
                except Exception:
                    pass
        if proto_ver in (2, 3) and _looks_like_subpacket(body):
            packets.extend(parse_packets(body))
            offset += total_len
            continue
        packets.append({
            "op": op,
            "body": body,
            "proto_ver": proto_ver,
            "header_len": header_len,
            "total_len": total_len,
            "raw_len": len(raw_body),
        })
        offset += total_len
    return packets


def split_json_objects(text):
    objects = []
    i = 0
    while i < len(text):
        while i < len(text) and text[i] != '{':
            i += 1
        if i >= len(text):
            break
        start = i
        depth = 0
        in_string = False
        escape = False
        while i < len(text):
            ch = text[i]
            if escape:
                escape = False
                i += 1
                continue
            if ch == '\\':
                escape = True
                i += 1
                continue
            if ch == '"' and not in_string:
                in_string = True
                i += 1
                continue
            if ch == '"' and in_string:
                in_string = False
                i += 1
                continue
            if not in_string:
                if ch == '{':
                    depth += 1
                elif ch == '}':
                    depth -= 1
                    if depth == 0:
                        objects.append(text[start:i + 1])
                        i += 1
                        break
            i += 1
        if i == start:
            break
    return objects


def extract_rank_items_from_json(data):
    result = []
    items = (data.get("data") or {}).get("item", []) or []
    for it in items:
        mi = it.get("medal_info", {}) or {}
        if not mi:
            ui = it.get("uinfo", {}) or {}
            mi = ui.get("medal", {}) or {}
        mn = (mi.get("medal_name") or mi.get("name") or "").strip()
        ml = _safe_int(mi.get("level", 0))
        mg = _safe_int(mi.get("guard_level", it.get("guard_level", 0)))
        face = it.get("face", "")
        name = it.get("name", "")
        if not face or not name:
            base = ((it.get("uinfo", {}) or {}).get("base", {}) or {})
            face = face or base.get("face", "")
            name = name or base.get("name", "")
        if face.startswith("http://"):
            face = "https://" + face[7:]
        result.append({"uid": _safe_int(it.get("uid", 0)), "uname": name or "?",
                       "face": face,
                       "score": _safe_int(it.get("score", 0)),
                       "rank": _safe_int(it.get("rank", 0)),
                       "medal_name": mn, "medal_level": ml, "medal_guard": mg})
    return result


def tree_to_json(node):
    """把 decode_pb_safe 的树转成 JSON 可序列化结构"""
    if isinstance(node, dict):
        if "varint" in node:
            return node.get("signed", node["varint"])
        if "i64" in node:
            return node["i64"]
        if "i32" in node:
            return node["i32"]
        if "message" in node:
            return {"msg": tree_to_json(node["message"])}
        if "string" in node:
            return node["string"]
        if "bytes_hex" in node:
            return {"_bytes_hex": node["bytes_hex"]}
        out = {}
        for k, v in node.items():
            out[str(k)] = tree_to_json(v)
        return out
    if isinstance(node, list):
        if len(node) == 1:
            return tree_to_json(node[0])
        return [tree_to_json(x) for x in node]
    return node