#!/system/bin/sh
if getprop ro.hardware.vulkan | grep -q "adreno"; then
    resetprop ro.hardware.vulkan turnip
    echo "Turnip 已设为当前 Vulkan 驱动。"
else
    resetprop ro.hardware.vulkan adreno
    echo "Adreno 已设为当前 Vulkan 驱动。"
fi
sleep 10