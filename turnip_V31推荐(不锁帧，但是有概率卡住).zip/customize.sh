#!/system/bin/sh

MODVER=`grep_prop version $MODPATH/module.prop`
MODVERCODE=`grep_prop versionCode $MODPATH/module.prop`

ui_print ""
ui_print "版本=$MODVER "
ui_print "Magisk版本=$MAGISK_VER"
ui_print ""
ui_print "Freedreno Turnip Vulkan 驱动 - 梦依依OvO"
ui_print ""
sleep 1.25

ui_print ""
ui_print "正在检查设备信息..."
sleep 1.25

[ $(getprop ro.system.build.version.sdk) -lt 34 ] && echo "现在需要 Android 14！中止..." && abort
echo ""
echo "一切正常... 继续"
ui_print ""
ui_print "正在安装驱动，请稍候..."
ui_print ""

sleep 1.25
set_perm_recursive $MODPATH/system 0 0 0755 0644
set_perm $MODPATH/system/vendor/lib64/hw/vulkan.turnip.so 0 0 0644

ui_print "驱动安装成功"
sleep 1.25

ui_print ""
ui_print "全部完成，请重启设备"
ui_print ""
ui_print "作者：梦依依OvO"
ui_print ""